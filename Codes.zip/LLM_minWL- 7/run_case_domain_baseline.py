import pandas as pd

import Database
import graph
from scenario_csv_runner import run_domain_once, run_scenario
from latency_runner import (
    compute_domain_latency_curve,
    export_domain_ratio_latency_csv,
    export_latency_csv,
)
BASELINE_DOMAIN_WEIGHT_BY_DOMAIN = {
    0: [0, 2, 610, 610, 938, 110, 110, 10],
    1: [0, 3, 630, 630, 948, 112, 112, 10],
    2: [0, 2, 580, 580, 925, 106, 106, 9],
    3: [0, 3, 650, 650, 958, 115, 115, 11],
    4: [0, 2, 620, 620, 942, 111, 111, 10],
    5: [0, 3, 660, 660, 962, 116, 116, 11],
    6: [0, 2, 640, 640, 952, 113, 113, 10],
}
# True: 只跑 Traffic_3000_0.5，仅输出「业务请求数-已激活波长总数」「业务请求数-已建立光路数」「业务请求数-时延」
# False: 全跑（含域间占比波长/光路/阻塞率、域间占比-时延等）
ONLY_05 = True
if __name__ == "__main__":
    # 确认加载的是当前目录下的 graph.py（改参数后此处应变化；不变则未加载到正确文件或未删 __pycache__）
    print(
        "[graph 已加载] "
        f"w_dem={graph.PARTITION_DEMAND_WEIGHT} "
        f"refine_pass={graph.PARTITION_REFINE_MAX_PASSES} "
        f"increase_cross={graph.PARTITION_REFINE_INCREASE_CROSS} | "
        f"跨域拓扑边(主划分)={graph.DOMAIN_PARTITION_SUMMARY['跨域拓扑边数(主划分)']} | "
        f"边界覆盖点数={len(graph.boundary_node_list)} | "
        f"各域主节点数={graph.DOMAIN_PARTITION_SUMMARY['各域主节点数']}"
    )
    domain_count = len(graph.domain_node_list_all)
    domain_edge_weight_by_id = {}
    for d in range(domain_count):
        if d in BASELINE_DOMAIN_WEIGHT_BY_DOMAIN:
            raw_weight = BASELINE_DOMAIN_WEIGHT_BY_DOMAIN[d]
        else:
            # 若未来域数变化，默认复用最后一组，避免 KeyError。
            raw_weight = BASELINE_DOMAIN_WEIGHT_BY_DOMAIN[
                max(BASELINE_DOMAIN_WEIGHT_BY_DOMAIN.keys())
            ]
        domain_edge_weight_by_id[d] = Database.to_augraph_edge_weight(raw_weight)
    print(f"[分七域_基线weights] 各域权重配置: {BASELINE_DOMAIN_WEIGHT_BY_DOMAIN}")
    traffic_csv = "Traffic_3000_0.5.csv"
    out_wave_csv = "分七域_基线weights_业务请求数_已激活波长总数.csv"
    out_lightpath_csv = "分七域_基线weights_业务请求数-已建立的光路数.csv"
    out_latency_csv = "分七域_基线weights_业务请求数-时延ms.csv"
    out_ratio_latency_csv = "分七域_基线weights_域间业务占比-时延ms.csv"

    if ONLY_05:
        (
            total_wave,
            wave_curve,
            total_lightpath,
            lightpath_curve,
            blocked_total,
            _success_curve,
            blocked_reason_counts,
        ) = run_domain_once(traffic_csv, domain_edge_weight_by_id)
        pd.DataFrame(
            {
                "业务请求数": list(range(1, Database.job_number + 1)),
                "已激活波长总数": [int(x) for x in wave_curve],
            }
        ).to_csv(out_wave_csv, index=False, encoding="utf-8-sig")
        pd.DataFrame(
            {
                "业务请求数": list(range(1, Database.job_number + 1)),
                "已建立的光路数": [int(x) for x in lightpath_curve],
            }
        ).to_csv(out_lightpath_csv, index=False, encoding="utf-8-sig")
        print(f"[分七域_基线weights] ONLY_05=True，traffic={traffic_csv}")
        print(f"[分七域_基线weights] 总激活波长数: {total_wave}，总已建立光路数: {total_lightpath}，阻塞: {blocked_total}")
        print(f"[分七域_基线weights] 阻塞原因: {blocked_reason_counts}")
        print(f"[分七域_基线weights] 已输出: {out_wave_csv}")
        print(f"[分七域_基线weights] 已输出: {out_lightpath_csv}")
    else:
        run_scenario(
            scenario_name="分七域_基线weights",
            business_csv_out=out_wave_csv,
            ratio_csv_out="分七域_基线weights_域间业务占比_已激活波长总数.csv",
            business_lightpath_csv_out=out_lightpath_csv,
            ratio_blocking_csv_out="分七域_基线weights_域间业务占比_成功率阻塞率.csv",
            global_weight=None,
            domain_edge_weight_by_id=domain_edge_weight_by_id,
        )

    print(f"[分七域_基线weights] 开始计算时延: {traffic_csv}")
    latency_curve, _business_success, latency_stats = compute_domain_latency_curve(
        traffic_csv, domain_edge_weight_by_id, progress_every=50
    )
    export_latency_csv(traffic_csv, latency_curve, out_latency_csv)
    print(f"[分七域_基线weights] 时延统计: {latency_stats}")
    print(f"[分七域_基线weights] 已输出: {out_latency_csv}")

    if not ONLY_05:
        print("[分七域_基线weights] 开始输出域间占比-时延（6 个占比场景）...")
        export_domain_ratio_latency_csv(
            domain_edge_weight_by_id, out_ratio_latency_csv, progress_every=50
        )
    else:
        print("[分七域_基线weights] ONLY_05=True，已跳过域间占比相关 CSV 与域间占比-时延")