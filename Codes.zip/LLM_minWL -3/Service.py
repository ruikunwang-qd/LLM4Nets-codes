import os
import pandas as pd
import copy
import Database
import random

# 根据 Database.job_number 尝试加载对应的 Traffic_N.csv
# 如果不存在（比如你还没生成 Traffic_3000.csv），则回退到 Traffic_1000.csv，
# 然后通过取模方式把请求扩展到 Database.job_number 条。
path1 = f'Traffic_{Database.job_number}.csv'
if not os.path.exists(path1):
    path1 = 'Traffic_1000.csv'
# path1 = Database.data_path21
# path1 = 'noise/noise1.csv'
# path1 = Database.data_path_random_list[6]
# path1 = Database.data_path_list[21]
# path2 = path1
# print("path1",path1)
# print("path2",path2)

data = pd.read_csv(path1, engine='python')
# data_list = data.values.tolist()

# data = pd.read_excel(data_path,sheet_name='0822',usecols=list(range(0,3)))
service_src_all = list(data['src'])  # 所有源节点
service_dst_all = list(data['dst'])  # 所有目的节点

# 要获取不同时刻的流量，改usercols即可
service_traffic_all1 = pd.read_csv(path1, engine='python',
                                   usecols=list(range(3, Database.time + 3)))  # 记录所有业务的流量（多个时刻）
# service_traffic_all = pd.read_excel(data_path,sheet_name='0822',usecols=list(range(3,Database.time+3)))     # 记录所有业务的流量（多个时刻）
service_traffic_all1 = service_traffic_all1.values.tolist()

# service_traffic_all2 = pd.read_csv(path2, engine='python',
#                                    usecols=list(range(3, Database.time + 3)))  # 记录所有业务的流量（多个时刻）
# service_traffic_all2 = service_traffic_all2.values.tolist()

service_list = []  # 业务信息集合

service = {}  # 存储当前业务，字典，存储id，src，dest，traffic


# traffic_min_list = []  # 最小流量
# traffic_max_list = []  # 最大流量
# for i in range(len(service_traffic_all)):
#     traffic_min_list.append(min(service_traffic_all[i]))
#     traffic_max_list.append(max(service_traffic_all[i]))
# traffic_min = min(traffic_min_list)
# traffic_max = max(traffic_max_list)
# print(traffic_max)
# service示例
# service = {
#     'id': 1,
#     'src': 5,
#     'dest': 4,
#     'traffic': 0.5
# }
# 产生业务的时候就限制长度了，不需要time_update


def generate_service(start, end):
    service_list.clear()
    traffic_list = service_traffic_all1
    n_src = len(service_src_all)
    if n_src == 0:
        raise ValueError(f"Traffic 文件 {path1} 里没有 src/dst 数据")
    for i in range(Database.job_number):
        src_dst_idx = i % n_src  # 不存在 Traffic_{job_number} 时，用 Traffic_1000 扩展到更大请求数
        service['id'] = i
        service['src'] = service_src_all[src_dst_idx]
        service['dest'] = service_dst_all[src_dst_idx]
        service['traffic'] = traffic_list[src_dst_idx][start:end]  # 流量是一个1*24的向量
        service_list.append(service.copy())
        service.clear()
    # print(service_list[0])


if __name__ == '__main__':
    for i in range(10):
        generate_service(0, 24)

