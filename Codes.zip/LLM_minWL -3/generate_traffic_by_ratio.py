# -*- coding: utf-8 -*-
"""
根据 Traffic_1000.csv 的格式与规律，生成域间业务占比不同的业务 CSV。
- 域划分与 graph.py 一致：A 0-13, B 14-27, C 28-40, D 41-54, E 55-67
- 域间业务：src 与 dst 属于不同域
- band0~band23 等流量列：直接沿用模板中的数值，以保持“原有的流量区间/分布”
"""
import pandas as pd
import random

# 与 graph.py 一致的域划分（主域节点）
DOMAIN_NODES = [
    list(range(0, 14)),   # A
    list(range(14, 28)),  # B
    list(range(28, 41)),  # C
    list(range(41, 55)),  # D
    list(range(55, 68)),  # E
]
N_NODES = 68
N_JOBS = 3000


def get_domain(node):
    """节点 node 所属主域编号 0~4"""
    for d, nodes in enumerate(DOMAIN_NODES):
        if node in nodes:
            return d
    return -1


def is_cross_domain(src, dst):
    return get_domain(src) != get_domain(dst)


def random_cross_domain_pair():
    """随机生成一对域间 (src, dst)：两个节点属于不同域"""
    d1, d2 = random.sample(range(5), 2)
    src = random.choice(DOMAIN_NODES[d1])
    dst = random.choice(DOMAIN_NODES[d2])
    return src, dst


def random_intra_domain_pair():
    """随机生成一对域内 (src, dst)：同一域内两节点（不允许同节点）"""
    d = random.choice(range(5))
    nodes = DOMAIN_NODES[d]
    src, dst = random.sample(nodes, 2)
    return src, dst


def generate_traffic_csv(template_path, out_path, cross_ratio):
    """
    template_path: 模板 CSV（如 Traffic_1000_0.1.csv），提供列格式与 band 规律
    out_path: 输出路径
    cross_ratio: 域间业务占比，0~1（如 0.4 表示 40% 域间）
    """
    df = pd.read_csv(template_path, encoding='utf-8')
    if len(df) == 0:
        raise ValueError(f"模板 CSV {template_path} 为空")

    # 始终生成固定数量的业务请求
    n = N_JOBS
    n_cross = int(round(n * cross_ratio))
    n_intra = n - n_cross

    pairs = []
    for _ in range(n_cross):
        pairs.append(random_cross_domain_pair())
    for _ in range(n_intra):
        pairs.append(random_intra_domain_pair())
    random.shuffle(pairs)

    # traffic 向量：按模板中的 band 列统计规律随机“生成”（不是随机抽取模板行）
    band_cols = [c for c in df.columns if str(c).startswith('band')]
    if not band_cols:
        raise ValueError(f"{template_path} 缺少 band 列（未找到以 'band' 开头的列）")

    # 预先计算每个 band 列的生成参数
    band_stats = {}
    for c in band_cols:
        col = df[c].astype(float)
        mu = float(col.mean())
        sd = float(col.std(ddof=0))
        mn = float(col.min())
        mx = float(col.max())
        band_stats[c] = (mu, sd, mn, mx)

    src_list = [p[0] for p in pairs]
    dst_list = [p[1] for p in pairs]

    # 逐业务生成 band0~band23
    traffic_rows = []
    for _ in range(n):
        row_vals = []
        for c in band_cols:
            mu, sd, mn, mx = band_stats[c]
            # 用截断高斯，保证生成值仍落在模板范围内（保持“流量规律”的数值尺度）
            if sd <= 0:
                val = mu
            else:
                val = random.gauss(mu, sd)
            if val < mn:
                val = mn
            if val > mx:
                val = mx
            row_vals.append(val)
        traffic_rows.append(row_vals)

    out = pd.DataFrame(traffic_rows, columns=band_cols)
    out.insert(0, 'src', src_list)
    out.insert(1, 'dst', dst_list)

    out.to_csv(out_path, index=False, encoding='utf-8-sig')
    actual_cross = sum(1 for i in range(n) if is_cross_domain(out['src'].iloc[i], out['dst'].iloc[i]))
    print(f"已生成 {out_path}: 域间业务 {actual_cross}/{n} ({100*actual_cross/n:.1f}%)")


if __name__ == '__main__':
    template = 'Traffic_1000.csv'
    # 生成域间占比：0.0, 0.2, 0.4, 0.5, 0.6, 0.8, 1.0
    for r in [0.0, 0.2, 0.4, 0.5, 0.6, 0.8, 1.0]:
        if r == 1.0:
            out = "Traffic_3000_1.csv"
        elif r == 0.0:
            out = "Traffic_3000_0.csv"
        else:
            out = f"Traffic_3000_{r}.csv"
        generate_traffic_csv(template, out, r)
