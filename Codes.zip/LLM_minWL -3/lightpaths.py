import AuOdlConvert
import Compute
import Service
import Database
import AuGraph
import RWA
import numpy as np

Service.generate_service(0, Database.time)
Database.clear(Database.links_physical)
AuGraph.links_virtual_list.clear()  # 清空虚拟链路

links_virtual_len = []

for i in range(Database.job_number):
    if i == 0:
        AuGraph.au_graph_init(AuGraph.edge_weight)
        flag, wave_used, au_edges_list = RWA.route_wave_assign(AuGraph.edge_weight, i)
        print(i, len(AuGraph.links_virtual_list))
        links_virtual_len.append(len(AuGraph.links_virtual_list))
    else:
        AuGraph.update_au_graph_weight(AuGraph.edge_weight)
        flag, wave_used, au_edges_list = RWA.route_wave_assign(AuGraph.edge_weight, i)
        if (i + 1) % 20 == 0:
            print(i, '\t', len(AuGraph.links_virtual_list))
        links_virtual_len.append(len(AuGraph.links_virtual_list))


print('\n', links_virtual_len)
