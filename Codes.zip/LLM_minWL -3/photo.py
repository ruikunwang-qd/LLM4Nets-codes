"""
从两个 CSV 绘制折线图（已建立光路数）：
  - 域间占比-建立光路数-3000.csv  → 域间业务占比 vs 最终已建立光路数（多曲线）
  - 业务数量-建立光路数-3000-0.5.csv → 业务序号 vs 累计已建立光路数（多曲线）
"""
import os

import matplotlib.pyplot as plt
import matplotlib
import pandas as pd

matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
matplotlib.rcParams['axes.unicode_minus'] = False

DIR = os.path.dirname(os.path.abspath(__file__))

CSV_RATIO = os.path.join(DIR, '域间占比-建立光路数-3000.csv')
CSV_BUSINESS = os.path.join(DIR, '业务数量-建立光路数-3000-0.5.csv')

OUT_RATIO = os.path.join(DIR, '域间占比-建立光路数-3000_折线图.png')
OUT_BUSINESS = os.path.join(DIR, '业务数量-建立光路数-3000-0.5_折线图.png')

# 折线颜色：未分域 + 各分域方法
COLORS = {
    # 颜色：蓝、绿、黄、红（按图中方法列命名匹配）
    '不分域': '#1f77b4',  # 蓝
    '分域Heuristic': '#2ca02c',  # 绿
    '分域deepseek': '#ffcc00',  # 黄（业务CSV里是小写deepseek）
    '分域Deepseek': '#ffcc00',  # 黄（域间占比CSV里是大写Deepseek）
    '分域chatgpt': '#d62728',  # 红
    '分域Chatgpt': '#d62728',
}


def _plot_columns(df, x_col, y_cols, title, ylabel, outfile, xlim_pad=0.02):
    fig, ax = plt.subplots(figsize=(10, 5.5))
    x = df[x_col]
    use_marker = len(df) <= 40
    for col in y_cols:
        if col not in df.columns:
            continue
        c = COLORS.get(col, None)
        ax.plot(
            x,
            df[col],
            marker='o' if use_marker else None,
            markersize=5,
            linewidth=1.6,
            label=col,
            color=c,
        )
    ax.set_xlabel(x_col, fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=13)
    ax.grid(True, linestyle='--', alpha=0.6)
    ax.legend(loc='best', fontsize=10)
    if x.dtype.kind in 'fiu' and len(df) > 1:
        xmin, xmax = float(x.min()), float(x.max())
        pad = (xmax - xmin) * xlim_pad + 1e-6
        ax.set_xlim(xmin - pad, xmax + pad)
    plt.tight_layout()
    plt.savefig(outfile, dpi=150, bbox_inches='tight', pad_inches=0.2)
    plt.close()
    print(f'已保存: {outfile}')


def main():
    if not os.path.isfile(CSV_RATIO):
        raise FileNotFoundError(CSV_RATIO)
    if not os.path.isfile(CSV_BUSINESS):
        raise FileNotFoundError(CSV_BUSINESS)

    df_r = pd.read_csv(CSV_RATIO, encoding='utf-8-sig')
    x_r = df_r.columns[0]
    y_r = [c for c in df_r.columns if c != x_r]
    _plot_columns(
        df_r,
        x_r,
        y_r,
        title='域间业务占比 - 最终已建立光路数（3000 条业务）',
        ylabel='已建立光路数',
        outfile=OUT_RATIO,
    )

    df_b = pd.read_csv(CSV_BUSINESS, encoding='utf-8-sig')
    x_b = df_b.columns[0]
    y_b = [c for c in df_b.columns if c != x_b]
    _plot_columns(
        df_b,
        x_b,
        y_b,
        title='业务数量 - 累计已建立光路数（Traffic 3000，域间占比 0.5）',
        ylabel='累计已建立光路数',
        outfile=OUT_BUSINESS,
        xlim_pad=0.001,
    )


if __name__ == '__main__':
    main()
