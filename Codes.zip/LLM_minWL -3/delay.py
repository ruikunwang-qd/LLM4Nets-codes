import AuGraph
import Database

latency = []
is_block = []

average_latency = [0]
success_num = [0]
reject_num = [0]


def compute_latency(flag, au_edges_list):

    is_block.append(int(not flag))
    latency_temp = 0
    # print(au_edges_list)
    cur_list = au_edges_list[-1]
    continue_index = -1
    if len(cur_list) != 0:
        for j in range(len(cur_list)):
            if j > continue_index:
                cur_au_edge = cur_list[j]  # 业务i的第j个辅助图边
                if cur_au_edge['attribute'] == 4:  # 波长链路边
                    # 要判断是不是多个WLE，第一个WLE的源节点——>etl，最后一个WLE的目的节点——>lte，中间都是ltl
                    # 一个WLE
                    if cur_list[j + 1]['attribute'] == 3:
                        latency_temp += 2 * Database.OEO_time + Database.fiber_time

                    elif cur_list[j + 1]['attribute'] == 7:
                        fiber_num = 0
                        for m in range(j, len(cur_list)):
                            if cur_list[m]['attribute'] == 4:
                                fiber_num += 1
                            elif cur_list[m]['attribute'] == 7:
                                continue
                            else:
                                continue_index = m - 1  # 从最后一个波长链路边的下一条边开始遍历
                                break  # 跳出for循环
                        latency_temp += 2 * Database.OEO_time + fiber_num * Database.fiber_time

                if cur_au_edge['attribute'] == 1:  # 光路边
                    for vir_link in AuGraph.links_virtual_list:
                        if cur_au_edge['src_phy'] == vir_link['src'] and \
                                cur_au_edge['dest_phy'] == vir_link['dest'] and \
                                cur_au_edge['wavelength_id'] == vir_link['wavelength_id']:
                            latency_temp += 2 * Database.OEO_time + (len(vir_link['route']) - 1) * Database.fiber_time
        latency.append(latency_temp)
    else:
        latency.append(0)


    # 全部业务
    success_num[0] = len(is_block) - sum(is_block)
    reject_num[0] = sum(is_block)
    if success_num[0] != 0:
        average_latency[0] = sum(latency) / success_num[0]
    else:
        average_latency[0] = float('inf')

    return latency[-1], average_latency[0]

