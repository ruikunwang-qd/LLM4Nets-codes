import pandas as pd

import Database
from scenario_csv_runner import TRAFFIC_FILES_BY_RATIO, run_global_once
from latency_runner import compute_global_latency_curve, export_latency_csv


GLOBAL_BASELINE_WEIGHTS = [0, 5, 100, 100, 1000, 10, 10, 25]
ONLY_05 = False  # True: 只跑 Traffic_3000_0.5；False: 额外输出域间占比两份 CSV


if __name__ == "__main__":
    global_weight = Database.to_augraph_edge_weight(GLOBAL_BASELINE_WEIGHTS)
    traffic_csv = "Traffic_3000_0.5.csv"
    out_csv = "不分域_业务请求数_已激活波长总数.csv"
    out_lightpath_csv = "不分域_业务请求数-已建立的光路数.csv"
    out_ratio_wave_csv = "不分域_域间业务占比_已激活波长总数.csv"
    out_ratio_lightpath_csv = "不分域_域间业务占比-已激活的光路数.csv"
    out_ratio_blocking_csv = "不分域_域间业务占比_成功率阻塞率.csv"
    out_latency_csv = "不分域_业务请求数-时延ms.csv"

    total_wave, wave_curve, total_lightpath, lightpath_curve, blocked_total, _success_curve, blocked_reason_counts = run_global_once(
        traffic_csv,
        global_weight,
        progress_every=50,
        progress_tag="不分域_基线weights",
    )

    pd.DataFrame(
        {
            "业务请求数": list(range(1, Database.job_number + 1)),
            "已激活波长总数": [int(x) for x in wave_curve],
        }
    ).to_csv(out_csv, index=False, encoding="utf-8-sig")

    pd.DataFrame(
        {
            "业务请求数": list(range(1, Database.job_number + 1)),
            "已建立的光路数": [int(x) for x in lightpath_curve],
        }
    ).to_csv(out_lightpath_csv, index=False, encoding="utf-8-sig")

    if not ONLY_05:
        ratio_wave_records = []
        ratio_lightpath_records = []
        ratio_blocking_records = []
        for ratio_csv, ratio in TRAFFIC_FILES_BY_RATIO:
            ratio_total_wave, _ratio_wave_curve, ratio_total_lightpath, _ratio_lightpath_curve, ratio_blocked, _ratio_success_curve, ratio_reason_counts = run_global_once(
                ratio_csv,
                global_weight,
            )
            ratio_wave_records.append(
                {
                    "域间业务占比": float(ratio),
                    "已激活波长总数": int(ratio_total_wave),
                }
            )
            ratio_lightpath_records.append(
                {
                    "域间业务占比": float(ratio),
                    "已激活的光路数": int(ratio_total_lightpath),
                }
            )
            ratio_blocking_records.append(
                {
                    "域间业务占比": float(ratio),
                    "业务总数": int(Database.job_number),
                    "成功业务数": int(Database.job_number - ratio_blocked),
                    "阻塞业务数": int(ratio_blocked),
                    "阻塞率": float(ratio_blocked / Database.job_number),
                    "成功率": float((Database.job_number - ratio_blocked) / Database.job_number),
                    "阻塞原因_源端无可用出边": int(ratio_reason_counts.get("SRC_NO_OUT_EDGE", 0)),
                    "阻塞原因_目的端无可用入边": int(ratio_reason_counts.get("DST_NO_IN_EDGE", 0)),
                    "阻塞原因_辅助图无可行路径": int(ratio_reason_counts.get("NO_FEASIBLE_PATH_IN_AUX", 0)),
                }
            )

        pd.DataFrame(ratio_wave_records).to_csv(out_ratio_wave_csv, index=False, encoding="utf-8-sig")
        pd.DataFrame(ratio_lightpath_records).to_csv(out_ratio_lightpath_csv, index=False, encoding="utf-8-sig")
        pd.DataFrame(ratio_blocking_records).to_csv(out_ratio_blocking_csv, index=False, encoding="utf-8-sig")

    print(f"[不分域_基线weights] traffic={traffic_csv}")
    print(f"[不分域_基线weights] 总激活波长数: {total_wave}")
    print(f"[不分域_基线weights] 总已建立光路数: {total_lightpath}")
    print(f"[不分域_基线weights] 阻塞业务数: {blocked_total}")
    print(f"[不分域_基线weights] 阻塞原因: {blocked_reason_counts}")
    print(f"[不分域_基线weights] 已输出: {out_csv}")
    print(f"[不分域_基线weights] 已输出: {out_lightpath_csv}")
    if not ONLY_05:
        print(f"[不分域_基线weights] 已输出: {out_ratio_wave_csv}")
        print(f"[不分域_基线weights] 已输出: {out_ratio_lightpath_csv}")
        print(f"[不分域_基线weights] 已输出: {out_ratio_blocking_csv}")
    else:
        print("[不分域_基线weights] ONLY_05=True，已跳过域间占比两份 CSV")

    # 时延计算（对应 delay.py 的 compute_latency 逻辑）
    print(f"[不分域_基线weights] 开始计算时延: {traffic_csv}")
    latency_curve, success_flags, latency_stats = compute_global_latency_curve(
        traffic_csv, global_weight, progress_every=50
    )
    export_latency_csv(traffic_csv, latency_curve, out_latency_csv)
    print(f"[不分域_基线weights] 时延统计: {latency_stats}")