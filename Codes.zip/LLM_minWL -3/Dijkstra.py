inf = float('inf')


def dijkstra(matrix, source, destination, id=0):
    """
    使用 O(n^2) 的数组实现 Dijkstra，避免原来三重循环导致的极慢速度。
    matrix 为 n×n 的邻接矩阵，inf 表示无边。
    """
    n = len(matrix)
    if n == 0 or source >= n or destination >= n:
        print('Error!')
        return []
    # 最短距离数组
    dist = [inf] * n
    dist[source] = 0.0

    # 是否已确定最短路
    visited = [False] * n

    # 前驱节点，用于回溯路径
    prev = [-1] * n

    for _ in range(n):
        # 1. 从未访问节点中选一个 dist 最小的
        u = -1
        u_dist = inf
        for i in range(n):
            if (not visited[i]) and dist[i] < u_dist:
                u_dist = dist[i]
                u = i

        if u == -1 or u == destination:
            break

        visited[u] = True

        # 2. 用 u 松弛所有 v
        row_u = matrix[u]
        for v in range(n):
            w = row_u[v]
            if w == inf:
                continue
            if not visited[v] and dist[u] + w < dist[v]:
                dist[v] = dist[u] + w
                prev[v] = u

    # 无可达路径
    if dist[destination] == inf:
        return []

    # 回溯得到路径
    path = []
    cur = destination
    while cur != -1:
        path.append(cur)
        cur = prev[cur]
    path.reverse()
    # print("id", id, "路径", path)
    return path


if __name__ == '__main__':
    graph = [[0.00000, inf, inf, 5.00000, inf, inf, inf, inf, inf, inf, inf, inf],
             [0.00000, 0.00000, inf, inf, inf, inf, inf, inf, inf, inf, inf, inf],
             [50.00000, inf, 0.00000, inf, inf, 0.00000, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, 0.00000, 0.00000, 50.00000, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, 0.00000, inf, inf, inf, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, 0.00000, inf, inf, 1000.00000, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, 0.00000, inf, inf, 5.00000, inf, inf],
             [inf, inf, inf, inf, inf, inf, 0.00000, 0.00000, inf, inf, inf, inf],
             [inf, inf, inf, inf, inf, inf, 50.00000, inf, 0.00000, inf, inf, 0.00000],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, 0.00000, 0.00000, 50.00000],
             [inf, inf, inf, inf, inf, inf, inf, inf, inf, inf, 0.00000, inf],
             [inf, inf, 1000.00000, inf, inf, inf, inf, inf, inf, inf, inf, 0.00000]]
    path = dijkstra(graph, 2, 0)
    print(path)
