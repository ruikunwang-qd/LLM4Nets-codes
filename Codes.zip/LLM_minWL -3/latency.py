import AuOdlConvert
import Compute
import Service
import Database
import AuGraph
import RWA
import delay
import statistics


Service.generate_service(0, Database.time)
Database.clear(Database.links_physical)
AuGraph.links_virtual_list.clear()  # 清空虚拟链路
latency_list = []

for i in range(Database.job_number):
# for i in range(1):
    if i == 0:
        AuGraph.au_graph_init(AuGraph.edge_weight)
        flag, wave_used, au_edges_list = RWA.route_wave_assign(AuGraph.edge_weight, i)
        latency, avg_latency = delay.compute_latency(flag, au_edges_list)
        print(i, "使用波长：", wave_used, "时延", latency, "平均时延", avg_latency)
        latency_list.append(latency)
    else:
        AuGraph.update_au_graph_weight(AuGraph.edge_weight)
        flag, wave_used, au_edges_list = RWA.route_wave_assign(AuGraph.edge_weight, i)
        latency, avg_latency = delay.compute_latency(flag, au_edges_list)
        print(i, "使用波长：", wave_used, "时延", latency, "平均时延", avg_latency)
        latency_list.append(latency)


print(latency_list)

print()

print(f'the min latency is {min(latency_list):.4f} ms, '
      f'the median latency is {statistics.median(latency_list):.4f} ms, '
      f'mean latency is {sum(latency_list) / len(latency_list):.4f} ms, '
      f'the max latency is {max(latency_list):.4f} ms')

print(f'{sum(latency_list) / len(latency_list):.4f}')
