import Database


def compute_wavelength(links_physical):  # 计算使用波长
    wave, row, col = links_physical.shape
    wave_used_all = 0        # 记波长使用情况，一段时间路由策略不变，波长使用情况相同
    max_wave_num = int(wave/Database.time)
    for i in range(row):
        for j in range(col):
            if Database.graph_connect[i][j] == 1:
                for k in range(max_wave_num):
                    wave_used = 0
                    for t in range(Database.time):
                        if 0 <= links_physical[t * max_wave_num + k][i][j] < Database.wavelength_capacity:
                            wave_used = 1
                    wave_used_all += wave_used

    return wave_used_all


# =========================
# 增量统计：避免每次全量扫描 links_physical
# =========================
_wave_used_mask = None  # shape: (wavelength_number, node, node), bool
_wave_used_count = 0    # 已经被使用过的(波长k, i->j)数量（按有向边统计）


def init_wavelength_tracker(node_number: int = None, wavelength_number: int = None):
    """
    初始化“已使用波长链路”追踪器。
    - node_number / wavelength_number 默认取 Database 里的配置
    """
    global _wave_used_mask, _wave_used_count
    if node_number is None:
        node_number = Database.node_number
    if wavelength_number is None:
        wavelength_number = Database.wavelength_number

    # 用有向边统计，和 compute_wavelength 的 i->j 扫描一致
    _wave_used_mask = [[ [False] * node_number for _ in range(node_number) ] for _ in range(wavelength_number)]
    _wave_used_count = 0


def mark_wavelength_used(wavelength_id: int, src: int, dest: int):
    """
    在第一次使用某条(波长, src->dest)时计数 +1。
    wavelength_id: 0..Database.wavelength_number-1
    """
    global _wave_used_mask, _wave_used_count
    if _wave_used_mask is None:
        init_wavelength_tracker()
    if wavelength_id < 0:
        return
    if not _wave_used_mask[wavelength_id][src][dest]:
        _wave_used_mask[wavelength_id][src][dest] = True
        _wave_used_count += 1


def get_wave_used_count() -> int:
    """返回当前累计已使用的(波长, 有向链路)数量。"""
    global _wave_used_mask, _wave_used_count
    if _wave_used_mask is None:
        init_wavelength_tracker()
    return _wave_used_count
# 计算业务经过的跳数，一条源到目的的新建光路是一跳，只统计虚拟拓扑上的跳数
# 经过的跳数就是接入层节点数量除以2，接入层节点都是5的倍数
def compute_hop(route):
    virtual_hop_num = 0
    for i in range(len(route)):
        cur_node = route[i]
        if cur_node % 5 == 0:
            virtual_hop_num += 1
    virtual_hop_num /= 2
    # print("光路数量：",virtual_hop_num)
    return virtual_hop_num


if __name__ == '__main__':
    Database.links_physical[5][0][1] = 5
    print(compute_wavelength(Database.links_physical))
