import os
import time
import multiprocessing as mp

import pandas as pd

import Database
import graph
import Compute
import AuGraph
import RWA
import Service
from AuGraph_simulation_LLM import run_domain_sim


# 要跑的业务文件及其对应的“域间业务占比”
TRAFFIC_FILES = [
    ('Traffic_3000_0.csv', 0.0),
    ('Traffic_3000_0.2.csv', 0.2),
    ('Traffic_3000_0.4.csv', 0.4),
    ('Traffic_3000_0.6.csv', 0.6),
    ('Traffic_3000_0.8.csv', 0.8),
    ('Traffic_3000_1.csv', 1.0),
]

N_RUNS = 1  # 每个业务文件（每个占比）只跑 1 次（条数由 Database.job_number 决定，当前 3000）

# True：只跑分域仿真（用 Database 里五域 weight）；不分域结果从已有 CSV 读入合并，省时间。
# False：每个场景分域 + 不分域都跑（完整重算）。
DOMAIN_ONLY_SIM = True

# 仅用于「业务数量 - 激活波长数」逐条曲线（与六个域间占比场景无关）
TRAFFIC_BUSINESS_COUNT_VS_WL = 'Traffic_3000_0.5.csv'
OUT_BUSINESS_COUNT_VS_WL_CSV = '业务数量_激活波长数_Traffic3000_0.5.csv'
# DOMAIN_ONLY 时：从此文件读取「不分域」列（须已存在一次完整跑出的结果）
PREV_DOMAIN_RATIO_CSV = '分域多次仿真结果_域间占比.csv'


def merge_wave_used_by_business(results, job_number):
    """
    与 AuGraph_simulation_LLM 主流程一致：按原始业务 id 合并五域子段，
    对第 k 条业务（0-based），取各域中「ser_id <= k 的最后一个子段」对应的 wave_used，再五域求和。
    """
    domain_wave_lists = []
    domain_ser_id_lists = []
    for _domain_id, wave_list, ser_id_list, _domain_total_wave, _elapsed, _seg_elapsed_list in results:
        domain_wave_lists.append(wave_list)
        domain_ser_id_lists.append(ser_id_list)

    wave_used_by_business = []
    for k in range(job_number):
        total_k = 0
        for wave_list, ser_id_list in zip(domain_wave_lists, domain_ser_id_lists):
            i_last = -1
            for j, sid in enumerate(ser_id_list):
                if sid <= k:
                    i_last = j
            if i_last >= 0:
                total_k += wave_list[i_last]
        wave_used_by_business.append(total_k)
    return wave_used_by_business


def load_services_from_csv(csv_path):
    """
    按 Service.generate_service 的逻辑，从指定 CSV 里构造业务列表：
    - 读取 src/dst
    - 读取 band0~band(time-1) 作为 traffic 向量
    """
    df = pd.read_csv(csv_path, engine='python')
    src_list = list(df['src'])
    dst_list = list(df['dst'])

    traffic_df = pd.read_csv(
        csv_path,
        engine='python',
        usecols=list(range(3, Database.time + 3))
    )
    traffic_list = traffic_df.values.tolist()

    services = []
    job_number = Database.job_number
    n_rows = len(src_list)
    if n_rows == 0:
        raise ValueError(f"CSV {csv_path} 为空，无法生成业务")
    for i in range(job_number):
        # 如果 Database.job_number > CSV 行数（例如你把 job_number 改成 3000，但只有 Traffic_1000_*.csv），
        # 则通过取模把请求扩展到需要的数量。
        src_dst_idx = i % n_rows
        services.append({
            'id': i,
            'src': int(src_list[src_dst_idx]),
            'dest': int(dst_list[src_dst_idx]),
            'traffic': traffic_list[src_dst_idx][0:Database.time],
        })
    return services


def run_one_domain_parallel(csv_path, domain_edge_weight_by_id):
    """
    对指定业务 CSV，执行一次“分域拆段 + 5 域并行”的仿真。
    返回：
      - 激活波长总数 (5 域求和)
      - 并行整体时间（墙钟）
      - 每条原始业务运行时间（拆段后各子段耗时求和，长度=job_number）
      - wave_used_by_business：按原始业务合并后的累计激活波长（五域求和），长度=job_number
    """
    base_services = load_services_from_csv(csv_path)

    # 按域拆段
    domain_to_seg_services = {0: [], 1: [], 2: [], 3: [], 4: []}
    for base_service in base_services:
        ser_id = base_service['id']
        src = base_service['src']
        dest = base_service['dest']
        traffic = base_service['traffic']

        full_path, segments = graph.route_with_domain_segments(src, dest)
        if not full_path or not segments:
            continue

        for seg_idx, seg in enumerate(segments):
            seg_nodes = seg['nodes']
            seg_domain = seg['domain']

            seg_src = seg_nodes[0]
            seg_dest = seg_nodes[-1]

            seg_service = {
                'id': f"{ser_id}_seg{seg_idx}_D{seg_domain}",
                'ser_id': ser_id,
                'src': seg_src,
                'dest': seg_dest,
                'traffic': traffic.copy(),
            }
            if seg_domain in domain_to_seg_services:
                domain_to_seg_services[seg_domain].append(seg_service)

    # 5 个域并行执行
    # domain_edge_weight_by_id：每个域的 AuGraph.edge_weight 顺序权重；确保 Windows spawn 多进程下权重传递正确。
    tasks = [(d, segs, domain_edge_weight_by_id[d]) for d, segs in domain_to_seg_services.items() if segs]

    parallel_start = time.time()
    with mp.Pool(processes=len(tasks)) as pool:
        results = pool.starmap(run_domain_sim, tasks)
    parallel_time = time.time() - parallel_start

    # 汇总激活波长总数：5 个域各自统计值求和
    total_wave_used = sum(r[3] for r in results)

    # 汇总“每条原始业务运行时间”：把拆段后落在不同域的子段耗时求和
    job_number = Database.job_number
    per_service_times = [0.0 for _ in range(job_number)]
    # run_domain_sim 返回: (domain_id, wave_list, ser_id_list, domain_total_wave, elapsed, seg_elapsed_list)
    for r in results:
        ser_id_list = r[2]
        seg_elapsed_list = r[5]
        for sid, dt in zip(ser_id_list, seg_elapsed_list):
            if 0 <= int(sid) < job_number:
                per_service_times[int(sid)] += float(dt)

    wave_used_by_business = merge_wave_used_by_business(results, job_number)
    return total_wave_used, parallel_time, per_service_times, wave_used_by_business


def run_one_global_baseline(csv_path):
    """
    对指定业务 CSV，执行一次“不分域（全网基线）”仿真。
    返回：
      - 激活波长总数
      - 总运行时间（墙钟）
      - 每条业务运行时间（长度=job_number）
      - wave_used_list_global：处理完第 i 条业务后（0-based）的累计已激活波长数，长度=job_number
    """
    services = load_services_from_csv(csv_path)
    Service.service_list = services

    # 初始化：清空物理链路、波长统计、虚拟光路
    Database.clear(Database.links_physical)
    Compute.init_wavelength_tracker(Database.node_number, Database.wavelength_number)
    AuGraph.links_virtual_list.clear()

    per_service_times = []
    wave_used_list_global = []
    start = time.time()
    for i in range(Database.job_number):
        t0 = time.perf_counter()
        if i == 0:
            AuGraph.au_graph_init(AuGraph.edge_weight)
        else:
            AuGraph.update_au_graph_weight(AuGraph.edge_weight)
        _flag, wave_used, _au_edges = RWA.route_wave_assign(AuGraph.edge_weight, i)
        wave_used_list_global.append(wave_used)
        per_service_times.append(time.perf_counter() - t0)

    total_time = time.time() - start
    total_wave_used = Compute.get_wave_used_count()
    return total_wave_used, total_time, per_service_times, wave_used_list_global


def export_business_count_vs_wavelength_csv(
    traffic_csv,
    out_path,
    baseline_domain_edge_weights,
    domain_only=False,
    prev_out_path_for_merge=None,
):
    """
    输出「业务数量 - 激活波长数」CSV：
    - domain_only=False：分域 + 不分域都仿真；
    - domain_only=True：只跑分域；不分域列从 prev_out_path_for_merge（默认同 out_path）已有 CSV 读取。
    """
    jn = Database.job_number
    merge_from = prev_out_path_for_merge or out_path

    if domain_only:
        print(f"[业务数量-激活波长数] DOMAIN_ONLY：只跑分域，不分域列从 {merge_from} 合并 → {out_path}")
        if not os.path.isfile(merge_from):
            raise FileNotFoundError(
                f'DOMAIN_ONLY 需要先存在 {merge_from}（含列：业务序号、不分域_累计已激活波长数）。'
            )
        prev = pd.read_csv(merge_from, encoding='utf-8-sig')
        for col in ('业务序号', '不分域_累计已激活波长数'):
            if col not in prev.columns:
                raise ValueError(f'{merge_from} 缺少列: {col}')
        if len(prev) != jn:
            raise ValueError(f'{merge_from} 行数应为 {jn}，实际 {len(prev)}')
        g_curve = prev['不分域_累计已激活波长数'].astype(int).tolist()
        g_wave = int(g_curve[-1]) if g_curve else 0
    else:
        print(f"[业务数量-激活波长数] 使用 {traffic_csv}，共 {jn} 条业务 → {out_path}")
        g_wave, _g_time, _g_per, g_curve = run_one_global_baseline(traffic_csv)
        assert len(g_curve) == jn, '不分域波长曲线长度应与 job_number 一致'

    d_wave, _d_time, _d_per, d_curve = run_one_domain_parallel(traffic_csv, baseline_domain_edge_weights)
    assert len(d_curve) == jn, '分域波长曲线长度应与 job_number 一致'

    pd.DataFrame({
        '业务序号': list(range(1, jn + 1)),
        '不分域_累计已激活波长数': [int(x) for x in g_curve],
        '分域_累计已激活波长数_五域求和': [int(x) for x in d_curve],
    }).to_csv(out_path, index=False, encoding='utf-8-sig')
    print(f"  已保存: {out_path}（不分域总波长≈{g_wave}, 分域五域和={d_wave}）")


def main():
    # 分域基线：使用 weight_A1~weight_E1（Database.get_domain_edge_weight_baseline）
    baseline_domain_edge_weights = {d: Database.get_domain_edge_weight_baseline(d) for d in range(5)}

    prev_ratio_df = None
    if DOMAIN_ONLY_SIM:
        if not os.path.isfile(PREV_DOMAIN_RATIO_CSV):
            raise FileNotFoundError(
                f'DOMAIN_ONLY_SIM=True 需要已有 {PREV_DOMAIN_RATIO_CSV}（含未分域汇总列），'
                f'请先 DOMAIN_ONLY_SIM=False 完整跑一次，或把旧结果文件放到当前目录。'
            )
        prev_ratio_df = pd.read_csv(PREV_DOMAIN_RATIO_CSV, encoding='utf-8-sig')
        print(f'[DOMAIN_ONLY] 已读入未分域汇总: {PREV_DOMAIN_RATIO_CSV}')

    # 1) 仅 Traffic_3000_0.5：业务数量 - 激活波长数（逐业务一条）
    export_business_count_vs_wavelength_csv(
        TRAFFIC_BUSINESS_COUNT_VS_WL,
        OUT_BUSINESS_COUNT_VS_WL_CSV,
        baseline_domain_edge_weights,
        domain_only=DOMAIN_ONLY_SIM,
        prev_out_path_for_merge=OUT_BUSINESS_COUNT_VS_WL_CSV,
    )

    # 2) 六个域间业务占比：业务占比 - 激活波长数（汇总表 CSV）
    records = []
    jn = Database.job_number

    for csv_path, ratio in TRAFFIC_FILES:
        if DOMAIN_ONLY_SIM:
            print(f"业务文件 {csv_path} (域间占比 {ratio})：仅分域仿真（{jn} 条业务），未分域列来自 {PREV_DOMAIN_RATIO_CSV}")
            sub = prev_ratio_df[prev_ratio_df['csv_file'] == csv_path]
            if len(sub) != 1:
                raise ValueError(
                    f'{PREV_DOMAIN_RATIO_CSV} 中应恰好有一行 csv_file={csv_path!r}，实际 {len(sub)} 行'
                )
            pr = sub.iloc[0]
            g_wave = int(pr['global_total_wave_used'])
            g_time = float(pr['global_wall_clock_sec'])
            g_mean = float(pr['global_per_service_time_mean_sec'])
            g_median = float(pr['global_per_service_time_median_sec'])
        else:
            print(f"业务文件 {csv_path} (域间占比 {ratio})：分域 + 未分域 各仿真 1 次（{jn} 条业务）")
            g_wave, g_time, g_per_service_times, g_wave_curve = run_one_global_baseline(csv_path)
            assert len(g_wave_curve) == jn, f"未分域波长曲线长度应为 {jn}，实际 {len(g_wave_curve)}"
            g_mean = float(pd.Series(g_per_service_times).mean())
            g_median = float(pd.Series(g_per_service_times).median())
            print(f"  [未分域] 激活波长总数 = {g_wave}, 总时间 = {g_time:.2f} 秒")

        d_wave_base, d_time_parallel_base, d_per_service_times_base, d_wave_curve = run_one_domain_parallel(
            csv_path, baseline_domain_edge_weights
        )
        assert len(d_wave_curve) == jn, f"分域波长曲线长度应与 {jn}，实际 {len(d_wave_curve)}"
        print(f"  [分域] 激活波长总数 = {d_wave_base}, 并行时间 = {d_time_parallel_base:.2f} 秒")

        records.append({
            'csv_file': csv_path,
            'ratio': ratio,
            'run_index': 1,
            'global_total_wave_used': g_wave,
            'global_wall_clock_sec': g_time,
            'global_per_service_time_mean_sec': g_mean,
            'global_per_service_time_median_sec': g_median,
            'domain_total_wave_used_sum5': d_wave_base,
            'domain_parallel_wall_clock_sec': d_time_parallel_base,
            'domain_per_service_time_mean_sec': float(pd.Series(d_per_service_times_base).mean()),
            'domain_per_service_time_median_sec': float(pd.Series(d_per_service_times_base).median()),
        })

    # 业务占比 - 激活波长数（每个域间占比一行）
    pd.DataFrame(records).to_csv(
        '分域多次仿真结果_域间占比.csv',
        index=False,
        encoding='utf-8-sig'
    )
    print("已保存: 分域多次仿真结果_域间占比.csv（业务占比-激活波长数）")

if __name__ == '__main__':
    main()

