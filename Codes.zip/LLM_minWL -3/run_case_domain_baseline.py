import pandas as pd

import Database
import graph
from scenario_csv_runner import run_domain_once
DOMAIN_WEIGHTS = {
    0: [0, 0, 430, 430, 1000, 145, 145, 95],
    1: [0, 0, 450, 450, 1000, 155, 155, 100],
    2: [0, 0, 410, 410, 1000, 135, 135, 90],
}

if __name__ == "__main__":
    domain_count = len(graph.domain_node_list_all)
    selected_weights = [DOMAIN_WEIGHTS[d] for d in sorted(DOMAIN_WEIGHTS.keys())[:domain_count]]
    domain_edge_weight_by_id = {d: Database.to_augraph_edge_weight(w) for d, w in enumerate(selected_weights)}

    traffic_csv = "Traffic_3000_0.5.csv"
    out_wave_csv = "分三域_基线weights_业务请求数-激活波长数.csv"

    total_wave, wave_curve, _total_lightpath, _lightpath_curve, _blocked_total, _success_curve, _blocked_reason_counts = (
        run_domain_once(traffic_csv, domain_edge_weight_by_id)
    )

    pd.DataFrame(
        {
            "业务请求数": list(range(1, Database.job_number + 1)),
            "激活波长数": [int(x) for x in wave_curve],
        }
    ).to_csv(out_wave_csv, index=False, encoding="utf-8-sig")

    test_v = int(total_wave)
    lo, hi = TARGET_WAVE_RANGE
    in_range = lo <= test_v <= hi
