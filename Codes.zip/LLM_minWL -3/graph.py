import numpy as np
import Database
import pandas as pd
# 导入邻接矩阵
adjacency_matrix = pd.read_csv('csv格式中讯拓扑邻接矩阵_68.csv', header=None)
adjacency_matrix = adjacency_matrix.fillna(0)
adjacency_matrix = np.array(adjacency_matrix, dtype=int)
PARTITION_USE_LOCAL_REFINE = False
PARTITION_PROXY_PICK_FRACTILE = 0.17
PARTITION_PROXY_PICK_INDEX = None  # 非 None 时忽略 FRACTILE，直接用排序后的下标（0=代理最优）


def _build_traffic_demand_matrix(csv_path, node_count):
    """
    根据业务CSV构造节点对业务需求矩阵（无向累加）。
    """
    try:
        df = pd.read_csv(csv_path, engine="python")
    except Exception:
        return np.zeros((node_count, node_count), dtype=float)

    demand = np.zeros((node_count, node_count), dtype=float)
    if "src" not in df.columns or "dst" not in df.columns:
        return demand

    for s, d in zip(df["src"], df["dst"]):
        s_i = int(s)
        d_i = int(d)
        if 0 <= s_i < node_count and 0 <= d_i < node_count and s_i != d_i:
            demand[s_i][d_i] += 1.0
            demand[d_i][s_i] += 1.0
    return demand


def _partition_proxy_tuple(adj, labels, demand):
    n = len(labels)
    boundary_flag = [False] * n
    cut_topo_edges = 0
    cross_demand = 0.0

    for i in range(n):
        for j in range(i + 1, n):
            if labels[i] == labels[j]:
                continue
            if adj[i][j] != 0:
                cut_topo_edges += 1
                boundary_flag[i] = True
                boundary_flag[j] = True
            if demand is not None and demand[i][j] > 0:
                cross_demand += float(demand[i][j])
                boundary_flag[i] = True
                boundary_flag[j] = True

    boundary_nodes = int(sum(boundary_flag))
    return (cross_demand, cut_topo_edges, boundary_nodes)


def _kmeans_simple(x, k, max_iter=100):
    n = x.shape[0]
    centers = x[np.linspace(0, n - 1, k, dtype=int)].copy()
    labels = np.zeros(n, dtype=int)

    for _ in range(max_iter):
        dist = np.linalg.norm(x[:, None, :] - centers[None, :, :], axis=2)
        new_labels = np.argmin(dist, axis=1)
        if np.array_equal(new_labels, labels):
            break
        labels = new_labels
        for c in range(k):
            idx = np.where(labels == c)[0]
            if len(idx) == 0:
                farthest = int(np.argmax(np.min(dist, axis=1)))
                centers[c] = x[farthest]
                labels[farthest] = c
            else:
                centers[c] = np.mean(x[idx], axis=0)
    return labels


def _spectral_embedding(adj, demand_norm, demand_alpha, k):
    """融合拓扑与业务需求的谱嵌入（列数至少为 k，便于 kmeans）。"""
    n = adj.shape[0]
    combined = adj.astype(float) + float(demand_alpha) * demand_norm
    degrees = np.sum(combined, axis=1)
    lap = np.diag(degrees) - combined
    _eigvals, eigvecs = np.linalg.eigh(lap)

    start = 1 if n > 1 else 0
    end = min(start + k, eigvecs.shape[1])
    embedding = eigvecs[:, start:end]
    if embedding.shape[1] < k:
        padding = np.zeros((n, k - embedding.shape[1]), dtype=float)
        embedding = np.hstack([embedding, padding])
    return embedding


def _balance_domain_sizes(labels, coords, k, min_size):
    """避免极小域；coords 与 kmeans 使用的特征一致。"""
    labels = np.asarray(labels, dtype=int).copy()
    for _ in range(5):
        counts = [int(np.sum(labels == d)) for d in range(k)]
        small_domains = [d for d, c in enumerate(counts) if c < min_size]
        if not small_domains:
            break
        for d_small in small_domains:
            donors = [d for d, c in enumerate(counts) if c > min_size + 1]
            if not donors:
                continue
            donor = donors[np.argmax([counts[d] for d in donors])]
            donor_nodes = np.where(labels == donor)[0]
            small_idx = np.where(labels == d_small)[0]
            if len(small_idx) == 0 or len(donor_nodes) == 0:
                continue
            small_center = np.mean(coords[small_idx], axis=0)
            donor_dist = np.linalg.norm(coords[donor_nodes] - small_center, axis=1)
            move_node = int(donor_nodes[np.argmin(donor_dist)])
            labels[move_node] = d_small
    return labels


def _local_refine_partition(adj, labels, demand, k):
    """单点迁移：按代理目标字典序改进划分。"""
    labels = np.asarray(labels, dtype=int).copy()
    n = len(labels)

    improved = True
    while improved:
        improved = False
        base_t = _partition_proxy_tuple(adj, labels, demand)
        counts = [int(np.sum(labels == d)) for d in range(k)]
        for node in range(n):
            src = int(labels[node])
            if counts[src] <= 1:
                continue
            best_domain = src
            best_t = base_t
            for dst in range(k):
                if dst == src:
                    continue
                labels[node] = dst
                new_t = _partition_proxy_tuple(adj, labels, demand)
                if new_t < best_t:
                    best_t = new_t
                    best_domain = dst
                labels[node] = src
            if best_domain != src:
                labels[node] = best_domain
                counts[src] -= 1
                counts[best_domain] += 1
                base_t = best_t
                improved = True

    return labels


def _k_domain_partition(adj, k, demand=None, rng_seed=42):
    n = adj.shape[0]
    if demand is None:
        demand = np.zeros((n, n), dtype=float)

    if np.max(demand) > 0:
        demand_norm = demand / np.max(demand)
    else:
        demand_norm = demand

    vol = demand.sum(axis=1)
    if np.max(vol) > 0:
        vol_col = (vol / np.max(vol)).reshape(-1, 1)
    else:
        vol_col = np.zeros((n, 1))

    rng = np.random.default_rng(int(rng_seed))
    candidates = []
    # 略收窄极端 alpha，减少「跨域业务被压得过低」的划分
    demand_alphas = [2.5, 2.8, 3.1, 3.4, 3.7, 4.0, 4.4, 4.8]
    noise_scales = [0.0, 0.025, 0.05]
    use_volume_flags = [False, True]

    min_size = max(8, n // (k * 2))

    for use_volume in use_volume_flags:
        for alpha in demand_alphas:
            for noise in noise_scales:
                emb = _spectral_embedding(adj, demand_norm, alpha, k)
                if use_volume:
                    x_work = np.hstack([emb, vol_col])
                else:
                    x_work = emb.copy()
                if noise > 0:
                    x_work = x_work + rng.normal(0.0, noise, size=x_work.shape)

                labels = _kmeans_simple(x_work, k)
                labels = _balance_domain_sizes(labels, x_work, k, min_size)
                if PARTITION_USE_LOCAL_REFINE:
                    labels = _local_refine_partition(adj, labels, demand, k)

                t = _partition_proxy_tuple(adj, labels, demand)
                candidates.append((t, labels.copy()))

    if not candidates:
        best_labels = np.zeros(n, dtype=int)
    else:
        candidates.sort(key=lambda item: item[0])

        m = len(candidates) - 1
        if PARTITION_PROXY_PICK_INDEX is not None and int(PARTITION_PROXY_PICK_INDEX) >= 0:
            pick_idx = max(0, min(m, int(PARTITION_PROXY_PICK_INDEX)))
        else:
            f = float(PARTITION_PROXY_PICK_FRACTILE)
            f = max(0.0, min(1.0, f))
            pick_idx = int(round(f * max(m, 0))) if m > 0 else 0
            pick_idx = max(0, min(m, pick_idx))
        best_labels = candidates[pick_idx][1]

    return [sorted(np.where(best_labels == d)[0].tolist()) for d in range(k)], best_labels


def _build_cross_domain_edges(adj, labels):
    n = adj.shape[0]
    cross_edges = []
    for u in range(n):
        for v in range(u + 1, n):
            if adj[u][v] != 0 and labels[u] != labels[v]:
                cross_edges.append((u, v))
    return cross_edges


def _greedy_boundary_cover_for_multidomain(cross_edges, labels):
    uncovered = set(cross_edges)
    copy_plan = {}

    # 构建每个节点可覆盖的跨域边
    node_cover_edges = {}
    for u, v in cross_edges:
        node_cover_edges.setdefault(u, set()).add((u, v))
        node_cover_edges.setdefault(v, set()).add((u, v))

    while uncovered:
        best_node = None
        best_gain = -1
        for node, edges in node_cover_edges.items():
            gain = len(edges & uncovered)
            if gain > best_gain:
                best_gain = gain
                best_node = node
        if best_node is None or best_gain <= 0:
            break
        affected = node_cover_edges.get(best_node, set()) & uncovered
        for e in affected:
            u, v = e
            other = v if best_node == u else u
            copy_plan.setdefault(best_node, set()).add(int(labels[other]))
        uncovered -= affected

    return copy_plan


def _build_sub_adjacency(adj, node_list):
    if not node_list:
        return np.zeros((0, 0), dtype=int)
    return adj[np.ix_(node_list, node_list)]


# 1) 先把全网 68 节点自动划分为 3 个域（目标：减少边界 + 降低高频业务跨域）
traffic_demand_matrix = _build_traffic_demand_matrix("Traffic_3000_0.5.csv", adjacency_matrix.shape[0])
domain_node_list, domain_labels = _k_domain_partition(adjacency_matrix, k=3, demand=traffic_demand_matrix)

# 2) 对跨域边做贪心覆盖，仅复制必要边界节点，减少复制数量
cross_edges = _build_cross_domain_edges(adjacency_matrix, domain_labels)
copy_plan = _greedy_boundary_cover_for_multidomain(cross_edges, domain_labels)

domain_node_list_all = []
for d, nodes in enumerate(domain_node_list):
    copied_here = sorted([n for n, dsts in copy_plan.items() if d in dsts and n not in nodes])
    domain_node_list_all.append(nodes + copied_here)

# 边界节点（至少被复制到一个其它域）
boundary_node_list = sorted(copy_plan.keys())

# 3) 域内 + 复制边界 的子图邻接矩阵
domain_adjacency_matrices = [
    _build_sub_adjacency(adjacency_matrix, nodes_all) for nodes_all in domain_node_list_all
]

# 边界子图邻接矩阵（只看边界节点之间的连接）
boundary_adjacency_matrix = _build_sub_adjacency(adjacency_matrix, boundary_node_list)

# 方便一次性使用的列表：
# [0号域子图, 1号域子图, 2号域子图, 边界子图]
adjacency_matrix_all = domain_adjacency_matrices + [boundary_adjacency_matrix]


def print_matrix_with_node_ids(title, node_list, matrix):
    print(f"\n[{title}] 节点编号列表: {node_list}")
    for row_idx, node_id in enumerate(node_list):
        print(f"# {node_id}: {matrix[row_idx].tolist()}")


def print_partition_matrices_for_check():
    """
    按“节点编号 + 每行矩阵值”的方式打印，方便人工核对。
    """
    print("\n========== 3域划分结果 ==========")
    for d, nodes in enumerate(domain_node_list):
        print(f"{d}号域(不含复制): {nodes}")
    print(f"复制边界节点: {boundary_node_list}")
    for d, nodes_all in enumerate(domain_node_list_all):
        copied = [n for n in nodes_all if n not in domain_node_list[d]]
        print(f"{d}号域复制节点: {copied}")
    for d, mat in enumerate(domain_adjacency_matrices):
        print_matrix_with_node_ids(f"{d}号域邻接矩阵(含复制边界)", domain_node_list_all[d], mat)
    print_matrix_with_node_ids("边界子图邻接矩阵", boundary_node_list, boundary_adjacency_matrix)



# 域/边界辅助函数
from collections import deque
def build_node_domains():
    """
    作用：给“每个节点”标注它属于哪个域（或哪些域）。

    这是“跨域业务拆段”的基础：
    - 普通节点只属于 1 个域（例如节点 1 只属于 A 域）
    - 边界节点会同时属于多个域（例如节点 3 同时属于 A 域和 B 域）

    返回两个结构：
    - primary_domain[i]：节点 i 的主域编号(0~4)
    - node_domains[i]：节点 i 所属的所有域集合(set)，边界节点会有多个域
    """
    # 1) 先根据连续编号范围确定主域
    primary_domain = {}
    for d, nodes in enumerate(domain_node_list):#enumerate:遍历列表的时候，同时拿到索引和nodes(节点列表)。
        for n in nodes:
            primary_domain[n] = d #记录哪个节点在哪个域

    # 2) 初始每个节点只属于自己的主域
    node_domains = {n: {d} for n, d in primary_domain.items()}
    """node_domains = {
      0: {0},    # 节点0 当前只属于域0
      1: {0},
      ...
      14: {1},   # 节点14 当前只属于域1
   ...
  }
      """

    # 3) 再根据 “域内+边界” 列表补充归属,让边界节点同时属于多个域
    for d, nodes_all in enumerate(domain_node_list_all):
        for n in nodes_all:
            node_domains.setdefault(n, set()).add(d)

    # 4) 字典转成列表便于直接通过下标访问
    max_node = max(node_domains.keys())
    primary_domain_list = [primary_domain.get(i, -1) for i in range(max_node + 1)]

    return primary_domain_list, node_domains


def shortest_path_global(src, dest):
    """
    作用：先在“全网拓扑”上找一条 src -> dest 的路径。

    - 使用 BFS
    - 输出是一个节点序列，例如 [1, 3, 2]。

    注意：这里的路径只用于后续“按域切段”，不直接做波长分配。
    """
    if src == dest:
        return [src]#直接快速返回，不用再跑下面的 BFS

    n = len(adjacency_matrix)
    if src < 0 or dest < 0 or src >= n or dest >= n:
        return []

    visited = [False] * n
    prev = [-1] * n
    q = deque()

    visited[src] = True
    q.append(src)
#BFS
    while q:
        u = q.popleft()
        row = adjacency_matrix[u]
        for v in range(n):
            if row[v] != 0 and not visited[v]:
                visited[v] = True
                prev[v] = u
                if v == dest:
                    q.clear()
                    break
                q.append(v)

    if not visited[dest]:
        return []


    path = []
    cur = dest
    while cur != -1:
        path.append(cur)
        cur = prev[cur]
    path.reverse()
    return path


def split_path_by_domain(path):
    """
    作用：把“全网路径”拆成多个“域内子路径段”。
    - 节点 1 在 A 域，节点 2 在 B 域，它们跨域
    - 如果路径里存在边界节点 3（同时属于 A 和 B）
    - 那么把跨域业务拆成两个域内段：
        A 域内段：[1, 3]
        B 域内段：[3, 2]
    拆段规则：
    - 沿着 path 从头走
    - 只要“下一跳还在同一个域里”，就继续放在当前段
    - 一旦发现“下一跳不在当前段所属域”，就在前一个节点切断
      （前一个节点通常就是边界节点，用它作为接力点开启下一段）
    - 中间跨多个域时，同样会切出多段，逐段接力

    返回:
        segments: 形如
        [
          {'domain': 0, 'nodes': [1, 3]},
          {'domain': 1, 'nodes': [3, 2]},
          ...
        ]
    """
    if not path:
        return []

    primary_domain_list, node_domains = build_node_domains()
    #一个是列表下标是节点号，值是主域编号，，node_domains[n] 是一个“域集合”


    segments = []#初始化一个空列表，后面要把“分段后的路径”（每一段一个 segment）存进去

    # 当前 segment 的节点和“候选域集合”
    cur_nodes = [path[0]]
    #如果 path[0] = 3，并且 node_domains[3] = {0, 1}（边界节点），那么执行完这一句：candidate_domains = {0, 1}
    candidate_domains = set(node_domains.get(path[0], set()))

#这三行是在从第二个节点开始，依次拿出这条路径上的每一个节点，并查它属于哪些域。↓
    for idx in range(1, len(path)):
        v = path[idx]
        v_domains = node_domains.get(v, set())

        # 1) 就是把“当前这段已有节点可能属于的域”（candidate_domains）
        # 和“新节点 v 能属于的域”（v_domains）做一个交集：
        # 还留在交集里的域，就是“这段路径到目前为止仍然共同属于的域”。
        # 如果交集变成空了，就说明要跨域了，需要在前一个节点切断，开启新的子段。
        new_candidates = candidate_domains & v_domains
        if new_candidates:
            cur_nodes.append(v)
            candidate_domains = new_candidates
            continue

        # 2) 否则需要切断，先把当前节点的前一个节点拿出来
        last_node = path[idx - 1]

        # 当要把上一段切出来时，就看看这段路径目前还能属于哪些域，
        # 如果有多个，就挑编号最小的那个做为这段的域编号；如果实在算不出来，就用最后一个节点的主域兜底。
        if not candidate_domains:
            last_domain = primary_domain_list[last_node] if last_node < len(primary_domain_list) else -1
        else:
            last_domain = min(candidate_domains)

        #cur_nodes：当前这段路径里的所有节点，比如 [1, 3]；
        #last_domain：刚才算出来“这一段属于哪个域”，比如 0（A 域）。
        segments.append({
            'domain': last_domain,
            'nodes': cur_nodes,
        })

        # 3) 新一段从 last_node 与当前节点 v 的共同域开始


        last_domains = node_domains.get(last_node, set())
        candidate_domains = last_domains & v_domains#last_node和v共同能属于哪些域？
        # 这就变成了新一段路径的“候选域集合”（candidate_domains），后面如果再加新节点，还会继续在这个集合里往下缩小

        if not candidate_domains:
            # 理论上,lastnode和v一个共同域没有按理说不可能
            # 这里做一个兜底: 把 v 作为新 segment 的单独起点。
            cur_nodes = [v]
            candidate_domains = set(v_domains)
        else:
            # last_node 是边界节点,同时属于两个域,作为交接点
            cur_nodes = [last_node, v]#新的这个域内子业务段，从 last_node 走到 v 开始算，

    # 用当前段的最后一个节点和候选域，确定这一段的域号，把这一段（域 + 节点列表）加入 segments，最后把所有分段结果 segments 返回
    last_node = cur_nodes[-1]#last_node = 当前这段的结尾节点
    if not candidate_domains:
        last_domain = primary_domain_list[last_node] if last_node < len(primary_domain_list) else -1
    else:
        last_domain = min(candidate_domains)

    segments.append({
        'domain': last_domain,
        'nodes': cur_nodes,
    })

    return segments#最后返回 segments，就是整个“跨域业务拆分成多个域内子业务段”的结果。


#这个函数返回“全网路径”和“按域拆好的子路径段”两个结果。
def route_with_domain_segments(src, dest):

    path = shortest_path_global(src, dest) #这个函数：在全网邻接矩阵上，用 BFS 算出一条从 src 到 dest 的路径
    segments = split_path_by_domain(path) if path else []#把这条全网路径按边界节点拆成多个域内子路径段。
    return path, segments

if __name__ == "__main__":
    print_partition_matrices_for_check()