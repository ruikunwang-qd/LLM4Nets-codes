import AuGraph
import Database
import Service
import Dijkstra
import Compute

ser_route_list = []  # ser_route_list[i] 对应第 i 个业务（或子业务段）的路由结果
au_edge_collection = []  # au_edge_collection[i] 就是第 i 个业务（或子业务段）在辅助图上的边集合，方便后面统计或调试。


def _classify_block_reason(au_src, au_dest):
    inf = AuGraph.Inf
    row_src = AuGraph.au_graph_weight[au_src]
    src_has_out = any((j != au_src) and (w != inf) for j, w in enumerate(row_src))
    if not src_has_out:
        return "SRC_NO_OUT_EDGE"

    dst_has_in = False
    for i in range(len(AuGraph.au_graph_weight)):
        if i != au_dest and AuGraph.au_graph_weight[i][au_dest] != inf:
            dst_has_in = True
            break
    if not dst_has_in:
        return "DST_NO_IN_EDGE"

    return "NO_FEASIBLE_PATH_IN_AUX"


def route_wave_assign(weight, index, return_reason=False):
    """
    不分域的情况下，对每一条业务调用 route_wave_assign，
    它会在全网辅助图上跑一次 Dijkstra，
    给这条业务选一条路、分配波长，并更新全网的波长占用情况，同时返回当前累计用了多少条波长链路。
    """
    job_fail = 0  # 失败业务
    # AuGraph.au_graph_init(weight)
    # Service.generate_service()  # 产生业务

    service = Service.service_list[index]
    # 业务信息
    ser_id = service['id']
    ser_src = service['src']
    ser_dest = service['dest']
    ser_traffic = service['traffic']  # 是数组
    # print('ser_traffic', ser_traffic)

    # 将源目节点的编号转换为辅助图上的节点的编号
    au_src = ser_src * AuGraph.layer * 2 + AuGraph.layer
    au_dest = ser_dest * AuGraph.layer * 2

    # 添加满足容量需求的光路边
    AuGraph.add_edge(AuGraph.links_virtual_list, ser_traffic, weight)

    # 计算最短路，并添加到路由集合中
    route_tmp = Dijkstra.dijkstra(AuGraph.au_graph_weight, au_src, au_dest, ser_id)

    # 删除添加的光路边
    AuGraph.delete_edge()

    if route_tmp:
        ser_route_list.append(route_tmp)
        au_edges = AuGraph.edge_convert(route_tmp)
        au_edges = AuGraph.update_au_graph(au_edges, service)
        au_edge_collection.append(au_edges)
        service['condition'] = True
        # 性能关键：不要每个业务都全量扫描 links_physical
        wave_used = Compute.get_wave_used_count()  # 部署完当前业务后，所有使用的波长数量（增量统计）
        virtual_hop_num = Compute.compute_hop(route_tmp)  # 虚拟拓扑跳数
        if return_reason:
            return True, wave_used, au_edge_collection, "SUCCESS"
        return True, wave_used, au_edge_collection
    else:
        service['condition'] = False
        job_fail += 1
        au_edge_collection.append([])
        ser_route_list.append([])
        # 失败业务不应把“累计已使用波长链路数”清零；应返回当前累计值（保持单调不减）
        reason = _classify_block_reason(au_src, au_dest)
        if return_reason:
            return False, Compute.get_wave_used_count(), au_edge_collection, reason
        return False, Compute.get_wave_used_count(), au_edge_collection


def route_wave_assign_segment(weight, service, return_reason=False):
    """
    域内“子业务段”入口（分域+拆段后会用到）：

    为什么要有它：
    - 原始函数 route_wave_assign(...) 必须按 index 去 Service.service_list 取业务；
    - 但我们把一条跨域业务拆成了多个“域内子业务段”，这些段不是原始 service_list 里的业务；
    - 所以新增这个函数，允许直接传入一个业务字典 service 来执行。

    参数 service 的格式（和原业务一致，只是 src/dest 变成了“子段”的首尾节点）：
        {
            'id':     子业务段的 id（用于打印/调试/汇报）,
            'src':    子业务段起点节点,
            'dest':   子业务段终点节点,
            'traffic': 流量向量(list),
        }
    函数内部做的事情和 route_wave_assign 基本一样：
    - 在辅助图上找最短路
    - 更新虚拟链路/物理链路容量
    - 返回当前累计激活波长数（Compute.get_wave_used_count）
    """
    job_fail = 0

    ser_id = service['id']
    ser_src = service['src']
    ser_dest = service['dest']
    ser_traffic = service['traffic']

    # 将源目节点的编号转换为辅助图上的节点的编号
    au_src = ser_src * AuGraph.layer * 2 + AuGraph.layer
    au_dest = ser_dest * AuGraph.layer * 2

    # 添加满足容量需求的光路边
    AuGraph.add_edge(AuGraph.links_virtual_list, ser_traffic, weight)

    # 计算最短路，并添加到路由集合中
    route_tmp = Dijkstra.dijkstra(AuGraph.au_graph_weight, au_src, au_dest, ser_id)

    # 删除添加的光路边
    AuGraph.delete_edge()

    if route_tmp:
        ser_route_list.append(route_tmp)
        au_edges = AuGraph.edge_convert(route_tmp)
        au_edges = AuGraph.update_au_graph(au_edges, service)
        au_edge_collection.append(au_edges)
        service['condition'] = True
        wave_used = Compute.get_wave_used_count()
        virtual_hop_num = Compute.compute_hop(route_tmp)
        if return_reason:
            return True, wave_used, au_edge_collection, "SUCCESS"
        return True, wave_used, au_edge_collection
    else:
        service['condition'] = False
        job_fail += 1
        au_edge_collection.append([])
        ser_route_list.append([])
        reason = _classify_block_reason(au_src, au_dest)
        if return_reason:
            return False, Compute.get_wave_used_count(), au_edge_collection, reason
        return False, Compute.get_wave_used_count(), au_edge_collection
