import AuOdlConvert
import Compute
import Service
import Database
import AuGraph
import RWA
import graph  # 域划分与边界节点信息
import numpy as np
import time
import multiprocessing as mp

ENABLE_N_CURVE = False
# 业务数量 N=100..3000 采样点（用于业务数量-激活波长数/折线图）
N_POINTS = [100, 200, 300, 400, 500, 600, 700, 800, 900, 1000, 1500, 2000, 2500, 3000]


def run_global_baseline_for_n(n):
    """不分域：从零开始处理前 n 条业务，返回 (激活波长总数, 运行时间)。"""
    import time as _time

    start_t = _time.time()
    Database.clear(Database.links_physical)
    Compute.init_wavelength_tracker(Database.node_number, Database.wavelength_number)
    AuGraph.links_virtual_list.clear()

    for i in range(n):
        if i == 0:
            AuGraph.au_graph_init(AuGraph.edge_weight)
        else:
            AuGraph.update_au_graph_weight(AuGraph.edge_weight)
        RWA.route_wave_assign(AuGraph.edge_weight, i)

    total_wave = Compute.get_wave_used_count()
    elapsed = _time.time() - start_t
    return total_wave, elapsed


def run_domain_parallel_for_n(base_services, n):
    """分域：从零开始处理前 n 条业务（拆段 + 5 域并行），返回 (激活波长总数(5域求和), 墙钟时间)。"""
    import time as _time

    parallel_start = _time.time()

    domain_to_seg_services = {0: [], 1: [], 2: [], 3: [], 4: []}
    for base_service in base_services[:n]:
        ser_id = base_service['id']
        src = base_service['src']
        dest = base_service['dest']
        traffic = base_service['traffic']

        full_path, segments = graph.route_with_domain_segments(src, dest)
        if not full_path or not segments:
            continue

        for seg_idx, seg in enumerate(segments):
            seg_nodes = seg['nodes']
            seg_domain = seg['domain']
            seg_src = seg_nodes[0]
            seg_dest = seg_nodes[-1]

            seg_service = {
                'id': f"{ser_id}_seg{seg_idx}_D{seg_domain}",
                'ser_id': ser_id,
                'src': seg_src,
                'dest': seg_dest,
                'traffic': traffic.copy(),
            }
            if seg_domain in domain_to_seg_services:
                domain_to_seg_services[seg_domain].append(seg_service)

    tasks = []
    for d in range(5):
        segs = domain_to_seg_services[d]
        if segs:
            tasks.append((d, segs))

    with mp.Pool(processes=len(tasks)) as pool:
        results = pool.starmap(run_domain_sim, tasks)

    parallel_time = _time.time() - parallel_start
    total_wave_used = sum(r[3] for r in results)
    return total_wave_used, parallel_time


def run_domain_sim(
    domain_id,
    seg_services,
    domain_edge_weight=None,
    return_lightpath=False,
    return_latency=False,
):
    """run_domain_sim 就是：“在一个单独进程里，把某个域的所有子业务段跑完” 的函数。
    主进程会为每个域各开一个进程，并发调用这个函数，达到并行执行"""
    import Database
    import Compute
    import AuGraph
    import RWA
    import graph
    import time as _time

    start_t = _time.time()

    if domain_edge_weight is None:
        domain_edge_weight = Database.get_domain_edge_weight(domain_id)

    """把“全网拓扑”裁剪成“当前域自己的小拓扑”，也就是只保留本域内部的链路，把跨域的链路全关掉。↓"""
    domain_nodes = set(graph.domain_node_list_all[domain_id])
    """从 graph.py 里拿到这个域能看到的所有节点，放到一个集合 domain_nodes 里，方便用 in 判断。"""
    row, col = Database.graph_connect.shape#graph_connect是全网邻接矩阵。
    for i in range(row):
        for j in range(col):
            if (i in domain_nodes) and (j in domain_nodes):
                # 域内链路保留
                continue
            else:
                # 跨域/非本域链路屏蔽掉
                Database.graph_connect[i][j] = 0

    # 在每个域的进程里，先把这个域的物理链路容量、波长使用统计器、虚拟光路列表全部重置。
    Database.clear(Database.links_physical)
    Compute.init_wavelength_tracker(Database.node_number, Database.wavelength_number)
    AuGraph.links_virtual_list.clear()

    wave_used_list = []  # 记录：本域内部累计用了多少条波长链路
    lightpath_used_list = []  # 记录：本域内部累计已建立光路数
    seg_success_list = []  # 记录：每个子业务段是否成功
    seg_reason_list = []  # 记录：每个子业务段失败原因
    seg_latency_list = []  # 记录：每个子业务段的时延(ms)
    seg_elapsed_list = []  # 记录：每个子业务段的运行时间（秒），与 seg_services 一一对应

    if return_latency:
        import delay as delay_mod

        # reset delay module global states（否则多次调用会累积列表）
        delay_mod.latency = []
        delay_mod.is_block = []
        delay_mod.average_latency = [0]
        delay_mod.success_num = [0]
        delay_mod.reject_num = [0]

    # 顺序执行本域内的所有子业务段
    #    这里的 seg_services 同时包含：
    #    - 原本就在本域内的业务
    #    - 原本跨域、但经过边界节点拆分后落到本域的那一段（例如 1-3、3-2）
    for idx, seg_service in enumerate(seg_services):
        seg_start_t = _time.perf_counter()
        if idx == 0:
            AuGraph.au_graph_init(domain_edge_weight)
        else:
            """update_au_graph_weight 相当于在每条业务到来前，
            把辅助图里的边权重按当前资源状态刷新一遍，
            让后续的 Dijkstra 路由总是基于最新的网络负载情况进行选择"""
            AuGraph.update_au_graph_weight(domain_edge_weight)
#调用域内子业务调度函数,
# domain_edge_weight：各种边的权重配置。seg_service：当前子业务段的信息（只有这一段的 src、dest、traffic）
        flag, wave_used, au_edges_list, reason = RWA.route_wave_assign_segment(
            domain_edge_weight, seg_service, return_reason=True
        )
        wave_used_list.append(wave_used)
        lightpath_used_list.append(len(AuGraph.links_virtual_list))
        seg_success_list.append(bool(flag))
        seg_reason_list.append(reason)

        if return_latency:
            seg_latency, _avg_latency = delay_mod.compute_latency(flag, au_edges_list)
            seg_latency_list.append(seg_latency)
        seg_elapsed_list.append(_time.perf_counter() - seg_start_t)

    #  本域的最终激活波长数
    domain_total_wave = Compute.get_wave_used_count()
    # 域内运行时间
    elapsed = _time.time() - start_t
    domain_total_lightpath = len(AuGraph.links_virtual_list)
    # 每个子业务段对应的原始业务编号，与 wave_used_list 一一对应，用于主进程按业务合并统计
    ser_id_list = [seg['ser_id'] for seg in seg_services]

    if return_lightpath:
        return (
            domain_id,
            wave_used_list,
            ser_id_list,
            domain_total_wave,
            elapsed,
            seg_elapsed_list,
            domain_total_lightpath,
            lightpath_used_list,
            seg_success_list,
            seg_reason_list,
            seg_latency_list if return_latency else [],
        )

    return domain_id, wave_used_list, ser_id_list, domain_total_wave, elapsed, seg_elapsed_list


if __name__ == "__main__":


    # 读traffic1000，生成id，src, dest, traffic，然后放进全局的 Service.service_list 里
    Service.generate_service(0, Database.time)

    # 为“业务数量-时间/波长”折线图准备采样点，只跑一次 1000 条业务，在这一次里记录
    n_curve_points = [n for n in N_POINTS if n <= Database.job_number]
    n_curve_set = set(n_curve_points)
    global_time_curve_n = []   # 不分域：在处理完 N 条业务时的累计时间
    global_wave_curve_n = []   # 不分域：在处理完 N 条业务时的激活波长总数
    parallel_wave_curve_n = [] # 分域：在处理完 N 条业务时的激活波长总数（按原始业务合并）
    global_per_service_times = []  # 不分域：每条业务耗时


    # 1.1 不分域(全网)基线: 激活波长数 + 运行时间
    # 这段是对照组：不做分域/拆段，直接按原算法顺序处理全部业务。
    global_start = time.time()

    # 物理链路 & 统计器初始化
    Database.clear(Database.links_physical)
    Compute.init_wavelength_tracker(Database.node_number, Database.wavelength_number)
    AuGraph.links_virtual_list.clear()

    wave_used_list_global = []

    for i in range(Database.job_number):
        t0 = time.perf_counter()
        if i == 0:
            AuGraph.au_graph_init(AuGraph.edge_weight)
        else:
            AuGraph.update_au_graph_weight(AuGraph.edge_weight)

        flag, wave_used, au_edges_list = RWA.route_wave_assign(AuGraph.edge_weight, i)
        wave_used_list_global.append(wave_used)
        global_per_service_times.append(time.perf_counter() - t0)

        # 在同一次 1000 业务仿真中，对指定 N 采样“累计时间/波长”
        cur_n = i + 1
        if cur_n in n_curve_set:
            elapsed_now = time.time() - global_start
            global_time_curve_n.append(elapsed_now)
            # 这里的 wave_used 代表“处理到当前业务后的激活波长总数”
            global_wave_curve_n.append(wave_used)

    global_total_wave = Compute.get_wave_used_count()
    global_time = time.time() - global_start

    print(f"[全网基线] 激活波长总数: {global_total_wave}")
    print(f"[全网基线] 总运行时间: {global_time:.2f} 秒")


    # 2按域划分 + 边界节点切分业务 + 并行执行整体计时
    # 从这里开始计时：包含“拆段 + 并行执行”的整体耗时。
    parallel_start = time.time()


    # 作用：把“拆出来的子业务段”按域放进对应的列表
    domain_to_seg_services = {0: [], 1: [], 2: [], 3: [], 4: []}

    for base_service in Service.service_list:
        ser_id = base_service['id']
        src = base_service['src']
        dest = base_service['dest']
        traffic = base_service['traffic']

        # 对每条原始业务，先在全网维度上路由并按域拆分。如果这一条业务在全网里都找不到路就跳过，不参与后面的分域并行计算
        full_path, segments = graph.route_with_domain_segments(src, dest)
        if not full_path or not segments:
            continue
        #把一条原始业务拆出来的每一段域内子路径逐个取出来，拿到它属于哪个域、包含哪些节点，给后面构造成子业务用。
        for seg_idx, seg in enumerate(segments):
            seg_nodes = seg['nodes']
            seg_domain = seg['domain']

            seg_src = seg_nodes[0]
            seg_dest = seg_nodes[-1]

            # 把“域内路径段”变成一个可执行的子业务段：只保留段的首尾节点，流量向量沿用原业务。
            # ser_id 用于后续按“原始业务”合并统计，使分域曲线与不分域在业务数量上可比
            seg_service = {
                'id': f"{ser_id}_seg{seg_idx}_D{seg_domain}",
                'ser_id': ser_id,
                'src': seg_src,
                'dest': seg_dest,
                'traffic': traffic.copy(),
            }
            # 按域把子业务放进对应的域里
            if seg_domain in domain_to_seg_services:
                domain_to_seg_services[seg_domain].append(seg_service)

    # 5 个域并行执行
    #    这里使用多进程：每个域一个进程，同时运行 run_domain_sim。
    tasks = []
    # 把分到该域的子业务加到任务列表
    for d in range(5):
        segs = domain_to_seg_services[d]
        if segs:
            tasks.append((d, segs))

    baseline_domain_edge_weights = {d: Database.get_domain_edge_weight_baseline(d) for d in range(5)}

    tasks_baseline = [(d, segs, baseline_domain_edge_weights[d]) for (d, segs) in tasks]
    with mp.Pool(processes=len(tasks_baseline)) as pool:
        results = pool.starmap(run_domain_sim, tasks_baseline)

    parallel_time = time.time() - parallel_start


    # 汇总结果: 激活波长总数 + CSV + 按原始业务合并的曲线数据
    # 每个域返回: (domain_id, wave_list, ser_id_list, domain_total_wave, elapsed, seg_elapsed_list)
    all_wave_used_list = []
    total_wave_used = 0
    domain_wave_lists = []   # 各域的 wave_list
    domain_ser_id_lists = [] # 各域的 ser_id_list，与 wave_list 一一对应
    domain_elapsed_list = [] # 各域域内运行时间，用于业务数量_时间箱线图
    domain_seg_elapsed_lists = []  # 各域子段耗时列表，与 ser_id_list 一一对应
    for domain_id, wave_list, ser_id_list, domain_total_wave, elapsed, seg_elapsed_list in results:
        all_wave_used_list.extend(wave_list)
        total_wave_used += domain_total_wave
        domain_wave_lists.append(wave_list)
        domain_ser_id_lists.append(ser_id_list)
        domain_elapsed_list.append(elapsed)
        domain_seg_elapsed_lists.append(seg_elapsed_list)
        print(f"域 {domain_id} 结束: 激活波长数 = {domain_total_wave}, 域内运行时间 = {elapsed:.2f} 秒")

    # 按“原始业务”合并：对每条业务 k (0..999)，统计“处理完属于前 k 条业务的所有子段后”的激活波长总数（五域求和）
    job_number = Database.job_number
    wave_used_by_business = []
    for k in range(job_number):
        total_k = 0
        for wave_list, ser_id_list in zip(domain_wave_lists, domain_ser_id_lists):
            # 在该域中，找到属于业务 0..k 的最后一个子段的下标
            i_last = -1
            for j, sid in enumerate(ser_id_list):
                if sid <= k:
                    i_last = j
            if i_last >= 0:
                total_k += wave_list[i_last]
        wave_used_by_business.append(total_k)

    # 按“原始业务”合并：每条业务的运行时间 = 拆段后各子段耗时求和（跨域业务会落在多个域）
    domain_per_service_times = [0.0 for _ in range(job_number)]
    for ser_id_list, seg_elapsed_list in zip(domain_ser_id_lists, domain_seg_elapsed_lists):
        for sid, dt in zip(ser_id_list, seg_elapsed_list):
            if 0 <= int(sid) < job_number:
                domain_per_service_times[int(sid)] += float(dt)

    # 使用同一趟分域仿真结果，为 N=100,200,... 构造“分域激活波长数”折线
    for n in n_curve_points:
        if n <= len(wave_used_by_business):
            parallel_wave_curve_n.append(wave_used_by_business[n - 1])
        else:
            parallel_wave_curve_n.append(wave_used_by_business[-1])
    print(f"[按域并行] 激活波长总数(5个域求和): {total_wave_used}")
    # 这里的时间 = 拆段耗时 + 并行执行耗时（不包含上面的全网基线）。
    print(f"[按域并行] 总运行时间(并行整体运行时间): {parallel_time:.2f} 秒")

    if ENABLE_N_CURVE:
        pass