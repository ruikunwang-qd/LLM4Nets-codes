import Database
import graph
from scenario_csv_runner import run_scenario
from latency_runner import (
    compute_domain_latency_curve,
    export_domain_ratio_latency_csv,
    export_latency_csv,
)


CHATGPT_DOMAIN_WEIGHTS = {
    0: [0, 0, 800, 800, 860, 140, 140, 5],
    1: [0, 0, 760, 760, 840, 130, 130, 6],
    2: [0, 0, 780, 780, 850, 135, 135, 5],
    3: [0, 0, 760, 760, 835, 130, 130, 6],
    4: [0, 0, 770, 770, 845, 132, 132, 6],
}
"""DEEPSEEK_DOMAIN_WEIGHTS = {
    0:  [0, 0, 520, 520, 1000, 200, 200, 150],
    1:  [0, 0, 540, 540, 1000, 210, 210, 160],
    2:  [0, 0, 500, 500, 1000, 190, 190, 140],
    3:  [0, 0, 560, 560, 1000, 220, 220, 170],
    4:  [0, 0, 510, 510, 1000, 195, 195, 145],
}"""


if __name__ == "__main__":
    domain_count = len(graph.domain_node_list_all)
    selected_weights = [CHATGPT_DOMAIN_WEIGHTS[d] for d in sorted(CHATGPT_DOMAIN_WEIGHTS.keys())[:domain_count]]
    domain_edge_weight_by_id = {
        d: Database.to_augraph_edge_weight(w)
        for d, w in enumerate(selected_weights)
    }
    run_scenario(
        scenario_name="分四域_ChatGPTweights",
        business_csv_out="分四域_ChatGPTweights_业务请求数_已激活波长总数.csv",
        ratio_csv_out="分四域_ChatGPTweights_域间业务占比_已激活波长总数.csv",
        business_lightpath_csv_out="分四域_ChatGPTweights_业务请求数-已建立的光路数.csv",
        ratio_lightpath_csv_out="分四域_ChatGPTweights_域间业务占比-已激活的光路数.csv",
        ratio_blocking_csv_out="分四域_ChatGPTweights_域间业务占比_成功率阻塞率.csv",
        global_weight=None,
        domain_edge_weight_by_id=domain_edge_weight_by_id,
    )

    traffic_csv = "Traffic_3000_0.5.csv"
    out_latency_csv = "分四域_ChatGPTweights_业务请求数-时延ms.csv"
    print("[分四域_ChatGPTweights] 开始计算时延...")
    latency_curve, business_success, latency_stats = compute_domain_latency_curve(
        traffic_csv, domain_edge_weight_by_id, progress_every=50
    )
    export_latency_csv(traffic_csv, latency_curve, out_latency_csv)
    print("[分四域_ChatGPTweights] 时延统计:", latency_stats)

    out_ratio_latency_csv = "分四域_ChatGPTweights_域间业务占比-时延ms.csv"
    print("[分四域_ChatGPTweights] 开始输出域间占比-时延（6 个占比场景）...")
    export_domain_ratio_latency_csv(
        domain_edge_weight_by_id, out_ratio_latency_csv, progress_every=50
    )