import numpy as np
import pandas as pd

# 导入邻接矩阵（全网 68 节点）
adjacency_matrix = pd.read_csv("csv格式中讯拓扑邻接矩阵_68.csv", header=None)
adjacency_matrix = adjacency_matrix.fillna(0)
adjacency_matrix = np.array(adjacency_matrix, dtype=int)
PARTITION_DEMAND_WEIGHT = 0.54
PARTITION_CUT_W_TOPO = 1.0
PARTITION_CUT_W_DEMAND = 1.9

NUM_DOMAINS = 4


def _build_traffic_demand_matrix(csv_path, node_count):
    """
    根据业务CSV构造节点对业务需求矩阵（无向累加）。
    """
    try:
        df = pd.read_csv(csv_path, engine="python")
    except Exception:
        return np.zeros((node_count, node_count), dtype=float)

    demand = np.zeros((node_count, node_count), dtype=float)
    if "src" not in df.columns or "dst" not in df.columns:
        return demand

    for s, d in zip(df["src"], df["dst"]):
        s_i = int(s)
        d_i = int(d)
        if 0 <= s_i < node_count and 0 <= d_i < node_count and s_i != d_i:
            demand[s_i][d_i] += 1.0
            demand[d_i][s_i] += 1.0
    return demand


def _objective_for_partition(
    adj, in_domain0, demand=None, cut_w_topo=1.0, cut_w_demand=4.0
):
    n = len(in_domain0)
    boundary_nodes = 0
    cut_topo_edges = 0
    cut_demand = 0.0
    for i in range(n):
        has_cross = False
        for j in range(i + 1, n):
            if adj[i][j] == 0:
                if demand is None:
                    continue
            if in_domain0[i] != in_domain0[j]:
                if adj[i][j] != 0:
                    cut_topo_edges += 1
                    has_cross = True
                if demand is not None and demand[i][j] > 0:
                    cut_demand += float(demand[i][j])
                    has_cross = True
        if not has_cross:
            for j in range(0, i):
                cross = False
                if adj[i][j] != 0 and in_domain0[i] != in_domain0[j]:
                    cross = True
                if (
                    demand is not None
                    and demand[i][j] > 0
                    and in_domain0[i] != in_domain0[j]
                ):
                    cross = True
                if cross:
                    has_cross = True
                    break
        if has_cross:
            boundary_nodes += 1
    return (
        boundary_nodes,
        cut_w_topo * cut_topo_edges + cut_w_demand * cut_demand,
        cut_topo_edges,
        cut_demand,
    )


def _two_domain_partition(
    adj,
    demand=None,
    demand_weight=None,
    cut_w_topo=None,
    cut_w_demand=None,
):
    """在整张邻接矩阵上二划分（节点编号为 0..n-1）。"""
    if demand_weight is None:
        demand_weight = PARTITION_DEMAND_WEIGHT
    if cut_w_topo is None:
        cut_w_topo = PARTITION_CUT_W_TOPO
    if cut_w_demand is None:
        cut_w_demand = PARTITION_CUT_W_DEMAND

    n = adj.shape[0]
    if demand is None:
        demand = np.zeros((n, n), dtype=float)
    if np.max(demand) > 0:
        demand_norm = demand / np.max(demand)
    else:
        demand_norm = demand
    combined = adj.astype(float) + float(demand_weight) * demand_norm

    degrees = np.sum(combined, axis=1)
    lap = np.diag(degrees) - combined
    eigvals, eigvecs = np.linalg.eigh(lap)
    fiedler = eigvecs[:, 1] if n > 1 else np.array([0.0])

    order = np.argsort(fiedler)
    split = n // 2
    in_domain0 = np.zeros(n, dtype=bool)
    in_domain0[order[:split]] = True

    if np.all(in_domain0) or not np.any(in_domain0):
        in_domain0[:] = False
        in_domain0[:split] = True

    improved = True
    while improved:
        improved = False
        base_obj = _objective_for_partition(
            adj, in_domain0, demand=demand, cut_w_topo=cut_w_topo, cut_w_demand=cut_w_demand
        )
        for node in range(n):
            if in_domain0[node] and np.sum(in_domain0) <= 1:
                continue
            if (not in_domain0[node]) and np.sum(~in_domain0) <= 1:
                continue
            in_domain0[node] = ~in_domain0[node]
            new_obj = _objective_for_partition(
                adj, in_domain0, demand=demand, cut_w_topo=cut_w_topo, cut_w_demand=cut_w_demand
            )
            if new_obj < base_obj:
                base_obj = new_obj
                improved = True
            else:
                in_domain0[node] = ~in_domain0[node]

    domain0 = sorted(np.where(in_domain0)[0].tolist())
    domain1 = sorted(np.where(~in_domain0)[0].tolist())
    return domain0, domain1


def _two_domain_partition_on_subset(adj, demand, node_indices):
    """
    仅在 node_indices 诱导子图上做二划分，返回两侧的全局节点编号列表。
    """
    node_indices = sorted(node_indices)
    if len(node_indices) <= 1:
        return node_indices, []

    sub_adj = adj[np.ix_(node_indices, node_indices)]
    sub_dem = demand[np.ix_(node_indices, node_indices)]
    loc0, loc1 = _two_domain_partition(sub_adj, demand=sub_dem)
    g0 = [node_indices[i] for i in loc0]
    g1 = [node_indices[i] for i in loc1]
    return g0, g1


def _four_domain_recursive_partition(adj, demand):
    """递归谱二分：先两半，再各二分 → 共 4 域。"""
    n = adj.shape[0]
    all_nodes = list(range(n))
    left, right = _two_domain_partition_on_subset(adj, demand, all_nodes)
    p0, p1 = _two_domain_partition_on_subset(adj, demand, left)
    p2, p3 = _two_domain_partition_on_subset(adj, demand, right)
    return [sorted(p0), sorted(p1), sorted(p2), sorted(p3)]


def _build_cross_edges(adj, domain0_set, domain1_set):
    cross_edges = []
    for u in domain0_set:
        for v in domain1_set:
            if adj[u][v] != 0:
                cross_edges.append((u, v))
    return cross_edges


def _minimum_vertex_cover_on_cut_graph(cross_edges, left_nodes, right_nodes):
    # Hopcroft-Karp: 求最大匹配（左域->右域）
    adj_list = {u: [] for u in left_nodes}
    for u, v in cross_edges:
        adj_list[u].append(v)

    left_match = {u: None for u in left_nodes}
    right_match = {v: None for v in right_nodes}
    dist = {}

    from collections import deque

    def bfs():
        q = deque()
        for u in left_nodes:
            if left_match[u] is None:
                dist[u] = 0
                q.append(u)
            else:
                dist[u] = -1
        found = False
        while q:
            u = q.popleft()
            for v in adj_list[u]:
                mu = right_match[v]
                if mu is None:
                    found = True
                elif dist[mu] == -1:
                    dist[mu] = dist[u] + 1
                    q.append(mu)
        return found

    def dfs(u):
        for v in adj_list[u]:
            mu = right_match[v]
            if mu is None or (dist.get(mu, -1) == dist[u] + 1 and dfs(mu)):
                left_match[u] = v
                right_match[v] = u
                return True
        dist[u] = -1
        return False

    while bfs():
        for u in left_nodes:
            if left_match[u] is None:
                dfs(u)

    # Konig: 由最大匹配导出最小点覆盖
    visited_left = set()
    visited_right = set()
    q = deque([u for u in left_nodes if left_match[u] is None])
    visited_left.update(q)

    while q:
        u = q.popleft()
        for v in adj_list[u]:
            if v in visited_right:
                continue
            if left_match[u] != v:
                visited_right.add(v)
                mu = right_match[v]
                if mu is not None and mu not in visited_left:
                    visited_left.add(mu)
                    q.append(mu)

    cover_left = set(left_nodes) - visited_left
    cover_right = visited_right
    return cover_left | cover_right


def _pairwise_min_cover_copies(adj, domain_node_lists):
    """
    对每一对域 (i,j)，在跨域拓扑边上取二分图最小点覆盖，
    将覆盖点复制到对侧域子图（与二域情形一致，推广到多域）。
    """
    k = len(domain_node_lists)
    copies = [set() for _ in range(k)]
    primary_label = {}
    for d, nodes in enumerate(domain_node_lists):
        for u in nodes:
            primary_label[u] = d

    union_cover = set()
    for d1 in range(k):
        for d2 in range(d1 + 1, k):
            s1 = domain_node_lists[d1]
            s2 = domain_node_lists[d2]
            cross_edges = _build_cross_edges(adj, set(s1), set(s2))
            if not cross_edges:
                continue
            cover = _minimum_vertex_cover_on_cut_graph(cross_edges, s1, s2)
            union_cover |= cover
            for u in cover:
                pu = primary_label[u]
                if pu == d1:
                    copies[d2].add(u)
                elif pu == d2:
                    copies[d1].add(u)
    return copies, union_cover


def _build_sub_adjacency(adj, node_list):
    if not node_list:
        return np.zeros((0, 0), dtype=int)
    return adj[np.ix_(node_list, node_list)]


def _count_cut_topo_edges(adj, domain_node_lists):
    k = len(domain_node_lists)
    labels = [-1] * adj.shape[0]
    for d, nodes in enumerate(domain_node_lists):
        for u in nodes:
            labels[u] = d
    c = 0
    n = adj.shape[0]
    for i in range(n):
        for j in range(i + 1, n):
            if adj[i][j] != 0 and labels[i] >= 0 and labels[j] >= 0 and labels[i] != labels[j]:
                c += 1
    return c


def _cross_topo_edge_count_matrix(adj, domain_node_lists):
    k = len(domain_node_lists)
    mat = [[0] * k for _ in range(k)]
    for d1 in range(k):
        for d2 in range(d1 + 1, k):
            c = len(
                _build_cross_edges(
                    adj, set(domain_node_lists[d1]), set(domain_node_lists[d2])
                )
            )
            mat[d1][d2] = c
            mat[d2][d1] = c
    return mat
# ---------------------------------------------------------------------------
# 4 域：递归谱二分 + 域对最小点覆盖复制边界
# ---------------------------------------------------------------------------
traffic_demand_matrix = _build_traffic_demand_matrix(
    "Traffic_3000_0.5.csv", adjacency_matrix.shape[0]
)

domain_node_list = _four_domain_recursive_partition(
    adjacency_matrix, traffic_demand_matrix
)

_domain_copies_by_domain, _union_vertex_covers = _pairwise_min_cover_copies(
    adjacency_matrix, domain_node_list
)

domain_node_list_all = [
    sorted(set(domain_node_list[d]) | _domain_copies_by_domain[d])
    for d in range(NUM_DOMAINS)
]

boundary_node_list = sorted(_union_vertex_covers)

domain_adjacency_matrices = [
    _build_sub_adjacency(adjacency_matrix, domain_node_list_all[d])
    for d in range(NUM_DOMAINS)
]

boundary_adjacency_matrix = _build_sub_adjacency(adjacency_matrix, boundary_node_list)

# [0..3 号域子图, 边界子图] —— 与原先结构一致，便于外部一次性取用
adjacency_matrix_all = domain_adjacency_matrices + [boundary_adjacency_matrix]


# ========== 分域结果摘要（便于人工检查是否合理）==========
DOMAIN_PARTITION_SUMMARY = {
    "全网节点数": int(adjacency_matrix.shape[0]),
    "域数量": NUM_DOMAINS,
    "递归谱二分 + 子图内启发式边割/业务割局部搜索": True,
    "域对最小点覆盖(Hopcroft-Karp+König)复制边界": True,
    "参数": {
        "PARTITION_DEMAND_WEIGHT": PARTITION_DEMAND_WEIGHT,
        "PARTITION_CUT_W_TOPO": PARTITION_CUT_W_TOPO,
        "PARTITION_CUT_W_DEMAND": PARTITION_CUT_W_DEMAND,
        "业务需求矩阵来源": "Traffic_3000_0.5.csv",
        "拓扑矩阵来源": "csv格式中讯拓扑邻接矩阵_68.csv",
    },
    "各域主节点数": [len(x) for x in domain_node_list],
    "各域主节点列表": [list(x) for x in domain_node_list],
    "各域复制节点(来自其它域)": [sorted(_domain_copies_by_domain[d]) for d in range(NUM_DOMAINS)],
    "各域含复制后节点数": [len(x) for x in domain_node_list_all],
    "各域含复制后节点列表": [list(x) for x in domain_node_list_all],
    "跨域拓扑边数(主划分)": _count_cut_topo_edges(adjacency_matrix, domain_node_list),
    "域对跨域拓扑边数矩阵_主属域": _cross_topo_edge_count_matrix(
        adjacency_matrix, domain_node_list
    ),
    "最小点覆盖并集节点数": len(boundary_node_list),
    "边界节点列表": list(boundary_node_list),
}


def print_matrix_with_node_ids(title, node_list, matrix):
    print(f"\n[{title}] 节点编号列表: {node_list}")
    for row_idx, node_id in enumerate(node_list):
        print(f"# {node_id}: {matrix[row_idx].tolist()}")


def print_partition_matrices_for_check():
    """
    打印划分摘要与各域（含复制）邻接矩阵行，方便人工核对。
    """
    print("\n========== 4 域划分结果（摘要）==========")
    for k, v in DOMAIN_PARTITION_SUMMARY.items():
        if k == "参数":
            print(f"  {k}: {v}")
        elif k == "域对跨域拓扑边数矩阵_主属域":
            print(f"  {k}:")
            for row in v:
                print(f"    {row}")
        elif isinstance(v, list) and k.startswith("各域"):
            print(f"  {k}:")
            for i, row in enumerate(v):
                print(f"    域{i}: {row}")
        else:
            print(f"  {k}: {v}")

    for d in range(NUM_DOMAINS):
        print_matrix_with_node_ids(
            f"{d}号域邻接矩阵(含复制边界)",
            domain_node_list_all[d],
            domain_adjacency_matrices[d],
        )
    print_matrix_with_node_ids(
        "边界子图邻接矩阵(所有域对最小点覆盖的并集)",
        boundary_node_list,
        boundary_adjacency_matrix,
    )


# 域/边界辅助函数
from collections import deque


def build_node_domains():
    """
    作用：给“每个节点”标注它属于哪个域（或哪些域）。

    这是“跨域业务拆段”的基础：
    - 普通节点只属于 1 个域（例如节点 1 只属于 A 域）
    - 边界节点会同时属于多个域（例如节点 3 同时属于 A 域和 B 域）

    返回两个结构：
    - primary_domain[i]：节点 i 的主域编号(0~NUM_DOMAINS-1)
    - node_domains[i]：节点 i 所属的所有域集合(set)，边界节点会有多个域
    """
    primary_domain = {}
    for d, nodes in enumerate(domain_node_list):
        for n in nodes:
            primary_domain[n] = d

    node_domains = {n: {d} for n, d in primary_domain.items()}

    for d, nodes_all in enumerate(domain_node_list_all):
        for n in nodes_all:
            node_domains.setdefault(n, set()).add(d)

    max_node = max(node_domains.keys())
    primary_domain_list = [primary_domain.get(i, -1) for i in range(max_node + 1)]

    return primary_domain_list, node_domains


def shortest_path_global(src, dest):
    """
    作用：先在“全网拓扑”上找一条 src -> dest 的路径。

    - 使用 BFS
    - 输出是一个节点序列，例如 [1, 3, 2]。

    注意：这里的路径只用于后续“按域切段”，不直接做波长分配。
    """
    if src == dest:
        return [src]

    n = len(adjacency_matrix)
    if src < 0 or dest < 0 or src >= n or dest >= n:
        return []

    visited = [False] * n
    prev = [-1] * n
    q = deque()

    visited[src] = True
    q.append(src)
    while q:
        u = q.popleft()
        row = adjacency_matrix[u]
        for v in range(n):
            if row[v] != 0 and not visited[v]:
                visited[v] = True
                prev[v] = u
                if v == dest:
                    q.clear()
                    break
                q.append(v)

    if not visited[dest]:
        return []

    path = []
    cur = dest
    while cur != -1:
        path.append(cur)
        cur = prev[cur]
    path.reverse()
    return path


def split_path_by_domain(path):
    """
    作用：把“全网路径”拆成多个“域内子路径段”。
    """
    if not path:
        return []

    primary_domain_list, node_domains = build_node_domains()

    segments = []
    cur_nodes = [path[0]]
    candidate_domains = set(node_domains.get(path[0], set()))

    for idx in range(1, len(path)):
        v = path[idx]
        v_domains = node_domains.get(v, set())

        new_candidates = candidate_domains & v_domains
        if new_candidates:
            cur_nodes.append(v)
            candidate_domains = new_candidates
            continue

        last_node = path[idx - 1]

        if not candidate_domains:
            last_domain = (
                primary_domain_list[last_node]
                if last_node < len(primary_domain_list)
                else -1
            )
        else:
            last_domain = min(candidate_domains)

        segments.append(
            {
                "domain": last_domain,
                "nodes": cur_nodes,
            }
        )

        last_domains = node_domains.get(last_node, set())
        candidate_domains = last_domains & v_domains

        if not candidate_domains:
            cur_nodes = [v]
            candidate_domains = set(v_domains)
        else:
            cur_nodes = [last_node, v]

    last_node = cur_nodes[-1]
    if not candidate_domains:
        last_domain = (
            primary_domain_list[last_node]
            if last_node < len(primary_domain_list)
            else -1
        )
    else:
        last_domain = min(candidate_domains)

    segments.append(
        {
            "domain": last_domain,
            "nodes": cur_nodes,
        }
    )

    return segments


def route_with_domain_segments(src, dest):
    path = shortest_path_global(src, dest)
    segments = split_path_by_domain(path) if path else []
    return path, segments


if __name__ == "__main__":
    print_partition_matrices_for_check()
