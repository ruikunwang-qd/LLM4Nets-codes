import numpy as np
import pandas as pd
from networkx.algorithms.connectivity.edge_augmentation import weighted_one_edge_augmentation, \
    weighted_bridge_augmentation

# 网络和业务信息
job_number = 3000              # 业务数量
wavelength_number = 40        # 波长数量
wavelength_capacity = 25     # 单波长容量
time = 24                    # 所有时刻数量（24小时）

# 时延模型（delay.compute_latency）：单位 ms，与「业务请求数-时延ms」CSV 一致；可按论文/设备参数自行修改。

OEO_time = 20 * 1e-3  # 单位ms
fiber_length = 20    # 单位km
v = 2 * 1e5           # 单位km/s
fiber_time = fiber_length/v * 1000  # # 单位ms
weights = [0, 5, 100, 100, 1000, 10, 10, 25]

# 分域，Heuristic权重
'''
weight_A = [0, 5, 100, 100, 1000, 10, 10, 25]
weight_B = [0, 5, 100, 100, 1000, 10, 10, 25]
weight_C = [0, 5, 100, 100, 1000, 10, 10, 25]
weight_D = [0, 5, 100, 100, 1000, 10, 10, 25]
weight_E = [0, 5, 100, 100, 1000, 10, 10, 25]
'''
#分域，用Deepseek调整的weight
'''
weight_A = [0, 0, 500, 500, 2000, 100, 100, 10]   
weight_B = [0, 1, 300, 300, 1500,  50,  50, 15]
weight_C = [0, 0, 400, 400, 1600,  80,  80, 12]
weight_D = [0, 1, 300, 300, 1500,  50,  50, 15]
weight_E = [0, 1, 300, 300, 1500,  50,  50, 15]
'''
#分域，用chatgpt调整weight
weight_A = [0, 0, 800, 800, 860, 140, 140, 5]
weight_B = [0, 0, 760, 760, 840, 130, 130, 6]
weight_C = [0, 0, 780, 780, 850, 135, 135, 5]
weight_D = [0, 0, 760, 760, 835, 130, 130, 6]
weight_E = [0, 0, 770, 770, 845, 132, 132, 6]

# 约定：域编号 0-4 对应 A-E
DOMAIN_WEIGHTS = {
    0: weight_A,
    1: weight_B,
    2: weight_C,
    3: weight_D,
    4: weight_E,
}

BASELINE_DOMAIN_WEIGHTS = {
    0: weight_A,
    1: weight_B,
    2: weight_C,
    3: weight_D,
    4: weight_E,
}


def get_domain_weights(domain_id: int):
    """返回指定域的权重列表（长度=8）。若域号非法则回退到默认 weights。"""
    return DOMAIN_WEIGHTS.get(int(domain_id), weights)


def to_augraph_edge_weight(w):
    if w is None or len(w) != 8:
        raise ValueError("weights 必须是长度为 8 的列表")
    return [w[0], w[1], w[2], w[4], w[5], w[6], w[3], w[7]]


def get_domain_edge_weight(domain_id: int):
    """返回指定域的 AuGraph.edge_weight 顺序权重。"""
    return to_augraph_edge_weight(get_domain_weights(domain_id))


def get_domain_edge_weight_baseline(domain_id: int):
    """返回指定域的基线 AuGraph.edge_weight 顺序权重。"""
    w = BASELINE_DOMAIN_WEIGHTS.get(int(domain_id), weights)
    return to_augraph_edge_weight(w)

GrmE_weight   = weights[0]
LPE_weight    = weights[1]
TxE_weight    = weights[2]
RxE_weight    = weights[3]
WLE_weight    = weights[4]
MuxE_weight   = weights[5]
DeMuxE_weight = weights[6]
WBE_weight    = weights[7]

# DRL 权重范围
weight_max = 1
weight_min = -1


topology_csv = 'Traffic_1000.csv'

df_topo = pd.read_csv(topology_csv)

# 节点数 = max(src, dst) + 1
node_number = int(max(df_topo['src'].max(), df_topo['dst'].max()) + 1)

# 邻接矩阵
graph_connect = np.zeros((node_number, node_number), dtype=int)

for _, row in df_topo.iterrows():
    i = int(row['src'])
    j = int(row['dst'])
    if i != j:
        graph_connect[i][j] = 1
        graph_connect[j][i] = 1

# 自动计算链路数（无向）
link_number = int(np.sum(graph_connect) / 2)

# 波长总数-公式
wavelength_number_all = link_number * wavelength_number * 2


# 物理链路矩阵
# shape = (time * wavelength, node, node)

links_physical = np.zeros((time * wavelength_number, node_number, node_number))

wave, row, col = links_physical.shape
for i in range(row):
    for j in range(col):
        if graph_connect[i][j] == 1:
            for k in range(wave):
                links_physical[k][i][j] = wavelength_capacity
        else:
            for k in range(wave):
                links_physical[k][i][j] = -1.0


def clear(links):
    for i in range(row):
        for j in range(col):
            if graph_connect[i][j] == 1:
                for k in range(wave):
                    links[k][i][j] = wavelength_capacity
            else:
                for k in range(wave):
                    links[k][i][j] = -1.0
    return links



# 测试入口

if __name__ == '__main__':
    clear(links_physical)
    print("node_number =", node_number)
    print("link_number =", link_number)
    print("wavelength_number_all =", wavelength_number_all)
    print("links_physical shape =", links_physical.shape)
