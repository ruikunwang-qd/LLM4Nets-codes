import Database
import graph
from scenario_csv_runner import run_scenario
from latency_runner import (
    compute_domain_latency_curve,
    export_domain_ratio_latency_csv,
    export_latency_csv,
)
DEEPSEEK_DOMAIN_WEIGHTS = {
    0:  [0, 0, 520, 520, 1000, 200, 200, 150],
    1:  [0, 0, 540, 540, 1000, 210, 210, 160],
    2:  [0, 0, 500, 500, 1000, 190, 190, 140],
    3:  [0, 0, 560, 560, 1000, 220, 220, 170],
    4:  [0, 0, 510, 510, 1000, 195, 195, 145],
    5:  [0, 0, 510, 510, 1000, 195, 195, 145],
    6:  [0, 0, 510, 510, 1000, 195, 195, 145],
    7:  [0, 0, 510, 510, 1000, 195, 195, 145],
}

if __name__ == "__main__":
    domain_count = len(graph.domain_node_list_all)
    selected_weights = [DEEPSEEK_DOMAIN_WEIGHTS[d] for d in sorted(DEEPSEEK_DOMAIN_WEIGHTS.keys())[:domain_count]]
    domain_edge_weight_by_id = {
        d: Database.to_augraph_edge_weight(w)
        for d, w in enumerate(selected_weights)
    }
    run_scenario(
        scenario_name="分八域_DeepSeekweights",
        business_csv_out="分八域_DeepSeekweights_业务请求数_已激活波长总数.csv",
        ratio_csv_out="分八域_DeepSeekweights_域间业务占比_已激活波长总数.csv",
        business_lightpath_csv_out="分八域_DeepSeekweights_业务请求数-已建立的光路数.csv",
        ratio_lightpath_csv_out="分八域_DeepSeekweights_域间业务占比-已激活的光路数.csv",
        ratio_blocking_csv_out="分八域_DeepSeekweights_域间业务占比_成功率阻塞率.csv",
        global_weight=None,
        domain_edge_weight_by_id=domain_edge_weight_by_id,
    )

    traffic_csv = "Traffic_3000_0.5.csv"
    out_latency_csv = "分八域_DeepSeekweights_业务请求数-时延ms.csv"
    print("[分八域_DeepSeekweights] 开始计算时延...")
    latency_curve, business_success, latency_stats = compute_domain_latency_curve(
        traffic_csv, domain_edge_weight_by_id, progress_every=50
    )
    export_latency_csv(traffic_csv, latency_curve, out_latency_csv)
    print("[分八域_DeepSeekweights] 时延统计:", latency_stats)

    out_ratio_latency_csv = "分八域_DeepSeekweights_域间业务占比-时延ms.csv"
    print("[分八域_DeepSeekweights] 开始输出域间占比-时延（6 个占比场景）...")
    export_domain_ratio_latency_csv(
        domain_edge_weight_by_id, out_ratio_latency_csv, progress_every=50
    )