import numpy as np
import pandas as pd

# 导入邻接矩阵（全网 68 节点）
adjacency_matrix = pd.read_csv("csv格式中讯拓扑邻接矩阵_68.csv", header=None)
adjacency_matrix = adjacency_matrix.fillna(0)
adjacency_matrix = np.array(adjacency_matrix, dtype=int)
PARTITION_CONFIG_VERSION = "v19-copy-cap2"
PARTITION_DEMAND_WEIGHT = 0.102
PARTITION_FIEDLER_NOISE_SEED = 42
PARTITION_FIEDLER_NOISE_STD = 0.008
PARTITION_REFINE_MAX_PASSES = 1400
PARTITION_REFINE_SECOND_PASS_PASSES = 1000
PARTITION_REFINE_THIRD_PASS_PASSES = 700
PARTITION_REFINE_INCREASE_CROSS = True
PARTITION_COPY_MAX_EXTRA_DOMAINS_PER_NODE = 2
PARTITION_REFINE_PAIR_SWAP_PASSES = 0
PARTITION_ASSIGNMENT_MODE = "contiguous"  # "contiguous" | "interleaved"
PARTITION_MULTI_START_SEEDS = [42]
PARTITION_MULTI_START_MODES = ["contiguous"]

NUM_DOMAINS = 8


def _build_traffic_demand_matrix(csv_path, node_count):
    """
    根据业务CSV构造节点对业务需求矩阵（无向累加）。
    """
    try:
        df = pd.read_csv(csv_path, engine="python")
    except Exception:
        return np.zeros((node_count, node_count), dtype=float)

    demand = np.zeros((node_count, node_count), dtype=float)
    if "src" not in df.columns or "dst" not in df.columns:
        return demand

    for s, d in zip(df["src"], df["dst"]):
        s_i = int(s)
        d_i = int(d)
        if 0 <= s_i < node_count and 0 <= d_i < node_count and s_i != d_i:
            demand[s_i][d_i] += 1.0
            demand[d_i][s_i] += 1.0
    return demand


def _fiedler_vector_weighted(adj, demand, demand_weight):
    """加权拉普拉斯第二小特征向量（Fiedler），用于一维排序。"""
    n = adj.shape[0]
    if demand is None:
        demand = np.zeros((n, n), dtype=float)
    if np.max(demand) > 0:
        demand_norm = demand / np.max(demand)
    else:
        demand_norm = demand
    combined = adj.astype(float) + float(demand_weight) * demand_norm
    degrees = np.sum(combined, axis=1)
    lap = np.diag(degrees) - combined
    _, eigvecs = np.linalg.eigh(lap)
    return eigvecs[:, 1] if n > 1 else np.zeros(n, dtype=float)


def _delta_move_cross_topo(adj, labels, u, du, dv):
    """将 u 从域 du 改到 dv 时，与 u 关联的跨域拓扑边数变化量（无向边在端点 u 处计一次）。"""
    n = adj.shape[0]
    row = adj[u]
    dlt = 0
    for v in range(n):
        if v == u or row[v] == 0:
            continue
        lv = int(labels[v])
        dlt += (1 if dv != lv else 0) - (1 if du != lv else 0)
    return dlt


def _refine_partition_balance_cross_topo(adj, parts, k, max_passes=None, increase_cross=None):
    """
    保持各域节点数在 [floor(n/k), ceil(n/k)]，贪心移动节点改变跨域拓扑边总数：
    increase_cross=True 时尽量增加，False 时尽量减少。
    """
    if max_passes is None:
        max_passes = PARTITION_REFINE_MAX_PASSES
    if increase_cross is None:
        increase_cross = PARTITION_REFINE_INCREASE_CROSS
    n = adj.shape[0]
    min_sz = n // k
    max_sz = (n + k - 1) // k

    labels = np.zeros(n, dtype=int)
    for d, nodes in enumerate(parts):
        for u in nodes:
            labels[u] = d
    sizes = [int(np.sum(labels == d)) for d in range(k)]

    for pass_i in range(max_passes):
        improved = False
        if increase_cross and pass_i > 0 and pass_i % 8 == 0:
            node_order = np.random.RandomState(2026 + pass_i).permutation(n)
        elif pass_i % 2 == 0:
            node_order = range(n)
        else:
            node_order = range(n - 1, -1, -1)
        for u in node_order:
            du = int(labels[u])
            if sizes[du] <= min_sz:
                continue
            best_dv = None
            if increase_cross:
                best_delta = -10**9
            else:
                best_delta = 0
            for dv in range(k):
                if dv == du:
                    continue
                if sizes[dv] >= max_sz:
                    continue
                dlt = _delta_move_cross_topo(adj, labels, u, du, dv)
                if increase_cross:
                    if dlt > best_delta:
                        best_delta = dlt
                        best_dv = dv
                else:
                    if dlt < best_delta:
                        best_delta = dlt
                        best_dv = dv
            ok = best_dv is not None and (
                (increase_cross and best_delta > 0) or ((not increase_cross) and best_delta < 0)
            )
            if ok:
                labels[u] = best_dv
                sizes[du] -= 1
                sizes[best_dv] += 1
                improved = True
        if not improved:
            break

    out = [[] for _ in range(k)]
    for u in range(n):
        out[int(labels[u])].append(u)
    return [sorted(p) for p in out]


def _refine_partition_pair_swap_cross_topo(adj, parts, k, max_passes=None):
    """
    在保持每个域节点数不变的前提下，贪心做跨域成对换点，继续提升跨域拓扑边。
    """
    if max_passes is None:
        max_passes = PARTITION_REFINE_PAIR_SWAP_PASSES
    if max_passes <= 0:
        return parts

    n = adj.shape[0]
    labels = np.zeros(n, dtype=int)
    domain_nodes = [set() for _ in range(k)]
    for d, nodes in enumerate(parts):
        for u in nodes:
            labels[u] = d
            domain_nodes[d].add(u)

    for pass_i in range(max_passes):
        improved = False
        best_pair = None
        best_delta = 0

        node_order = range(n) if pass_i % 2 == 0 else range(n - 1, -1, -1)
        for u in node_order:
            du = int(labels[u])
            for dv in range(k):
                if dv == du:
                    continue
                for v in domain_nodes[dv]:
                    # 先算 u->dv 的增量
                    d1 = _delta_move_cross_topo(adj, labels, u, du, dv)
                    # 临时执行第一步，再算 v->du 的增量
                    labels[u] = dv
                    d2 = _delta_move_cross_topo(adj, labels, v, dv, du)
                    labels[u] = du
                    total_delta = int(d1 + d2)
                    if total_delta > best_delta:
                        best_delta = total_delta
                        best_pair = (u, v, du, dv)

        if best_pair is not None and best_delta > 0:
            u, v, du, dv = best_pair
            labels[u] = dv
            labels[v] = du
            domain_nodes[du].remove(u)
            domain_nodes[dv].remove(v)
            domain_nodes[du].add(v)
            domain_nodes[dv].add(u)
            improved = True

        if not improved:
            break

    out = [[] for _ in range(k)]
    for u in range(n):
        out[int(labels[u])].append(u)
    return [sorted(p) for p in out]


def _k_domain_balanced_cross(adj, demand, k=None):
    """
    k 域：Fiedler 序上等分初划 + 均衡约束下按 PARTITION_REFINE_INCREASE_CROSS 增减跨域拓扑边。
    """
    if k is None:
        k = NUM_DOMAINS
    n = adj.shape[0]
    base_f = np.asarray(
        _fiedler_vector_weighted(adj, demand, PARTITION_DEMAND_WEIGHT), dtype=float
    )

    def _build_initial_parts(order_idx, mode):
        if mode == "interleaved":
            out_parts = [[] for _ in range(k)]
            for idx, node in enumerate(order_idx):
                out_parts[idx % k].append(int(node))
            return [sorted(p) for p in out_parts]
        chunks = np.array_split(order_idx, k)
        return [sorted(int(x) for x in ch) for ch in chunks]

    def _cross_demand_sum(demand_mat, domain_node_lists):
        if demand_mat is None:
            return 0.0
        nn = demand_mat.shape[0]
        labels = np.full(nn, -1, dtype=int)
        for d, nodes in enumerate(domain_node_lists):
            for u in nodes:
                labels[u] = d
        total = 0.0
        for i in range(nn):
            li = int(labels[i])
            if li < 0:
                continue
            for j in range(i + 1, nn):
                lj = int(labels[j])
                if lj >= 0 and li != lj:
                    total += float(demand_mat[i][j])
        return total

    def _partition_objective(parts, copies, boundary_nodes):
        cut_edges = float(_count_cut_topo_edges(adj, parts))
        cross_dem = float(_cross_demand_sum(demand, parts))
        copy_total = float(sum(len(c) for c in copies))
        boundary_sz = float(len(boundary_nodes))
        return 0.8 * cut_edges + 0.04 * cross_dem + 0.2 * boundary_sz + 0.12 * copy_total

    candidates = []
    for seed in PARTITION_MULTI_START_SEEDS:
        f = base_f.copy()
        if PARTITION_FIEDLER_NOISE_STD > 0:
            rng = np.random.RandomState(int(seed))
            f = f + float(PARTITION_FIEDLER_NOISE_STD) * rng.standard_normal(n)
        order = np.argsort(f)
        for mode in PARTITION_MULTI_START_MODES:
            parts = _build_initial_parts(order, mode)
            flat = [x for p in parts for x in p]
            if len(flat) != n or len(set(flat)) != n:
                continue

            parts = _refine_partition_balance_cross_topo(adj, parts, k)
            if PARTITION_REFINE_INCREASE_CROSS and PARTITION_REFINE_SECOND_PASS_PASSES > 0:
                parts = _refine_partition_balance_cross_topo(
                    adj, parts, k, max_passes=PARTITION_REFINE_SECOND_PASS_PASSES
                )
            if PARTITION_REFINE_INCREASE_CROSS and PARTITION_REFINE_THIRD_PASS_PASSES > 0:
                parts = _refine_partition_balance_cross_topo(
                    adj, parts, k, max_passes=PARTITION_REFINE_THIRD_PASS_PASSES
                )
            if PARTITION_REFINE_INCREASE_CROSS and PARTITION_REFINE_PAIR_SWAP_PASSES > 0:
                parts = _refine_partition_pair_swap_cross_topo(
                    adj, parts, k, max_passes=PARTITION_REFINE_PAIR_SWAP_PASSES
                )

            copies, cover = _pairwise_min_cover_copies(adj, parts)
            copies = _limit_copy_fanout(parts, copies, PARTITION_COPY_MAX_EXTRA_DOMAINS_PER_NODE)
            score = _partition_objective(parts, copies, cover)
            candidates.append((float(score), int(seed), str(mode), parts))

    if not candidates:
        raise ValueError("未生成有效分域候选")
    candidates.sort(key=lambda x: x[0], reverse=True)
    _best_score, _best_seed, _best_mode, best_parts = candidates[0]
    best_parts.sort(key=lambda lst: min(lst))
    return best_parts


def _build_cross_edges(adj, domain0_set, domain1_set):
    cross_edges = []
    for u in domain0_set:
        for v in domain1_set:
            if adj[u][v] != 0:
                cross_edges.append((u, v))
    return cross_edges


def _minimum_vertex_cover_on_cut_graph(cross_edges, left_nodes, right_nodes):
    # Hopcroft-Karp: 求最大匹配（左域->右域）
    adj_list = {u: [] for u in left_nodes}
    for u, v in cross_edges:
        adj_list[u].append(v)

    left_match = {u: None for u in left_nodes}
    right_match = {v: None for v in right_nodes}
    dist = {}

    from collections import deque

    def bfs():
        q = deque()
        for u in left_nodes:
            if left_match[u] is None:
                dist[u] = 0
                q.append(u)
            else:
                dist[u] = -1
        found = False
        while q:
            u = q.popleft()
            for v in adj_list[u]:
                mu = right_match[v]
                if mu is None:
                    found = True
                elif dist[mu] == -1:
                    dist[mu] = dist[u] + 1
                    q.append(mu)
        return found

    def dfs(u):
        for v in adj_list[u]:
            mu = right_match[v]
            if mu is None or (dist.get(mu, -1) == dist[u] + 1 and dfs(mu)):
                left_match[u] = v
                right_match[v] = u
                return True
        dist[u] = -1
        return False

    while bfs():
        for u in left_nodes:
            if left_match[u] is None:
                dfs(u)

    # Konig: 由最大匹配导出最小点覆盖
    visited_left = set()
    visited_right = set()
    q = deque([u for u in left_nodes if left_match[u] is None])
    visited_left.update(q)

    while q:
        u = q.popleft()
        for v in adj_list[u]:
            if v in visited_right:
                continue
            if left_match[u] != v:
                visited_right.add(v)
                mu = right_match[v]
                if mu is not None and mu not in visited_left:
                    visited_left.add(mu)
                    q.append(mu)

    cover_left = set(left_nodes) - visited_left
    cover_right = visited_right
    return cover_left | cover_right


def _pairwise_min_cover_copies(adj, domain_node_lists):
    """
    对每一对域 (i,j)，在跨域拓扑边上取二分图最小点覆盖，
    将覆盖点复制到对侧域子图（与二域情形一致，推广到多域）。
    """
    k = len(domain_node_lists)
    copies = [set() for _ in range(k)]
    primary_label = {}
    for d, nodes in enumerate(domain_node_lists):
        for u in nodes:
            primary_label[u] = d

    union_cover = set()
    for d1 in range(k):
        for d2 in range(d1 + 1, k):
            s1 = domain_node_lists[d1]
            s2 = domain_node_lists[d2]
            cross_edges = _build_cross_edges(adj, set(s1), set(s2))
            if not cross_edges:
                continue
            cover = _minimum_vertex_cover_on_cut_graph(cross_edges, s1, s2)
            union_cover |= cover
            for u in cover:
                pu = primary_label[u]
                if pu == d1:
                    copies[d2].add(u)
                elif pu == d2:
                    copies[d1].add(u)
    return copies, union_cover


def _limit_copy_fanout(domain_node_lists, copies, max_extra_domains_per_node):
    """
    限制单个主节点向其它域复制的扇出，降低跨多域重复复制。
    """
    if max_extra_domains_per_node is None or max_extra_domains_per_node < 0:
        return copies
    if max_extra_domains_per_node == 0:
        return [set() for _ in copies]

    primary_label = {}
    for d, nodes in enumerate(domain_node_lists):
        for u in nodes:
            primary_label[u] = d

    targets_by_node = {}
    for d, cp in enumerate(copies):
        for u in cp:
            targets_by_node.setdefault(u, []).append(d)

    new_copies = [set() for _ in copies]
    for u, targets in targets_by_node.items():
        pu = primary_label.get(u, -1)
        if pu >= 0:
            # 优先保留与主域编号距离近的目标域，保证跨域连通同时减少复制扩散
            targets = sorted(targets, key=lambda d: (abs(d - pu), d))
        else:
            targets = sorted(targets)
        for d in targets[: int(max_extra_domains_per_node)]:
            new_copies[d].add(u)
    return new_copies


def _build_sub_adjacency(adj, node_list):
    if not node_list:
        return np.zeros((0, 0), dtype=int)
    return adj[np.ix_(node_list, node_list)]


def _count_cut_topo_edges(adj, domain_node_lists):
    k = len(domain_node_lists)
    labels = [-1] * adj.shape[0]
    for d, nodes in enumerate(domain_node_lists):
        for u in nodes:
            labels[u] = d
    c = 0
    n = adj.shape[0]
    for i in range(n):
        for j in range(i + 1, n):
            if adj[i][j] != 0 and labels[i] >= 0 and labels[j] >= 0 and labels[i] != labels[j]:
                c += 1
    return c


def _cross_topo_edge_count_matrix(adj, domain_node_lists):
    """对称矩阵：域 d1 与 d2 之间的跨域拓扑边条数（仅主属域，不含复制节点）。"""
    k = len(domain_node_lists)
    mat = [[0] * k for _ in range(k)]
    for d1 in range(k):
        for d2 in range(d1 + 1, k):
            c = len(
                _build_cross_edges(
                    adj, set(domain_node_lists[d1]), set(domain_node_lists[d2])
                )
            )
            mat[d1][d2] = c
            mat[d2][d1] = c
    return mat


# ---------------------------------------------------------------------------
# NUM_DOMAINS 域：Fiedler 序等分 + 均衡精炼 + 域对最小点覆盖复制边界
# ---------------------------------------------------------------------------
traffic_demand_matrix = _build_traffic_demand_matrix(
    "Traffic_3000_0.5.csv", adjacency_matrix.shape[0]
)

domain_node_list = _k_domain_balanced_cross(
    adjacency_matrix, traffic_demand_matrix
)

_flat = [n for part in domain_node_list for n in part]
_n = adjacency_matrix.shape[0]
_min_sz = _n // NUM_DOMAINS
_max_sz = (_n + NUM_DOMAINS - 1) // NUM_DOMAINS
assert len(domain_node_list) == NUM_DOMAINS and all(len(p) > 0 for p in domain_node_list)
assert all(_min_sz <= len(p) <= _max_sz for p in domain_node_list)
assert len(_flat) == _n and len(set(_flat)) == len(_flat)

_domain_copies_by_domain, _union_vertex_covers = _pairwise_min_cover_copies(
    adjacency_matrix, domain_node_list
)
_domain_copies_by_domain = _limit_copy_fanout(
    domain_node_list,
    _domain_copies_by_domain,
    PARTITION_COPY_MAX_EXTRA_DOMAINS_PER_NODE,
)

domain_node_list_all = [
    sorted(set(domain_node_list[d]) | _domain_copies_by_domain[d])
    for d in range(NUM_DOMAINS)
]

boundary_node_list = sorted(_union_vertex_covers)

domain_adjacency_matrices = [
    _build_sub_adjacency(adjacency_matrix, domain_node_list_all[d])
    for d in range(NUM_DOMAINS)
]

boundary_adjacency_matrix = _build_sub_adjacency(adjacency_matrix, boundary_node_list)

# [0..NUM_DOMAINS-1 号域子图, 边界子图]
adjacency_matrix_all = domain_adjacency_matrices + [boundary_adjacency_matrix]


# ========== 分域结果摘要（便于人工检查是否合理）==========
DOMAIN_PARTITION_SUMMARY = {
    "全网节点数": int(adjacency_matrix.shape[0]),
    "域数量": NUM_DOMAINS,
    f"Fiedler序等分+均衡精炼(各域{_min_sz}~{_max_sz}节点; INCREASE_CROSS={PARTITION_REFINE_INCREASE_CROSS})": True,
    "域对最小点覆盖(Hopcroft-Karp+König)复制边界": True,
    "参数": {
        "PARTITION_CONFIG_VERSION": PARTITION_CONFIG_VERSION,
        "PARTITION_DEMAND_WEIGHT": PARTITION_DEMAND_WEIGHT,
        "PARTITION_FIEDLER_NOISE_STD": PARTITION_FIEDLER_NOISE_STD,
        "PARTITION_FIEDLER_NOISE_SEED": PARTITION_FIEDLER_NOISE_SEED,
        "PARTITION_REFINE_MAX_PASSES": PARTITION_REFINE_MAX_PASSES,
        "PARTITION_REFINE_SECOND_PASS_PASSES": PARTITION_REFINE_SECOND_PASS_PASSES,
        "PARTITION_REFINE_THIRD_PASS_PASSES": PARTITION_REFINE_THIRD_PASS_PASSES,
        "PARTITION_REFINE_INCREASE_CROSS": PARTITION_REFINE_INCREASE_CROSS,
        "PARTITION_REFINE_PAIR_SWAP_PASSES": PARTITION_REFINE_PAIR_SWAP_PASSES,
        "PARTITION_COPY_MAX_EXTRA_DOMAINS_PER_NODE": PARTITION_COPY_MAX_EXTRA_DOMAINS_PER_NODE,
        "PARTITION_ASSIGNMENT_MODE": PARTITION_ASSIGNMENT_MODE,
        "PARTITION_MULTI_START_SEEDS": list(PARTITION_MULTI_START_SEEDS),
        "PARTITION_MULTI_START_MODES": list(PARTITION_MULTI_START_MODES),
        "业务需求矩阵来源": "Traffic_3000_0.5.csv",
        "拓扑矩阵来源": "csv格式中讯拓扑邻接矩阵_68.csv",
    },
    "各域主节点数": [len(x) for x in domain_node_list],
    "各域主节点列表": [list(x) for x in domain_node_list],
    "各域复制节点(来自其它域)": [sorted(_domain_copies_by_domain[d]) for d in range(NUM_DOMAINS)],
    "各域含复制后节点数": [len(x) for x in domain_node_list_all],
    "各域含复制后节点列表": [list(x) for x in domain_node_list_all],
    "跨域拓扑边数(主划分)": _count_cut_topo_edges(adjacency_matrix, domain_node_list),
    "域对跨域拓扑边数矩阵_主属域": _cross_topo_edge_count_matrix(
        adjacency_matrix, domain_node_list
    ),
    "最小点覆盖并集节点数": len(boundary_node_list),
    "边界节点列表": list(boundary_node_list),
}


def print_matrix_with_node_ids(title, node_list, matrix):
    print(f"\n[{title}] 节点编号列表: {node_list}")
    for row_idx, node_id in enumerate(node_list):
        print(f"# {node_id}: {matrix[row_idx].tolist()}")


def print_partition_matrices_for_check():
    """
    打印划分摘要与各域（含复制）邻接矩阵行，方便人工核对。
    """
    print(f"\n========== {NUM_DOMAINS} 域划分结果（摘要）==========")
    for k, v in DOMAIN_PARTITION_SUMMARY.items():
        if k == "参数":
            print(f"  {k}: {v}")
        elif k == "域对跨域拓扑边数矩阵_主属域":
            print(f"  {k}:")
            for row in v:
                print(f"    {row}")
        elif isinstance(v, list) and k.startswith("各域"):
            print(f"  {k}:")
            for i, row in enumerate(v):
                print(f"    域{i}: {row}")
        else:
            print(f"  {k}: {v}")

    for d in range(NUM_DOMAINS):
        print_matrix_with_node_ids(
            f"{d}号域邻接矩阵(含复制边界)",
            domain_node_list_all[d],
            domain_adjacency_matrices[d],
        )
    print_matrix_with_node_ids(
        "边界子图邻接矩阵(所有域对最小点覆盖的并集)",
        boundary_node_list,
        boundary_adjacency_matrix,
    )


# 域/边界辅助函数
from collections import deque


def build_node_domains():
    """
    作用：给“每个节点”标注它属于哪个域（或哪些域）。

    这是“跨域业务拆段”的基础：
    - 普通节点只属于 1 个域（例如节点 1 只属于 A 域）
    - 边界节点会同时属于多个域（例如节点 3 同时属于 A 域和 B 域）

    返回两个结构：
    - primary_domain[i]：节点 i 的主域编号(0~NUM_DOMAINS-1)
    - node_domains[i]：节点 i 所属的所有域集合(set)，边界节点会有多个域
    """
    primary_domain = {}
    for d, nodes in enumerate(domain_node_list):
        for n in nodes:
            primary_domain[n] = d

    node_domains = {n: {d} for n, d in primary_domain.items()}

    for d, nodes_all in enumerate(domain_node_list_all):
        for n in nodes_all:
            node_domains.setdefault(n, set()).add(d)

    max_node = max(node_domains.keys())
    primary_domain_list = [primary_domain.get(i, -1) for i in range(max_node + 1)]

    return primary_domain_list, node_domains


def shortest_path_global(src, dest):
    """
    作用：先在“全网拓扑”上找一条 src -> dest 的路径。

    - 使用 BFS
    - 输出是一个节点序列，例如 [1, 3, 2]。

    注意：这里的路径只用于后续“按域切段”，不直接做波长分配。
    """
    if src == dest:
        return [src]

    n = len(adjacency_matrix)
    if src < 0 or dest < 0 or src >= n or dest >= n:
        return []

    visited = [False] * n
    prev = [-1] * n
    q = deque()

    visited[src] = True
    q.append(src)
    while q:
        u = q.popleft()
        row = adjacency_matrix[u]
        for v in range(n):
            if row[v] != 0 and not visited[v]:
                visited[v] = True
                prev[v] = u
                if v == dest:
                    q.clear()
                    break
                q.append(v)

    if not visited[dest]:
        return []

    path = []
    cur = dest
    while cur != -1:
        path.append(cur)
        cur = prev[cur]
    path.reverse()
    return path


def _pick_segment_domain_id(candidate_domains, primary_domain_list, seg_nodes):
    """
    边界节点可能属于多域时，不能长期用 min(域号) 打标签——会把绝大多数子段挤到低编号域，
    高编号域几乎空跑，多域时总激活波长会虚低。
    策略：优先该子段起点、再终点的主属域（若在候选内）；否则用 max(候选) 打散负载（与旧 min 对称）。
    """
    if not candidate_domains:
        return -1
    if len(seg_nodes) == 0:
        return min(candidate_domains)
    for u in (seg_nodes[0], seg_nodes[-1]):
        if 0 <= u < len(primary_domain_list):
            pd = int(primary_domain_list[u])
            if pd in candidate_domains:
                return pd
    return max(candidate_domains)


def split_path_by_domain(path):
    """
    作用：把“全网路径”拆成多个“域内子路径段”。
    """
    if not path:
        return []

    primary_domain_list, node_domains = build_node_domains()

    segments = []
    cur_nodes = [path[0]]
    candidate_domains = set(node_domains.get(path[0], set()))

    for idx in range(1, len(path)):
        v = path[idx]
        v_domains = node_domains.get(v, set())

        new_candidates = candidate_domains & v_domains
        if new_candidates:
            cur_nodes.append(v)
            candidate_domains = new_candidates
            continue

        last_node = path[idx - 1]

        if not candidate_domains:
            last_domain = (
                primary_domain_list[last_node]
                if last_node < len(primary_domain_list)
                else -1
            )
        else:
            last_domain = _pick_segment_domain_id(
                candidate_domains, primary_domain_list, cur_nodes
            )

        segments.append(
            {
                "domain": last_domain,
                "nodes": cur_nodes,
            }
        )

        last_domains = node_domains.get(last_node, set())
        candidate_domains = last_domains & v_domains

        if not candidate_domains:
            cur_nodes = [v]
            candidate_domains = set(v_domains)
        else:
            cur_nodes = [last_node, v]

    last_node = cur_nodes[-1]
    if not candidate_domains:
        last_domain = (
            primary_domain_list[last_node]
            if last_node < len(primary_domain_list)
            else -1
        )
    else:
        last_domain = _pick_segment_domain_id(
            candidate_domains, primary_domain_list, cur_nodes
        )

    segments.append(
        {
            "domain": last_domain,
            "nodes": cur_nodes,
        }
    )

    return segments


def route_with_domain_segments(src, dest):
    path = shortest_path_global(src, dest)
    segments = split_path_by_domain(path) if path else []
    return path, segments


if __name__ == "__main__":
    print_partition_matrices_for_check()
