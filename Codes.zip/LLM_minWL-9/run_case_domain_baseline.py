import pandas as pd

import Database
import graph
from scenario_csv_runner import run_domain_once, run_scenario
from latency_runner import (
    compute_domain_latency_curve,
    export_domain_ratio_latency_csv,
    export_latency_csv,
)

"""CHATGPT_DOMAIN_WEIGHTS = {
    0: [0, 0, 800, 800, 860, 140, 140, 5],
    1: [0, 0, 760, 760, 840, 130, 130, 6],
    2: [0, 0, 780, 780, 850, 135, 135, 5],
    3: [0, 0, 760, 760, 835, 130, 130, 6],
    4: [0, 0, 770, 770, 845, 132, 132, 6],
    5: [0, 0, 770, 770, 845, 132, 132, 6],
    6: [0, 0, 770, 770, 845, 132, 132, 6],
    7: [0, 0, 770, 770, 845, 132, 132, 6],
    8: [0, 0, 770, 770, 845, 132, 132, 6],
}
"""
"""DEEPSEEK_DOMAIN_WEIGHTS = {
    0:  [0, 0, 520, 520, 1000, 200, 200, 150],
    1:  [0, 0, 540, 540, 1000, 210, 210, 160],
    2:  [0, 0, 500, 500, 1000, 190, 190, 140],
    3:  [0, 0, 560, 560, 1000, 220, 220, 170],
    4:  [0, 0, 510, 510, 1000, 195, 195, 145],
    5:  [0, 0, 510, 510, 1000, 195, 195, 145],
    6:  [0, 0, 510, 510, 1000, 195, 195, 145],
    7:  [0, 0, 510, 510, 1000, 195, 195, 145],
    8:  [0, 0, 510, 510, 1000, 195, 195, 145],
}
"""
BASELINE_DOMAIN_WEIGHT = [0, 5, 100, 100, 1000, 10, 10, 25]

# True: 只跑 Traffic_3000_0.5，仅输出「业务请求数-已激活波长总数」「业务请求数-已建立光路数」「业务请求数-时延」
# False: 全跑（含域间占比波长/光路/阻塞率、域间占比-时延等）
ONLY_05 = True


if __name__ == "__main__":
    print(
        "[graph 已加载] "
        f"version={graph.PARTITION_CONFIG_VERSION} "
        f"w_dem={graph.PARTITION_DEMAND_WEIGHT} "
        f"fiedler_noise_std={graph.PARTITION_FIEDLER_NOISE_STD} "
        f"refine1/2/3={graph.PARTITION_REFINE_MAX_PASSES}/"
        f"{graph.PARTITION_REFINE_SECOND_PASS_PASSES}/"
        f"{graph.PARTITION_REFINE_THIRD_PASS_PASSES} "
        f"increase_cross={graph.PARTITION_REFINE_INCREASE_CROSS} | "
        f"跨域拓扑边(主划分)={graph.DOMAIN_PARTITION_SUMMARY['跨域拓扑边数(主划分)']} | "
        f"边界覆盖点数={len(graph.boundary_node_list)} | "
        f"各域主节点数={graph.DOMAIN_PARTITION_SUMMARY['各域主节点数']}"
    )
    domain_count = len(graph.domain_node_list_all)
    domain_edge_weight_by_id = {
        d: Database.to_augraph_edge_weight(BASELINE_DOMAIN_WEIGHT)
        for d in range(domain_count)
    }
    traffic_csv = "Traffic_3000_0.5.csv"
    out_wave_csv = "分九域_基线weights_业务请求数_已激活波长总数.csv"
    out_lightpath_csv = "分九域_基线weights_业务请求数-已建立的光路数.csv"
    out_latency_csv = "分九域_基线weights_业务请求数-时延ms.csv"
    out_ratio_latency_csv = "分九域_基线weights_域间业务占比-时延ms.csv"

    if ONLY_05:
        (
            total_wave,
            wave_curve,
            total_lightpath,
            lightpath_curve,
            blocked_total,
            _success_curve,
            blocked_reason_counts,
        ) = run_domain_once(traffic_csv, domain_edge_weight_by_id)
        pd.DataFrame(
            {
                "业务请求数": list(range(1, Database.job_number + 1)),
                "已激活波长总数": [int(x) for x in wave_curve],
            }
        ).to_csv(out_wave_csv, index=False, encoding="utf-8-sig")
        pd.DataFrame(
            {
                "业务请求数": list(range(1, Database.job_number + 1)),
                "已建立的光路数": [int(x) for x in lightpath_curve],
            }
        ).to_csv(out_lightpath_csv, index=False, encoding="utf-8-sig")
        print(f"[分九域_基线weights] ONLY_05=True，traffic={traffic_csv}")
        print(f"[分九域_基线weights] 总激活波长数: {total_wave}，总已建立光路数: {total_lightpath}，阻塞: {blocked_total}")
        print(f"[分九域_基线weights] 阻塞原因: {blocked_reason_counts}")
        print(f"[分九域_基线weights] 已输出: {out_wave_csv}")
        print(f"[分九域_基线weights] 已输出: {out_lightpath_csv}")
    else:
        run_scenario(
            scenario_name="分九域_基线weights",
            business_csv_out=out_wave_csv,
            ratio_csv_out="分九域_基线weights_域间业务占比_已激活波长总数.csv",
            business_lightpath_csv_out=out_lightpath_csv,
            ratio_blocking_csv_out="分九域_基线weights_域间业务占比_成功率阻塞率.csv",
            global_weight=None,
            domain_edge_weight_by_id=domain_edge_weight_by_id,
        )

    print(f"[分九域_基线weights] 开始计算时延: {traffic_csv}")
    latency_curve, _business_success, latency_stats = compute_domain_latency_curve(
        traffic_csv, domain_edge_weight_by_id, progress_every=50
    )
    export_latency_csv(traffic_csv, latency_curve, out_latency_csv)
    print(f"[分九域_基线weights] 时延统计: {latency_stats}")
    print(f"[分九域_基线weights] 已输出: {out_latency_csv}")

    if not ONLY_05:
        print("[分九域_基线weights] 开始输出域间占比-时延（6 个占比场景）...")
        export_domain_ratio_latency_csv(
            domain_edge_weight_by_id, out_ratio_latency_csv, progress_every=50
        )
    else:
        print("[分九域_基线weights] ONLY_05=True，已跳过域间占比相关 CSV 与域间占比-时延")