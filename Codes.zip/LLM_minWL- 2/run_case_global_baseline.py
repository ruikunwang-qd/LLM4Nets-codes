import pandas as pd
from statistics import mean

import Database
from scenario_csv_runner import run_global_once_with_runtime


GLOBAL_BASELINE_WEIGHTS = [0, 5, 100, 100, 1000, 10, 10, 25]


if __name__ == "__main__":
    global_weight = Database.to_augraph_edge_weight(GLOBAL_BASELINE_WEIGHTS)
    traffic_csv = "Traffic_3000_0.5.csv"
    out_runtime_csv = "不分域_业务请求数-运行时间ms.csv"
    runtime_curve_sec = run_global_once_with_runtime(
        traffic_csv,
        global_weight,
        progress_every=50,
        progress_tag="不分域_基线weights",
    )
    runtime_curve_ms = [float(x) * 1000.0 for x in runtime_curve_sec]
    pd.DataFrame(
        {
            "业务请求数": list(range(1, Database.job_number + 1)),
            "运行时间ms": runtime_curve_ms,
        }
    ).to_csv(out_runtime_csv, index=False, encoding="utf-8-sig")
    print(f"[不分域_基线weights] traffic={traffic_csv}")
    print(f"[不分域_基线weights] 平均每条业务运行时间: {mean(runtime_curve_ms):.6f} ms")
    print(f"[不分域_基线weights] 已输出: {out_runtime_csv}")