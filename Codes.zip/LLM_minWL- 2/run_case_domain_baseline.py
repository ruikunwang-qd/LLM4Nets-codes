from statistics import mean

import pandas as pd

import Database
import graph
from scenario_csv_runner import run_domain_once_with_runtime

#[0, 5, 100, 100, 1000, 10, 10, 25] 平均0.68
#deepseek：BASELINE_DOMAIN_WEIGHT = [310, 170, 145, 145, 55, 290, 290, 0] 平均时延 0.2994
BASELINE_DOMAIN_WEIGHT = [0, 5, 100, 100, 1000, 10, 10, 25]
"""CHATGPT_DOMAIN_WEIGHTS = {
    0: [0, 0, 800, 800, 860, 140, 140, 5],
    1: [0, 0, 760, 760, 840, 130, 130, 6],
    2: [0, 0, 780, 780, 850, 135, 135, 5],
    3: [0, 0, 760, 760, 835, 130, 130, 6],
    4: [0, 0, 770, 770, 845, 132, 132, 6],
}"""
"""DEEPSEEK_DOMAIN_WEIGHTS = {
    0: [0, 0, 745, 745, 1030, 206, 206, 16],
    1: [0, 0, 770, 770, 1040, 210, 210, 16],
}"""
if __name__ == "__main__":
    domain_count = len(graph.domain_node_list_all)
    print("[分两域_基线weights] 两域分域情况如下：")
    print(f"[分两域_基线weights] 0号域(不含复制): {graph.domain0_node_list}")
    print(f"[分两域_基线weights] 1号域(不含复制): {graph.domain1_node_list}")
    print(f"[分两域_基线weights] 复制边界节点: {graph.boundary_node_list}")
    print(f"[分两域_基线weights] 0号域复制节点(来自1号域): {graph.domain0_copies}")
    print(f"[分两域_基线weights] 1号域复制节点(来自0号域): {graph.domain1_copies}")
    print(
        f"[分两域_基线weights] 0号域总节点(含复制): {len(graph.domain0_node_list_all)}，"
        f"1号域总节点(含复制): {len(graph.domain1_node_list_all)}"
    )
    domain_edge_weight_by_id = {
        d: Database.to_augraph_edge_weight(BASELINE_DOMAIN_WEIGHT)
        for d in range(domain_count)
    }
    traffic_csv = "Traffic_3000_0.5.csv"
    out_runtime_csv = "分两域_基线weights_业务请求数-运行时间ms.csv"
    runtime_curve_sec = run_domain_once_with_runtime(traffic_csv, domain_edge_weight_by_id)
    runtime_curve_ms = [float(x) * 1000.0 for x in runtime_curve_sec]
    pd.DataFrame(
        {
            "业务请求数": list(range(1, Database.job_number + 1)),
            "运行时间ms": runtime_curve_ms,
        }
    ).to_csv(out_runtime_csv, index=False, encoding="utf-8-sig")
    print(f"[分两域_基线weights] traffic={traffic_csv}")
    print(f"[分两域_基线weights] 平均每条业务运行时间: {mean(runtime_curve_ms):.6f} ms")
    print(f"[分两域_基线weights] 已输出: {out_runtime_csv}")