import numpy as np
import Database
import pandas as pd
# 导入邻接矩阵
adjacency_matrix = pd.read_csv('csv格式中讯拓扑邻接矩阵_68.csv', header=None)
adjacency_matrix = adjacency_matrix.fillna(0)
adjacency_matrix = np.array(adjacency_matrix, dtype=int)


def _build_traffic_demand_matrix(csv_path, node_count):
    """
    根据业务CSV构造节点对业务需求矩阵（无向累加）。
    """
    try:
        df = pd.read_csv(csv_path, engine="python")
    except Exception:
        return np.zeros((node_count, node_count), dtype=float)

    demand = np.zeros((node_count, node_count), dtype=float)
    if "src" not in df.columns or "dst" not in df.columns:
        return demand

    for s, d in zip(df["src"], df["dst"]):
        s_i = int(s)
        d_i = int(d)
        if 0 <= s_i < node_count and 0 <= d_i < node_count and s_i != d_i:
            demand[s_i][d_i] += 1.0
            demand[d_i][s_i] += 1.0
    return demand


def _objective_for_partition(adj, in_domain0, demand=None, cut_w_topo=1.0, cut_w_demand=4.0):
    n = len(in_domain0)
    boundary_nodes = 0
    cut_topo_edges = 0
    cut_demand = 0.0
    for i in range(n):
        has_cross = False
        for j in range(i + 1, n):
            if adj[i][j] == 0:
                if demand is None:
                    continue
            if in_domain0[i] != in_domain0[j]:
                if adj[i][j] != 0:
                    cut_topo_edges += 1
                    has_cross = True
                if demand is not None and demand[i][j] > 0:
                    cut_demand += float(demand[i][j])
                    has_cross = True
        if not has_cross:
            for j in range(0, i):
                cross = False
                if adj[i][j] != 0 and in_domain0[i] != in_domain0[j]:
                    cross = True
                if demand is not None and demand[i][j] > 0 and in_domain0[i] != in_domain0[j]:
                    cross = True
                if cross:
                    has_cross = True
                    break
        if has_cross:
            boundary_nodes += 1
    return (
        boundary_nodes,
        cut_w_topo * cut_topo_edges + cut_w_demand * cut_demand,
        cut_topo_edges,
        cut_demand,
    )


def _two_domain_partition(adj, demand=None):
    n = adj.shape[0]
    # 将拓扑连接和业务需求融合，优先让高业务耦合节点同域
    if demand is None:
        demand = np.zeros((n, n), dtype=float)
    if np.max(demand) > 0:
        demand_norm = demand / np.max(demand)
    else:
        demand_norm = demand
    combined = adj.astype(float) + 3.0 * demand_norm

    degrees = np.sum(combined, axis=1)
    lap = np.diag(degrees) - combined
    eigvals, eigvecs = np.linalg.eigh(lap)
    fiedler = eigvecs[:, 1] if n > 1 else np.array([0.0])

    order = np.argsort(fiedler)
    split = n // 2
    in_domain0 = np.zeros(n, dtype=bool)
    in_domain0[order[:split]] = True

    if np.all(in_domain0) or not np.any(in_domain0):
        in_domain0[:] = False
        in_domain0[:split] = True

    improved = True
    while improved:
        improved = False
        base_obj = _objective_for_partition(adj, in_domain0, demand=demand)
        for node in range(n):
            if in_domain0[node] and np.sum(in_domain0) <= 1:
                continue
            if (not in_domain0[node]) and np.sum(~in_domain0) <= 1:
                continue
            in_domain0[node] = ~in_domain0[node]
            new_obj = _objective_for_partition(adj, in_domain0, demand=demand)
            if new_obj < base_obj:
                base_obj = new_obj
                improved = True
            else:
                in_domain0[node] = ~in_domain0[node]

    domain0 = sorted(np.where(in_domain0)[0].tolist())
    domain1 = sorted(np.where(~in_domain0)[0].tolist())
    return domain0, domain1


def _build_cross_edges(adj, domain0_set, domain1_set):
    cross_edges = []
    for u in domain0_set:
        for v in domain1_set:
            if adj[u][v] != 0:
                cross_edges.append((u, v))
    return cross_edges


def _minimum_vertex_cover_on_cut_graph(cross_edges, left_nodes, right_nodes):
    # Hopcroft-Karp: 求最大匹配（左域->右域）
    adj_list = {u: [] for u in left_nodes}
    for u, v in cross_edges:
        adj_list[u].append(v)

    left_match = {u: None for u in left_nodes}
    right_match = {v: None for v in right_nodes}
    dist = {}

    from collections import deque

    def bfs():
        q = deque()
        for u in left_nodes:
            if left_match[u] is None:
                dist[u] = 0
                q.append(u)
            else:
                dist[u] = -1
        found = False
        while q:
            u = q.popleft()
            for v in adj_list[u]:
                mu = right_match[v]
                if mu is None:
                    found = True
                elif dist[mu] == -1:
                    dist[mu] = dist[u] + 1
                    q.append(mu)
        return found

    def dfs(u):
        for v in adj_list[u]:
            mu = right_match[v]
            if mu is None or (dist.get(mu, -1) == dist[u] + 1 and dfs(mu)):
                left_match[u] = v
                right_match[v] = u
                return True
        dist[u] = -1
        return False

    while bfs():
        for u in left_nodes:
            if left_match[u] is None:
                dfs(u)

    # Konig: 由最大匹配导出最小点覆盖
    visited_left = set()
    visited_right = set()
    q = deque([u for u in left_nodes if left_match[u] is None])
    visited_left.update(q)

    while q:
        u = q.popleft()
        for v in adj_list[u]:
            if v in visited_right:
                continue
            if left_match[u] != v:
                visited_right.add(v)
                mu = right_match[v]
                if mu is not None and mu not in visited_left:
                    visited_left.add(mu)
                    q.append(mu)

    cover_left = set(left_nodes) - visited_left
    cover_right = visited_right
    return cover_left | cover_right


def _build_sub_adjacency(adj, node_list):
    if not node_list:
        return np.zeros((0, 0), dtype=int)
    return adj[np.ix_(node_list, node_list)]


# 1) 先把全网 68 节点自动划分为 2 个域（目标：减少边界 + 降低高频业务跨域）
traffic_demand_matrix = _build_traffic_demand_matrix("Traffic_3000_0.5.csv", adjacency_matrix.shape[0])
domain0_node_list, domain1_node_list = _two_domain_partition(adjacency_matrix, demand=traffic_demand_matrix)
domain_node_list = [domain0_node_list, domain1_node_list]

domain0_set = set(domain0_node_list)
domain1_set = set(domain1_node_list)

# 2) 对跨域边做最小点覆盖，仅复制必要边界节点，减少复制数量
cross_edges = _build_cross_edges(adjacency_matrix, domain0_set, domain1_set)
copied_boundary_nodes = _minimum_vertex_cover_on_cut_graph(
    cross_edges,
    domain0_node_list,
    domain1_node_list,
)

domain0_copies = sorted([n for n in copied_boundary_nodes if n in domain1_set])
domain1_copies = sorted([n for n in copied_boundary_nodes if n in domain0_set])

domain0_node_list_all = domain0_node_list + domain0_copies
domain1_node_list_all = domain1_node_list + domain1_copies
domain_node_list_all = [domain0_node_list_all, domain1_node_list_all]

# 边界节点（被复制到另一域的节点）
boundary_node_list = sorted(copied_boundary_nodes)

# 3) 域内 + 复制边界 的子图邻接矩阵
domain0_adjacency_matrix = _build_sub_adjacency(adjacency_matrix, domain0_node_list_all)
domain1_adjacency_matrix = _build_sub_adjacency(adjacency_matrix, domain1_node_list_all)

# 边界子图邻接矩阵（只看边界节点之间的连接）
boundary_adjacency_matrix = _build_sub_adjacency(adjacency_matrix, boundary_node_list)

# 方便一次性使用的列表：
# [0号域子图, 1号域子图, 边界子图]
adjacency_matrix_all = [
    domain0_adjacency_matrix,
    domain1_adjacency_matrix,
    boundary_adjacency_matrix,
]


def print_matrix_with_node_ids(title, node_list, matrix):
    print(f"\n[{title}] 节点编号列表: {node_list}")
    for row_idx, node_id in enumerate(node_list):
        print(f"# {node_id}: {matrix[row_idx].tolist()}")


def print_partition_matrices_for_check():
    """
    按“节点编号 + 每行矩阵值”的方式打印，方便人工核对。
    """
    print("\n========== 2域划分结果 ==========")
    print(f"0号域(不含复制): {domain0_node_list}")
    print(f"1号域(不含复制): {domain1_node_list}")
    print(f"复制边界节点: {boundary_node_list}")
    print(f"0号域复制节点(来自1号域): {domain0_copies}")
    print(f"1号域复制节点(来自0号域): {domain1_copies}")

    print_matrix_with_node_ids("0号域邻接矩阵(含复制边界)", domain0_node_list_all, domain0_adjacency_matrix)
    print_matrix_with_node_ids("1号域邻接矩阵(含复制边界)", domain1_node_list_all, domain1_adjacency_matrix)
    print_matrix_with_node_ids("边界子图邻接矩阵", boundary_node_list, boundary_adjacency_matrix)



# 域/边界辅助函数
from collections import deque
def build_node_domains():
    """
    作用：给“每个节点”标注它属于哪个域（或哪些域）。

    这是“跨域业务拆段”的基础：
    - 普通节点只属于 1 个域（例如节点 1 只属于 A 域）
    - 边界节点会同时属于多个域（例如节点 3 同时属于 A 域和 B 域）

    返回两个结构：
    - primary_domain[i]：节点 i 的主域编号(0~4)
    - node_domains[i]：节点 i 所属的所有域集合(set)，边界节点会有多个域
    """
    # 1) 先根据连续编号范围确定主域
    primary_domain = {}
    for d, nodes in enumerate(domain_node_list):#enumerate:遍历列表的时候，同时拿到索引和nodes(节点列表)。
        for n in nodes:
            primary_domain[n] = d #记录哪个节点在哪个域

    # 2) 初始每个节点只属于自己的主域
    node_domains = {n: {d} for n, d in primary_domain.items()}
    """node_domains = {
      0: {0},    # 节点0 当前只属于域0
      1: {0},
      ...
      14: {1},   # 节点14 当前只属于域1
   ...
  }
      """

    # 3) 再根据 “域内+边界” 列表补充归属,让边界节点同时属于多个域
    for d, nodes_all in enumerate(domain_node_list_all):
        for n in nodes_all:
            node_domains.setdefault(n, set()).add(d)

    # 4) 字典转成列表便于直接通过下标访问
    max_node = max(node_domains.keys())
    primary_domain_list = [primary_domain.get(i, -1) for i in range(max_node + 1)]

    return primary_domain_list, node_domains


def shortest_path_global(src, dest):
    """
    作用：先在“全网拓扑”上找一条 src -> dest 的路径。

    - 使用 BFS
    - 输出是一个节点序列，例如 [1, 3, 2]。

    注意：这里的路径只用于后续“按域切段”，不直接做波长分配。
    """
    if src == dest:
        return [src]#直接快速返回，不用再跑下面的 BFS

    n = len(adjacency_matrix)
    if src < 0 or dest < 0 or src >= n or dest >= n:
        return []

    visited = [False] * n
    prev = [-1] * n
    q = deque()

    visited[src] = True
    q.append(src)
#BFS
    while q:
        u = q.popleft()
        row = adjacency_matrix[u]
        for v in range(n):
            if row[v] != 0 and not visited[v]:
                visited[v] = True
                prev[v] = u
                if v == dest:
                    q.clear()
                    break
                q.append(v)

    if not visited[dest]:
        return []


    path = []
    cur = dest
    while cur != -1:
        path.append(cur)
        cur = prev[cur]
    path.reverse()
    return path


def split_path_by_domain(path):
    """
    作用：把“全网路径”拆成多个“域内子路径段”。
    - 节点 1 在 A 域，节点 2 在 B 域，它们跨域
    - 如果路径里存在边界节点 3（同时属于 A 和 B）
    - 那么把跨域业务拆成两个域内段：
        A 域内段：[1, 3]
        B 域内段：[3, 2]
    拆段规则：
    - 沿着 path 从头走
    - 只要“下一跳还在同一个域里”，就继续放在当前段
    - 一旦发现“下一跳不在当前段所属域”，就在前一个节点切断
      （前一个节点通常就是边界节点，用它作为接力点开启下一段）
    - 中间跨多个域时，同样会切出多段，逐段接力

    返回:
        segments: 形如
        [
          {'domain': 0, 'nodes': [1, 3]},
          {'domain': 1, 'nodes': [3, 2]},
          ...
        ]
    """
    if not path:
        return []

    primary_domain_list, node_domains = build_node_domains()
    #一个是列表下标是节点号，值是主域编号，，node_domains[n] 是一个“域集合”


    segments = []#初始化一个空列表，后面要把“分段后的路径”（每一段一个 segment）存进去

    # 当前 segment 的节点和“候选域集合”
    cur_nodes = [path[0]]
    #如果 path[0] = 3，并且 node_domains[3] = {0, 1}（边界节点），那么执行完这一句：candidate_domains = {0, 1}
    candidate_domains = set(node_domains.get(path[0], set()))

#这三行是在从第二个节点开始，依次拿出这条路径上的每一个节点，并查它属于哪些域。↓
    for idx in range(1, len(path)):
        v = path[idx]
        v_domains = node_domains.get(v, set())

        # 1) 就是把“当前这段已有节点可能属于的域”（candidate_domains）
        # 和“新节点 v 能属于的域”（v_domains）做一个交集：
        # 还留在交集里的域，就是“这段路径到目前为止仍然共同属于的域”。
        # 如果交集变成空了，就说明要跨域了，需要在前一个节点切断，开启新的子段。
        new_candidates = candidate_domains & v_domains
        if new_candidates:
            cur_nodes.append(v)
            candidate_domains = new_candidates
            continue

        # 2) 否则需要切断，先把当前节点的前一个节点拿出来
        last_node = path[idx - 1]

        # 当要把上一段切出来时，就看看这段路径目前还能属于哪些域，
        # 如果有多个，就挑编号最小的那个做为这段的域编号；如果实在算不出来，就用最后一个节点的主域兜底。
        if not candidate_domains:
            last_domain = primary_domain_list[last_node] if last_node < len(primary_domain_list) else -1
        else:
            last_domain = min(candidate_domains)

        #cur_nodes：当前这段路径里的所有节点，比如 [1, 3]；
        #last_domain：刚才算出来“这一段属于哪个域”，比如 0（A 域）。
        segments.append({
            'domain': last_domain,
            'nodes': cur_nodes,
        })

        # 3) 新一段从 last_node 与当前节点 v 的共同域开始


        last_domains = node_domains.get(last_node, set())
        candidate_domains = last_domains & v_domains#last_node和v共同能属于哪些域？
        # 这就变成了新一段路径的“候选域集合”（candidate_domains），后面如果再加新节点，还会继续在这个集合里往下缩小

        if not candidate_domains:
            # 理论上,lastnode和v一个共同域没有按理说不可能
            # 这里做一个兜底: 把 v 作为新 segment 的单独起点。
            cur_nodes = [v]
            candidate_domains = set(v_domains)
        else:
            # last_node 是边界节点,同时属于两个域,作为交接点
            cur_nodes = [last_node, v]#新的这个域内子业务段，从 last_node 走到 v 开始算，

    # 用当前段的最后一个节点和候选域，确定这一段的域号，把这一段（域 + 节点列表）加入 segments，最后把所有分段结果 segments 返回
    last_node = cur_nodes[-1]#last_node = 当前这段的结尾节点
    if not candidate_domains:
        last_domain = primary_domain_list[last_node] if last_node < len(primary_domain_list) else -1
    else:
        last_domain = min(candidate_domains)

    segments.append({
        'domain': last_domain,
        'nodes': cur_nodes,
    })

    return segments#最后返回 segments，就是整个“跨域业务拆分成多个域内子业务段”的结果。


#这个函数返回“全网路径”和“按域拆好的子路径段”两个结果。
def route_with_domain_segments(src, dest):

    path = shortest_path_global(src, dest) #这个函数：在全网邻接矩阵上，用 BFS 算出一条从 src 到 dest 的路径
    segments = split_path_by_domain(path) if path else []#把这条全网路径按边界节点拆成多个域内子路径段。
    return path, segments

if __name__ == "__main__":
    print_partition_matrices_for_check()
