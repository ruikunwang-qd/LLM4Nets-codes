import multiprocessing as mp

import pandas as pd

import AuGraph
import Compute
import Database
import RWA
import Service
import delay
import graph
from AuGraph_simulation_LLM import run_domain_sim
from scenario_csv_runner import TRAFFIC_FILES_BY_RATIO, load_services_from_csv


def _reset_delay_module():
    # delay.py uses module-level globals; reset them to keep each run independent.
    delay.latency = []
    delay.is_block = []
    delay.average_latency = [0]
    delay.success_num = [0]
    delay.reject_num = [0]


def compute_global_latency_curve(csv_path: str, global_weight, progress_every: int = 50):
    """
    不分域：逐业务（0..job_number-1）计算每条业务时延（ms代理指标）。
    返回：
      latency_curve: list[float]，长度=job_number
      business_success: list[bool]，长度=job_number
      stats: dict
    """
    _reset_delay_module()

    services = load_services_from_csv(csv_path)
    Service.service_list = services

    # init network state
    Database.clear(Database.links_physical)
    Compute.init_wavelength_tracker(Database.node_number, Database.wavelength_number)
    AuGraph.links_virtual_list.clear()

    latency_curve = []
    business_success = []

    for i in range(Database.job_number):
        if i == 0:
            AuGraph.au_graph_init(AuGraph.edge_weight)
        else:
            AuGraph.update_au_graph_weight(AuGraph.edge_weight)

        flag, _wave_used, au_edges_list, _reason = RWA.route_wave_assign(
            global_weight, i, return_reason=True
        )
        latency_val, _avg = delay.compute_latency(flag, au_edges_list)
        latency_curve.append(float(latency_val))
        business_success.append(bool(flag))

        if progress_every and ((i + 1) % int(progress_every) == 0 or (i + 1) == Database.job_number):
            print(
                f"[不分域时延] 进度: {i + 1}/{Database.job_number} "
                f"({(i + 1) / Database.job_number * 100:.1f}%)"
            )

    lat_success = [latency_curve[i] for i in range(Database.job_number) if business_success[i]]
    if lat_success:
        stats = {
            "min_latency_ms": min(lat_success),
            "median_latency_ms": float(pd.Series(lat_success).median()),
            "mean_latency_ms": float(sum(lat_success) / len(lat_success)),
            "max_latency_ms": max(lat_success),
            "success_num": len(lat_success),
            "blocked_num": Database.job_number - len(lat_success),
        }
    else:
        stats = {
            "min_latency_ms": float("inf"),
            "median_latency_ms": float("inf"),
            "mean_latency_ms": float("inf"),
            "max_latency_ms": float("inf"),
            "success_num": 0,
            "blocked_num": Database.job_number,
        }
    return latency_curve, business_success, stats


def compute_domain_latency_curve(csv_path: str, domain_edge_weight_by_id, progress_every: int = 0):
    """
    分域：逐业务按跨域拆段，在域内并行仿真子段时延；最后按原始业务 id 求和得到每条业务的总时延。
    返回：
      latency_curve: list[float]，长度=job_number
      business_success: list[bool]，长度=job_number
      stats: dict
    """
    _reset_delay_module()

    base_services = load_services_from_csv(csv_path)

    domain_to_seg_services = {d: [] for d in range(len(graph.domain_node_list_all))}
    business_success = [True for _ in range(Database.job_number)]

    for base_service in base_services:
        ser_id = int(base_service["id"])
        src = base_service["src"]
        dest = base_service["dest"]
        traffic = base_service["traffic"]

        full_path, segments = graph.route_with_domain_segments(src, dest)
        if not full_path or not segments:
            if 0 <= ser_id < Database.job_number:
                business_success[ser_id] = False
            continue

        for seg_idx, seg in enumerate(segments):
            seg_nodes = seg["nodes"]
            seg_domain = seg["domain"]
            seg_service = {
                "id": f"{ser_id}_seg{seg_idx}_D{seg_domain}",
                "ser_id": ser_id,
                "src": seg_nodes[0],
                "dest": seg_nodes[-1],
                "traffic": traffic.copy(),
            }
            if seg_domain in domain_to_seg_services:
                domain_to_seg_services[seg_domain].append(seg_service)

    tasks = [
        (d, segs, domain_edge_weight_by_id[d], True, True)
        for d, segs in domain_to_seg_services.items()
        if segs
    ]
    if not tasks:
        zeros = [0.0 for _ in range(Database.job_number)]
        stats = {
            "min_latency_ms": float("inf"),
            "median_latency_ms": float("inf"),
            "mean_latency_ms": float("inf"),
            "max_latency_ms": float("inf"),
            "success_num": 0,
            "blocked_num": Database.job_number,
        }
        return zeros, business_success, stats

    with mp.Pool(processes=len(tasks)) as pool:
        results = pool.starmap(run_domain_sim, tasks)

    latency_curve = [0.0 for _ in range(Database.job_number)]

    for r in results:
        ser_id_list = r[2]
        seg_success_list = r[8]
        seg_latency_list = r[10]

        for sid, ok, lat in zip(ser_id_list, seg_success_list, seg_latency_list):
            sid_int = int(sid)
            if 0 <= sid_int < Database.job_number:
                latency_curve[sid_int] += float(lat)
                if not bool(ok):
                    business_success[sid_int] = False

    # If a business is blocked, set its latency to 0 to match delay.py behavior (blocked path has no valid route).
    for k in range(Database.job_number):
        if not business_success[k]:
            latency_curve[k] = 0.0

    lat_success = [latency_curve[i] for i in range(Database.job_number) if business_success[i]]
    if lat_success:
        stats = {
            "min_latency_ms": min(lat_success),
            "median_latency_ms": float(pd.Series(lat_success).median()),
            "mean_latency_ms": float(sum(lat_success) / len(lat_success)),
            "max_latency_ms": max(lat_success),
            "success_num": len(lat_success),
            "blocked_num": Database.job_number - len(lat_success),
        }
    else:
        stats = {
            "min_latency_ms": float("inf"),
            "median_latency_ms": float("inf"),
            "mean_latency_ms": float("inf"),
            "max_latency_ms": float("inf"),
            "success_num": 0,
            "blocked_num": Database.job_number,
        }

    return latency_curve, business_success, stats


def export_latency_csv(csv_path: str, latency_curve, out_path: str):
    jn = Database.job_number
    pd.DataFrame(
        {
            "业务请求数": list(range(1, jn + 1)),
            "时延ms": [float(x) for x in latency_curve],
        }
    ).to_csv(out_path, index=False, encoding="utf-8-sig")

    print(f"已保存时延CSV: {out_path}")


def export_domain_ratio_latency_csv(
    domain_edge_weight_by_id,
    out_path: str,
    progress_every: int = 0,
):
    """
    对 scenario_csv_runner.TRAFFIC_FILES_BY_RATIO 中每个流量文件跑一次分域时延，
    输出「域间业务占比 → 时延统计」汇总表（每行一个占比）。
    """
    rows = []
    for traffic_csv, ratio in TRAFFIC_FILES_BY_RATIO:
        print(f"[域间占比-时延] 开始 ratio={ratio} ({traffic_csv})")
        _curve, _succ, stats = compute_domain_latency_curve(
            traffic_csv, domain_edge_weight_by_id, progress_every=progress_every
        )
        rows.append(
            {
                "域间业务占比": float(ratio),
                "时延ms_最小值": stats["min_latency_ms"],
                "时延ms_中位数": stats["median_latency_ms"],
                "时延ms_平均值": stats["mean_latency_ms"],
                "时延ms_最大值": stats["max_latency_ms"],
                "成功业务数": stats["success_num"],
                "阻塞业务数": stats["blocked_num"],
            }
        )
        print(f"[域间占比-时延] 完成 ratio={ratio}, 统计: {stats}")

    pd.DataFrame(rows).to_csv(out_path, index=False, encoding="utf-8-sig")
    print(f"已保存域间占比-时延CSV: {out_path}")

