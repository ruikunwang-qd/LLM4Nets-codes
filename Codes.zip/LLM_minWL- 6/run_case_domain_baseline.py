import pandas as pd

import Database
import graph
from scenario_csv_runner import run_domain_once

_BASE=[0, 5, 100, 100, 1000, 10, 10, 25]
BASELINE_DOMAIN_WEIGHTS = {d: list(_BASE) for d in range(6)}

if __name__ == "__main__":
    print(f"[weights] _BASE={_BASE} (WLE={_BASE[4]})")
    # 确认加载的是当前目录下的 graph.py（改参数后此处应变化；不变则未加载到正确文件或未删 __pycache__）
    print(
        "[graph 已加载] "
        f"w_dem={graph.PARTITION_DEMAND_WEIGHT} "
        f"refine_pass={graph.PARTITION_REFINE_MAX_PASSES} "
        f"increase_cross={graph.PARTITION_REFINE_INCREASE_CROSS} | "
        f"跨域拓扑边(主划分)={graph.DOMAIN_PARTITION_SUMMARY['跨域拓扑边数(主划分)']} | "
        f"边界覆盖点数={len(graph.boundary_node_list)} | "
        f"各域主节点数={graph.DOMAIN_PARTITION_SUMMARY['各域主节点数']}"
    )
    domain_count = len(graph.domain_node_list_all)
    selected_weights = [
        BASELINE_DOMAIN_WEIGHTS[d]
        for d in sorted(BASELINE_DOMAIN_WEIGHTS.keys())[:domain_count]
    ]
    domain_edge_weight_by_id = {
        d: Database.to_augraph_edge_weight(w)
        for d, w in enumerate(selected_weights)
    }
    traffic_csv = "Traffic_3000_0.5.csv"
    out_wave_csv = "分六域_基线weights_业务请求数_已激活波长总数.csv"
    total_wave, wave_curve, *_ = run_domain_once(traffic_csv, domain_edge_weight_by_id)
    pd.DataFrame(
        {
            "业务请求数": list(range(1, Database.job_number + 1)),
            "已激活波长总数": [int(x) for x in wave_curve],
        }
    ).to_csv(out_wave_csv, index=False, encoding="utf-8-sig")
    print(f"总激活波长数: {total_wave}")