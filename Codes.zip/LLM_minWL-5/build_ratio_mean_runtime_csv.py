from pathlib import Path

import pandas as pd


def build_one(src: Path, mean_col: str) -> Path:
    df = pd.read_csv(src, engine="python")
    if mean_col not in df.columns:
        raise KeyError(f"{src.name} 缺少列: {mean_col}")
    out = src.with_name(src.name.replace("域间业务占比-运行时间", "域间业务占比-平均运行时间"))
    out_df = df[["域间业务占比", mean_col]].copy()
    out_df.columns = ["域间业务占比", "平均运行时间_s"]
    out_df.to_csv(out, index=False, encoding="utf-8-sig")
    return out


def main() -> None:
    root = Path(__file__).resolve().parent

    # 不分域：当前脚本输出未包含“整体墙钟/每业务”，使用全体业务平均运行时间列。
    global_src = root / "不分域_域间业务占比-运行时间.csv"
    out_global = root / "不分域_基线weights_域间业务占比-平均运行时间.csv"
    g_df = pd.read_csv(global_src, engine="python")
    g_df = g_df[["域间业务占比", "平均运行时间_s_全体业务"]].copy()
    g_df.columns = ["域间业务占比", "平均运行时间_s"]
    g_df.to_csv(out_global, index=False, encoding="utf-8-sig")
    print(f"saved: {out_global.name}")

    # 分域三组：使用“平均整体墙钟时间_s_每业务”。
    for name in [
        "分五域_基线weights_域间业务占比-运行时间.csv",
        "分五域_ChatGPTweights_域间业务占比-运行时间.csv",
        "分五域_DeepSeekweights_域间业务占比-运行时间.csv",
    ]:
        out = build_one(root / name, "平均整体墙钟时间_s_每业务")
        print(f"saved: {out.name}")


if __name__ == "__main__":
    main()
