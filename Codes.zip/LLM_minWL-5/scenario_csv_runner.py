import multiprocessing as mp
import time

import pandas as pd

import AuGraph
import Compute
import Database
import RWA
import Service
import graph
from AuGraph_simulation_LLM import run_domain_sim

BLOCK_REASON_LABELS = {
    "SRC_NO_OUT_EDGE": "阻塞原因_源端无可用出边",
    "DST_NO_IN_EDGE": "阻塞原因_目的端无可用入边",
    "NO_FEASIBLE_PATH_IN_AUX": "阻塞原因_辅助图无可行路径",
    "NO_FULL_PATH_SEGMENT": "阻塞原因_分段失败(无全路径)",
}


TRAFFIC_FILES_BY_RATIO = [
    ("Traffic_3000_0.csv", 0.0),
    ("Traffic_3000_0.2.csv", 0.2),
    ("Traffic_3000_0.4.csv", 0.4),
    ("Traffic_3000_0.6.csv", 0.6),
    ("Traffic_3000_0.8.csv", 0.8),
    ("Traffic_3000_1.csv", 1.0),
]

BUSINESS_CURVE_TRAFFIC = "Traffic_3000_0.5.csv"


def load_services_from_csv(csv_path):
    df = pd.read_csv(csv_path, engine="python")
    src_list = list(df["src"])
    dst_list = list(df["dst"])

    traffic_df = pd.read_csv(
        csv_path,
        engine="python",
        usecols=list(range(3, Database.time + 3)),
    )
    traffic_list = traffic_df.values.tolist()

    services = []
    job_number = Database.job_number
    n_rows = len(src_list)
    if n_rows == 0:
        raise ValueError(f"CSV {csv_path} 为空，无法生成业务")

    for i in range(job_number):
        row_idx = i % n_rows
        services.append(
            {
                "id": i,
                "src": int(src_list[row_idx]),
                "dest": int(dst_list[row_idx]),
                "traffic": traffic_list[row_idx][0 : Database.time],
            }
        )
    return services


def run_global_once(csv_path, global_weight, progress_every=0, progress_tag="GLOBAL"):
    services = load_services_from_csv(csv_path)
    Service.service_list = services

    Database.clear(Database.links_physical)
    Compute.init_wavelength_tracker(Database.node_number, Database.wavelength_number)
    AuGraph.links_virtual_list.clear()

    wave_used_curve = []
    lightpath_curve = []
    success_curve = []
    blocked_reason_counts = {
        "SRC_NO_OUT_EDGE": 0,
        "DST_NO_IN_EDGE": 0,
        "NO_FEASIBLE_PATH_IN_AUX": 0,
    }
    t_start = time.time()
    success_count = 0
    for i in range(Database.job_number):
        if i == 0:
            AuGraph.au_graph_init(global_weight)
        else:
            AuGraph.update_au_graph_weight(global_weight)
        flag, wave_used, _au_edges, reason = RWA.route_wave_assign(global_weight, i, return_reason=True)
        wave_used_curve.append(int(wave_used))
        lightpath_curve.append(int(len(AuGraph.links_virtual_list)))
        if flag:
            success_count += 1
        else:
            if reason in blocked_reason_counts:
                blocked_reason_counts[reason] += 1
        success_curve.append(int(success_count))
        if progress_every and ((i + 1) % int(progress_every) == 0 or (i + 1) == Database.job_number):
            elapsed = time.time() - t_start
            pct = (i + 1) / Database.job_number * 100
            print(
                f"[{progress_tag}] 进度: {i + 1}/{Database.job_number} "
                f"({pct:.1f}%), 已耗时: {elapsed:.1f}s"
            )

    total_wave = int(Compute.get_wave_used_count())
    total_lightpath = int(len(AuGraph.links_virtual_list))
    blocked_total = int(Database.job_number - success_count)
    return (
        total_wave,
        wave_used_curve,
        total_lightpath,
        lightpath_curve,
        blocked_total,
        success_curve,
        blocked_reason_counts,
    )


def merge_by_business(results, job_number, value_index):
    domain_value_lists = []
    domain_ser_id_lists = []
    for r in results:
        domain_value_lists.append(r[value_index])
        domain_ser_id_lists.append(r[2])

    merged = []
    for k in range(job_number):
        total_k = 0
        for value_list, ser_id_list in zip(domain_value_lists, domain_ser_id_lists):
            i_last = -1
            for j, sid in enumerate(ser_id_list):
                if sid <= k:
                    i_last = j
            if i_last >= 0:
                total_k += int(value_list[i_last])
        merged.append(total_k)
    return merged


def run_domain_once(csv_path, domain_edge_weight_by_id):
    base_services = load_services_from_csv(csv_path)

    domain_to_seg_services = {0: [], 1: [], 2: [], 3: [], 4: []}
    # 按原始业务统计：先假设成功；若任一子段失败或无可分段路径则置为失败
    business_success = [True for _ in range(Database.job_number)]
    business_fail_reason = ["" for _ in range(Database.job_number)]
    for base_service in base_services:
        ser_id = base_service["id"]
        src = base_service["src"]
        dest = base_service["dest"]
        traffic = base_service["traffic"]

        full_path, segments = graph.route_with_domain_segments(src, dest)
        if not full_path or not segments:
            if 0 <= int(ser_id) < Database.job_number:
                business_success[int(ser_id)] = False
                business_fail_reason[int(ser_id)] = "NO_FULL_PATH_SEGMENT"
            continue

        for seg_idx, seg in enumerate(segments):
            seg_nodes = seg["nodes"]
            seg_domain = seg["domain"]
            seg_service = {
                "id": f"{ser_id}_seg{seg_idx}_D{seg_domain}",
                "ser_id": ser_id,
                "src": seg_nodes[0],
                "dest": seg_nodes[-1],
                "traffic": traffic.copy(),
            }
            if seg_domain in domain_to_seg_services:
                domain_to_seg_services[seg_domain].append(seg_service)

    tasks = [(d, segs, domain_edge_weight_by_id[d]) for d, segs in domain_to_seg_services.items() if segs]
    if not tasks:
        zeros = [0 for _ in range(Database.job_number)]
        return 0, zeros, 0, zeros, Database.job_number, [0 for _ in range(Database.job_number)], {
            "SRC_NO_OUT_EDGE": 0,
            "DST_NO_IN_EDGE": 0,
            "NO_FEASIBLE_PATH_IN_AUX": 0,
            "NO_FULL_PATH_SEGMENT": Database.job_number,
        }

    with mp.Pool(processes=len(tasks)) as pool:
        tasks_with_lightpath = [(d, segs, w, True, False, True) for (d, segs, w) in tasks]
        results = pool.starmap(run_domain_sim, tasks_with_lightpath)

    # 统一到“全网唯一计数”口径：跨域结果按 (wavelength, src, dest) 做并集计数。
    global_wave_entries = set()
    for r in results:
        for entry in r[11]:
            global_wave_entries.add((int(entry[0]), int(entry[1]), int(entry[2])))
    total_wave_used = int(len(global_wave_entries))
    total_lightpath_used = int(sum(r[6] for r in results))
    merged_wave_curve = merge_by_business(results, Database.job_number, value_index=1)
    merged_lightpath_curve = merge_by_business(results, Database.job_number, value_index=7)

    # 将各域的子段成功性合并回原始业务成功性：任一子段失败则该业务失败
    for r in results:
        ser_id_list = r[2]
        seg_success_list = r[8]
        seg_reason_list = r[9]
        for sid, ok, reason in zip(ser_id_list, seg_success_list, seg_reason_list):
            sid_int = int(sid)
            if 0 <= sid_int < Database.job_number and not bool(ok):
                business_success[sid_int] = False
                if not business_fail_reason[sid_int]:
                    business_fail_reason[sid_int] = reason

    success_curve = []
    succ = 0
    for ok in business_success:
        if ok:
            succ += 1
        success_curve.append(succ)
    blocked_total = int(Database.job_number - succ)
    blocked_reason_counts = {
        "SRC_NO_OUT_EDGE": 0,
        "DST_NO_IN_EDGE": 0,
        "NO_FEASIBLE_PATH_IN_AUX": 0,
        "NO_FULL_PATH_SEGMENT": 0,
    }
    for ok, reason in zip(business_success, business_fail_reason):
        if not ok:
            key = reason if reason in blocked_reason_counts else "NO_FEASIBLE_PATH_IN_AUX"
            blocked_reason_counts[key] += 1

    return (
        total_wave_used,
        merged_wave_curve,
        total_lightpath_used,
        merged_lightpath_curve,
        blocked_total,
        success_curve,
        blocked_reason_counts,
    )


def run_scenario(
    scenario_name,
    business_csv_out,
    ratio_csv_out,
    business_lightpath_csv_out=None,
    ratio_lightpath_csv_out=None,
    ratio_blocking_csv_out=None,
    global_weight=None,
    domain_edge_weight_by_id=None,
):
    """
    运行一个场景并输出两类 CSV：
    1) 业务请求数-已激活波长总数（使用 Traffic_3000_0.5）
    2) 域间业务占比-已激活波长总数（使用 TRAFFIC_FILES_BY_RATIO）
    """
    if global_weight is None and domain_edge_weight_by_id is None:
        raise ValueError("global_weight 和 domain_edge_weight_by_id 不能同时为空")

    business_curve = None
    if global_weight is not None:
        _global_total, business_curve, _global_lp, business_lightpath_curve, _global_blocked, _global_success_curve, _global_block_reasons = run_global_once(
            BUSINESS_CURVE_TRAFFIC, global_weight
        )
    else:
        _domain_total, business_curve, _domain_lp, business_lightpath_curve, _domain_blocked, _domain_success_curve, _domain_block_reasons = run_domain_once(
            BUSINESS_CURVE_TRAFFIC, domain_edge_weight_by_id
        )

    pd.DataFrame(
        {
            "业务请求数": list(range(1, Database.job_number + 1)),
            "已激活波长总数": [int(x) for x in business_curve],
        }
    ).to_csv(business_csv_out, index=False, encoding="utf-8-sig")

    if business_lightpath_csv_out:
        pd.DataFrame(
            {
                "业务请求数": list(range(1, Database.job_number + 1)),
                "已建立的光路数": [int(x) for x in business_lightpath_curve],
            }
        ).to_csv(business_lightpath_csv_out, index=False, encoding="utf-8-sig")

    ratio_records = []
    ratio_lightpath_records = []
    ratio_blocking_records = []
    for traffic_csv, ratio in TRAFFIC_FILES_BY_RATIO:
        if global_weight is not None:
            total_wave, _curve, total_lightpath, _lp_curve, blocked_total, _succ_curve, blocked_reason_counts = run_global_once(
                traffic_csv, global_weight
            )
        else:
            total_wave, _curve, total_lightpath, _lp_curve, blocked_total, _succ_curve, blocked_reason_counts = run_domain_once(
                traffic_csv, domain_edge_weight_by_id
            )
        ratio_records.append(
            {
                "域间业务占比": float(ratio),
                "已激活波长总数": int(total_wave),
            }
        )
        ratio_lightpath_records.append(
            {
                "域间业务占比": float(ratio),
                "已激活的光路数": int(total_lightpath),
            }
        )
        record = {
            "域间业务占比": float(ratio),
            "业务总数": int(Database.job_number),
            "成功业务数": int(Database.job_number - blocked_total),
            "阻塞业务数": int(blocked_total),
            "阻塞率": float(blocked_total / Database.job_number),
            "成功率": float((Database.job_number - blocked_total) / Database.job_number),
        }
        for k, v in blocked_reason_counts.items():
            col = BLOCK_REASON_LABELS.get(k, f"阻塞原因_{k}")
            record[col] = int(v)
        ratio_blocking_records.append(record)

    pd.DataFrame(ratio_records).to_csv(ratio_csv_out, index=False, encoding="utf-8-sig")
    if ratio_lightpath_csv_out:
        pd.DataFrame(ratio_lightpath_records).to_csv(ratio_lightpath_csv_out, index=False, encoding="utf-8-sig")
    if ratio_blocking_csv_out:
        pd.DataFrame(ratio_blocking_records).to_csv(ratio_blocking_csv_out, index=False, encoding="utf-8-sig")

    print(f"[{scenario_name}] 已输出: {business_csv_out}")
    print(f"[{scenario_name}] 已输出: {ratio_csv_out}")
    if business_lightpath_csv_out:
        print(f"[{scenario_name}] 已输出: {business_lightpath_csv_out}")
    if ratio_lightpath_csv_out:
        print(f"[{scenario_name}] 已输出: {ratio_lightpath_csv_out}")
    if ratio_blocking_csv_out:
        print(f"[{scenario_name}] 已输出: {ratio_blocking_csv_out}")

