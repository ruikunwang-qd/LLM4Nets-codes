import latency as latency_mod

latency = []
is_block = []

average_latency = [0]
success_num = [0]
reject_num = [0]


def compute_latency(flag, au_edges_list):
    """
    兼容入口：内部使用 latency.compute_latency_ms（与 latency.py 规则一致），
    并维护原 delay 模块级列表，供旧代码读取。
    """
    is_block.append(int(not flag))
    lat_val = latency_mod.compute_latency_ms(flag, au_edges_list)
    latency.append(float(lat_val))

    success_num[0] = len(is_block) - sum(is_block)
    reject_num[0] = sum(is_block)
    if success_num[0] != 0:
        average_latency[0] = sum(latency) / success_num[0]
    else:
        average_latency[0] = float("inf")

    return latency[-1], average_latency[0]
