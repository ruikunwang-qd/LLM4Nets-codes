import multiprocessing as mp

import pandas as pd

import Database
from latency_runner import (
    compute_domain_latency_curve,
    export_domain_ratio_runtime_csv,
    export_runtime_csv,
    print_mean_latency_runtime_console,
)
from scenario_csv_runner import run_scenario

ONLY_05 = False
EXPORT_WAVE_RATIO_CSV = True

# [GrmE, LPE, TxE, RxE, WLE, MuxE, DeMuxE, WBE]
DEEPSEEK_DOMAIN_WEIGHTS = {
    # 原五域相同基线（保留备份）：
    # 0..4: [310, 170, 145, 145, 55, 290, 290, 0],
    # 当前生效：再次微调（0-1000）
    0: [0, 3, 175, 300, 900, 0, 0, 20],
    1: [0, 3, 175, 300, 900, 0, 0, 20],
    2: [0, 3, 175, 300, 900, 0, 0, 20],
    3: [0, 3, 175, 300, 900, 0, 0, 20],
    4: [0, 3, 175, 300, 900, 0, 0, 20],
}

LATENCY_PROGRESS_EVERY = 0
RATIO_LATENCY_PROGRESS_EVERY = 200


if __name__ == "__main__":
    mp.freeze_support()
    domain_edge_weight_by_id = {
        d: Database.to_augraph_edge_weight(w)
        for d, w in DEEPSEEK_DOMAIN_WEIGHTS.items()
    }
    traffic_csv = "Traffic_3000_0.5.csv"
    out_runtime_csv = "分五域_DeepSeekweights_业务请求数-运行时间.csv"
    out_ratio_runtime_csv = "分五域_DeepSeekweights_域间业务占比-运行时间.csv"

    print("[分五域_DeepSeekweights] 计算运行时间...")
    _latency_curve, _business_success, latency_stats, runtime_curve = compute_domain_latency_curve(
        traffic_csv, domain_edge_weight_by_id, progress_every=LATENCY_PROGRESS_EVERY
    )
    export_runtime_csv(traffic_csv, runtime_curve, out_runtime_csv)
    print(
        f"[分五域_DeepSeekweights] 每条业务平均时间: "
        f"{float(latency_stats['mean_runtime_s']):.6f} s/条"
    )
    print(
        f"[分五域_DeepSeekweights] 每条成功业务平均时间: "
        f"{float(latency_stats.get('mean_runtime_s_success_only', float('nan'))):.6f} s/条"
    )
    print_mean_latency_runtime_console("[分五域_DeepSeekweights]", latency_stats)
    print(f"[分五域_DeepSeekweights] 已输出: {out_runtime_csv}")
    try:
        baseline_rt = pd.read_csv("分五域_基线weights_业务请求数-运行时间.csv")["运行时间_s"].mean()
        cur_rt = pd.read_csv(out_runtime_csv)["运行时间_s"].mean()
        print(
            f"[分五域_DeepSeekweights] 平均运行时间对比（秒/条）：当前={cur_rt:.6f}，基线={baseline_rt:.6f}"
        )
    except Exception as e:
        print(f"[分五域_DeepSeekweights] 未能读取基线运行时间CSV做对比：{e}")

    if not ONLY_05:
        print("[分五域_DeepSeekweights] 输出域间占比-运行时间（6 个占比场景）...")
        export_domain_ratio_runtime_csv(
            domain_edge_weight_by_id,
            out_ratio_runtime_csv,
            progress_every=RATIO_LATENCY_PROGRESS_EVERY,
        )
        print(f"[分五域_DeepSeekweights] 已输出: {out_ratio_runtime_csv}")
    else:
        print("[分五域_DeepSeekweights] ONLY_05=True，已跳过域间占比运行时间 CSV")

    if EXPORT_WAVE_RATIO_CSV:
        wave_business_csv = "分五域_DeepSeekweights_业务请求数_已激活波长总数.csv"
        wave_ratio_csv = "分五域_DeepSeekweights_域间业务占比_已激活波长总数.csv"
        print("[分五域_DeepSeekweights] 输出域间占比-激活波长总数...")
        run_scenario(
            scenario_name="分五域_DeepSeekweights_激活波长",
            business_csv_out=wave_business_csv,
            ratio_csv_out=wave_ratio_csv,
            domain_edge_weight_by_id=domain_edge_weight_by_id,
        )
        print(f"[分五域_DeepSeekweights] 已输出: {wave_ratio_csv}")
