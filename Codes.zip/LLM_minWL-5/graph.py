import numpy as np
import Database
import pandas as pd
# 导入邻接矩阵
adjacency_matrix = pd.read_csv('csv格式中讯拓扑邻接矩阵_68.csv', header=None)
adjacency_matrix = adjacency_matrix.fillna(0)
adjacency_matrix = np.array(adjacency_matrix, dtype=int)


# 1. 域内节点划分（不含边界复制）
# A: 0-13, B: 14-27, C: 28-40, D: 41-54, E: 55-67
domainA_node_list = list(range(0, 14))#灰色
domainB_node_list = list(range(14, 28))#橙色
domainC_node_list = list(range(28, 41))#蓝色
domainD_node_list = list(range(41, 55))#绿色
domainE_node_list = list(range(55, 68))#黄色
#打包成一个大列表，域编号0-4
domain_node_list = [
    domainA_node_list,
    domainB_node_list,
    domainC_node_list,
    domainD_node_list,
    domainE_node_list,
]


# 每个域“带边界”的完整节点列表（域内路由用）
# A 额外: 30，41，55
# B 额外: 5, 6
# C 额外: 16, 41, 67
# D 额外: 6, 17, 25, 62
# E 额外: 14, 28, 44
domainA_node_list_all = domainA_node_list + [30,41,55]#17
domainB_node_list_all = domainB_node_list + [5, 6]#16
domainC_node_list_all = domainC_node_list + [16, 41, 67]#16
domainD_node_list_all = domainD_node_list + [6, 17, 25, 62]#18
domainE_node_list_all = domainE_node_list + [14, 28, 44]#16

domain_node_list_all = [domainA_node_list_all,domainB_node_list_all,domainC_node_list_all,domainD_node_list_all,domainE_node_list_all]

# 边界节点集合
boundary_node_list = sorted(list({5, 6, 14, 16, 17, 25, 28, 30,41, 44, 55,62, 67}))




# 4. 各域邻接矩阵（域内 + 边界复制）
domainA_adjacency_matrix = np.array([
    [0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0],
    [1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0],
    [0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    [0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0],
], dtype=int)
domainB_adjacency_matrix = np.array([
    [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],  # 5
    [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 6
    [0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 14
    [1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 15
    [0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0],  # 16
    [0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0],  # 17
    [0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0],  # 18
    [0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],  # 19
    [0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1],  # 20
    [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0],  # 21
    [0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0],  # 22
    [0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1],  # 23
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0],  # 24
    [0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0],  # 25
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1],  # 26
    [1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0],  # 27
], dtype=int)
domainC_adjacency_matrix = np.array([
    [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0],  # 16
    [0, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0],  # 28
    [0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0],  # 29
    [0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 30
    [1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 31
    [0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0],  # 32
    [0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0],  # 33
    [0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 34
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0],  # 35
    [0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1],  # 36
    [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0],  # 37
    [1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0],  # 38
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0],  # 39
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0],  # 40
    [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 41
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0],  # 67
], dtype=int)
domainD_adjacency_matrix = np.array([
    [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 6
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],  # 17
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0],  # 25
    [1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0],  # 41
    [0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 42
    [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 43
    [0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 44
    [0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0],  # 45
    [0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],  # 46
    [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],  # 47
    [0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0],  # 48
    [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0],  # 49
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0],  # 50
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0],  # 51
    [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1],  # 52
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0],  # 53
    [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0],  # 54
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],  # 62
], dtype=int)
domainE_adjacency_matrix = np.array([
    [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],  # 14
    [0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],  # 28
    [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],  # 44
    [0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 55
    [0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],  # 56
    [0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0],  # 57
    [0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],  # 58
    [1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0],  # 59
    [0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0],  # 60
    [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0],  # 61
    [0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0],  # 62
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0],  # 63
    [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1],  # 64
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1],  # 65
    [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1],  # 66
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0],  # 67
], dtype=int)


#边界子图邻接矩阵（只看边界节点之间的连接）

boundary_adjacency_matrix = np.array([
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 5
    [0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0],  # 6  -14,41
    [0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],  # 14 -6,17
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 16
    [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 17 -14
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 25
    [0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0],  # 28 -30,41
    [0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0],  # 30 -28
    [0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0],  # 41 -6,28
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 44
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 55
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 62
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # 67
], dtype=int)
# 方便一次性使用的列表：
# [A域子图, B域子图, C域子图, D域子图, E域子图, 边界子图]
adjacency_matrix_all = [
    domainA_adjacency_matrix,
    domainB_adjacency_matrix,
    domainC_adjacency_matrix,
    domainD_adjacency_matrix,
    domainE_adjacency_matrix,
    boundary_adjacency_matrix,
]



# 域/边界辅助函数
from collections import deque
def build_node_domains():
    """
    作用：给“每个节点”标注它属于哪个域（或哪些域）。

    这是“跨域业务拆段”的基础：
    - 普通节点只属于 1 个域（例如节点 1 只属于 A 域）
    - 边界节点会同时属于多个域（例如节点 3 同时属于 A 域和 B 域）

    返回两个结构：
    - primary_domain[i]：节点 i 的主域编号(0~4)
    - node_domains[i]：节点 i 所属的所有域集合(set)，边界节点会有多个域
    """
    # 1) 先根据连续编号范围确定主域
    primary_domain = {}
    for d, nodes in enumerate(domain_node_list):#enumerate:遍历列表的时候，同时拿到索引和nodes(节点列表)。
        for n in nodes:
            primary_domain[n] = d #记录哪个节点在哪个域

    # 2) 初始每个节点只属于自己的主域
    node_domains = {n: {d} for n, d in primary_domain.items()}
    """node_domains = {
      0: {0},    # 节点0 当前只属于域0
      1: {0},
      ...
      14: {1},   # 节点14 当前只属于域1
   ...
  }
      """

    # 3) 再根据 “域内+边界” 列表补充归属,让边界节点同时属于多个域
    for d, nodes_all in enumerate(domain_node_list_all):
        for n in nodes_all:
            node_domains.setdefault(n, set()).add(d)

    # 4) 字典转成列表便于直接通过下标访问
    max_node = max(node_domains.keys())
    primary_domain_list = [primary_domain.get(i, -1) for i in range(max_node + 1)]

    return primary_domain_list, node_domains


def shortest_path_global(src, dest):
    """
    作用：先在“全网拓扑”上找一条 src -> dest 的路径。

    - 使用 BFS
    - 输出是一个节点序列，例如 [1, 3, 2]。

    注意：这里的路径只用于后续“按域切段”，不直接做波长分配。
    """
    if src == dest:
        return [src]#直接快速返回，不用再跑下面的 BFS

    n = len(adjacency_matrix)
    if src < 0 or dest < 0 or src >= n or dest >= n:
        return []

    visited = [False] * n
    prev = [-1] * n
    q = deque()

    visited[src] = True
    q.append(src)
#BFS
    while q:
        u = q.popleft()
        row = adjacency_matrix[u]
        for v in range(n):
            if row[v] != 0 and not visited[v]:
                visited[v] = True
                prev[v] = u
                if v == dest:
                    q.clear()
                    break
                q.append(v)

    if not visited[dest]:
        return []


    path = []
    cur = dest
    while cur != -1:
        path.append(cur)
        cur = prev[cur]
    path.reverse()
    return path


def shortest_path_restricted(src, dest, allowed_nodes):
    """
    作用：在“受限节点集合”内做 BFS 最短路（按跳数）。
    - 仅允许访问 allowed_nodes 中的节点；
    - 若 src/dest 不在 allowed_nodes 内，直接返回空路径。
    """
    if src == dest:
        return [src]

    n = len(adjacency_matrix)
    if src < 0 or dest < 0 or src >= n or dest >= n:
        return []

    allowed = set(allowed_nodes)
    if src not in allowed or dest not in allowed:
        return []

    visited = [False] * n
    prev = [-1] * n
    q = deque()

    visited[src] = True
    q.append(src)

    while q:
        u = q.popleft()
        row = adjacency_matrix[u]
        for v in range(n):
            if v not in allowed:
                continue
            if row[v] != 0 and not visited[v]:
                visited[v] = True
                prev[v] = u
                if v == dest:
                    q.clear()
                    break
                q.append(v)

    if not visited[dest]:
        return []

    path = []
    cur = dest
    while cur != -1:
        path.append(cur)
        cur = prev[cur]
    path.reverse()
    return path


def split_path_by_domain(path):
    """
    作用：把“全网路径”拆成多个“域内子路径段”。
    - 节点 1 在 A 域，节点 2 在 B 域，它们跨域
    - 如果路径里存在边界节点 3（同时属于 A 和 B）
    - 那么把跨域业务拆成两个域内段：
        A 域内段：[1, 3]
        B 域内段：[3, 2]
    拆段规则：
    - 沿着 path 从头走
    - 只要“下一跳还在同一个域里”，就继续放在当前段
    - 一旦发现“下一跳不在当前段所属域”，就在前一个节点切断
      （前一个节点通常就是边界节点，用它作为接力点开启下一段）
    - 中间跨多个域时，同样会切出多段，逐段接力

    返回:
        segments: 形如
        [
          {'domain': 0, 'nodes': [1, 3]},
          {'domain': 1, 'nodes': [3, 2]},
          ...
        ]
    """
    if not path:
        return []

    primary_domain_list, node_domains = build_node_domains()
    #一个是列表下标是节点号，值是主域编号，，node_domains[n] 是一个“域集合”


    segments = []#初始化一个空列表，后面要把“分段后的路径”（每一段一个 segment）存进去

    # 当前 segment 的节点和“候选域集合”
    cur_nodes = [path[0]]
    #如果 path[0] = 3，并且 node_domains[3] = {0, 1}（边界节点），那么执行完这一句：candidate_domains = {0, 1}
    candidate_domains = set(node_domains.get(path[0], set()))

#这三行是在从第二个节点开始，依次拿出这条路径上的每一个节点，并查它属于哪些域。↓
    for idx in range(1, len(path)):
        v = path[idx]
        v_domains = node_domains.get(v, set())

        # 1) 就是把“当前这段已有节点可能属于的域”（candidate_domains）
        # 和“新节点 v 能属于的域”（v_domains）做一个交集：
        # 还留在交集里的域，就是“这段路径到目前为止仍然共同属于的域”。
        # 如果交集变成空了，就说明要跨域了，需要在前一个节点切断，开启新的子段。
        new_candidates = candidate_domains & v_domains
        if new_candidates:
            cur_nodes.append(v)
            candidate_domains = new_candidates
            continue

        # 2) 否则需要切断，先把当前节点的前一个节点拿出来
        last_node = path[idx - 1]

        # 当要把上一段切出来时，就看看这段路径目前还能属于哪些域，
        # 如果有多个，就挑编号最小的那个做为这段的域编号；如果实在算不出来，就用最后一个节点的主域兜底。
        if not candidate_domains:
            last_domain = primary_domain_list[last_node] if last_node < len(primary_domain_list) else -1
        else:
            last_domain = min(candidate_domains)

        #cur_nodes：当前这段路径里的所有节点，比如 [1, 3]；
        #last_domain：刚才算出来“这一段属于哪个域”，比如 0（A 域）。
        segments.append({
            'domain': last_domain,
            'nodes': cur_nodes,
        })

        # 3) 新一段从 last_node 与当前节点 v 的共同域开始


        last_domains = node_domains.get(last_node, set())
        candidate_domains = last_domains & v_domains#last_node和v共同能属于哪些域？
        # 这就变成了新一段路径的“候选域集合”（candidate_domains），后面如果再加新节点，还会继续在这个集合里往下缩小

        if not candidate_domains:
            # 理论上,lastnode和v一个共同域没有按理说不可能
            # 这里做一个兜底: 把 v 作为新 segment 的单独起点。
            cur_nodes = [v]
            candidate_domains = set(v_domains)
        else:
            # last_node 是边界节点,同时属于两个域,作为交接点
            cur_nodes = [last_node, v]#新的这个域内子业务段，从 last_node 走到 v 开始算，

    # 用当前段的最后一个节点和候选域，确定这一段的域号，把这一段（域 + 节点列表）加入 segments，最后把所有分段结果 segments 返回
    last_node = cur_nodes[-1]#last_node = 当前这段的结尾节点
    if not candidate_domains:
        last_domain = primary_domain_list[last_node] if last_node < len(primary_domain_list) else -1
    else:
        last_domain = min(candidate_domains)

    segments.append({
        'domain': last_domain,
        'nodes': cur_nodes,
    })

    return segments#最后返回 segments，就是整个“跨域业务拆分成多个域内子业务段”的结果。


#这个函数返回“全网路径”和“按域拆好的子路径段”两个结果。
def route_with_domain_segments(src, dest):
    primary_domain_list, _node_domains = build_node_domains()
    src_domain = primary_domain_list[src] if 0 <= src < len(primary_domain_list) else -1
    dst_domain = primary_domain_list[dest] if 0 <= dest < len(primary_domain_list) else -1

    # 同主域业务强制走“本域可用路径”（主域节点 + 本域边界节点），
    # 允许边界节点，不允许其他域外节点。
    if src_domain != -1 and src_domain == dst_domain:
        path = shortest_path_restricted(src, dest, domain_node_list_all[src_domain])
        if path:
            return path, [{"domain": src_domain, "nodes": path}]
        return [], []

    path = shortest_path_global(src, dest) #这个函数：在全网邻接矩阵上，用 BFS 算出一条从 src 到 dest 的路径
    segments = split_path_by_domain(path) if path else []#把这条全网路径按边界节点拆成多个域内子路径段。
    return path, segments

