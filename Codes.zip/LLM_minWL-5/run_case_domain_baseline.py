import multiprocessing as mp

import Database
from latency_runner import (
    compute_domain_latency_curve,
    export_domain_ratio_latency_csv,
    export_domain_ratio_runtime_csv,
    export_latency_csv,
    export_runtime_csv,
    print_mean_latency_runtime_console,
)
from scenario_csv_runner import run_scenario

BASELINE_DOMAIN_WEIGHT = [0, 5, 100, 100, 1000, 10, 10, 25]

# True: 仅输出 Traffic_3000_0.5 的「业务请求数-运行时间」CSV
# False: 额外输出「域间业务占比-运行时间」汇总 CSV（较慢）
ONLY_05 = False
EXPORT_WAVE_RATIO_CSV = True


if __name__ == "__main__":
    mp.freeze_support()
    domain_edge_weight_by_id = {
        d: Database.to_augraph_edge_weight(BASELINE_DOMAIN_WEIGHT)
        for d in range(5)
    }
    traffic_csv = "Traffic_3000_0.5.csv"
    out_latency_csv = "分五域_基线weights_业务请求数-时延.csv"
    out_runtime_csv = "分五域_基线weights_业务请求数-运行时间.csv"
    out_ratio_latency_csv = "分五域_基线weights_域间业务占比-时延.csv"
    out_ratio_runtime_csv = "分五域_基线weights_域间业务占比-运行时间.csv"

    print(f"[分五域_基线weights] 计算运行时间: {traffic_csv}")
    _latency_curve, _business_success, latency_stats, runtime_curve = compute_domain_latency_curve(
        traffic_csv, domain_edge_weight_by_id, progress_every=50
    )
    export_latency_csv(traffic_csv, _latency_curve, out_latency_csv)
    export_runtime_csv(traffic_csv, runtime_curve, out_runtime_csv)
    print(f"[分五域_基线weights] 每条业务平均时间: {float(latency_stats['mean_runtime_s']):.6f} s/条")
    print(
        f"[分五域_基线weights] 每条成功业务平均时间: "
        f"{float(latency_stats.get('mean_runtime_s_success_only', float('nan'))):.6f} s/条"
    )
    print_mean_latency_runtime_console("[分五域_基线weights]", latency_stats)
    print(f"[分五域_基线weights] 已输出: {out_latency_csv}")
    print(f"[分五域_基线weights] 已输出: {out_runtime_csv}")

    if not ONLY_05:
        print("[分五域_基线weights] 输出域间占比-时延/运行时间（6 个占比场景）...")
        export_domain_ratio_latency_csv(
            domain_edge_weight_by_id, out_ratio_latency_csv, progress_every=50
        )
        export_domain_ratio_runtime_csv(
            domain_edge_weight_by_id, out_ratio_runtime_csv, progress_every=50
        )
        print(f"[分五域_基线weights] 已输出: {out_ratio_latency_csv}")
        print(f"[分五域_基线weights] 已输出: {out_ratio_runtime_csv}")
    else:
        print("[分五域_基线weights] ONLY_05=True，已跳过域间占比时延/运行时间 CSV")

    if EXPORT_WAVE_RATIO_CSV:
        wave_business_csv = "分五域_基线weights_业务请求数_已激活波长总数.csv"
        wave_ratio_csv = "分五域_基线weights_域间业务占比_已激活波长总数.csv"
        print("[分五域_基线weights] 输出域间占比-激活波长总数...")
        run_scenario(
            scenario_name="分五域_基线weights_激活波长",
            business_csv_out=wave_business_csv,
            ratio_csv_out=wave_ratio_csv,
            domain_edge_weight_by_id=domain_edge_weight_by_id,
        )
        print(f"[分五域_基线weights] 已输出: {wave_ratio_csv}")
