import multiprocessing as mp

import pandas as pd

import Database
from latency_runner import (
    compute_domain_latency_curve,
    export_domain_ratio_runtime_csv,
    export_runtime_csv,
    print_mean_latency_runtime_console,
)
from scenario_csv_runner import run_scenario

ONLY_05 = False
EXPORT_WAVE_RATIO_CSV = True

# 原 ChatGPT 权重（保留备份，不启用）：
# CHATGPT_DOMAIN_WEIGHTS = {
#     0: [311, 167, 140, 139, 51, 227, 229, 2],
#     ...
# }
CHATGPT_DOMAIN_WEIGHTS = {
    # [GrmE, LPE, TxE, RxE, WLE, MuxE, DeMuxE, WBE]
    0: [0, 4, 180, 255, 933, 0, 0, 22],
    1: [0, 4, 180, 255, 933, 0, 0, 22],
    2: [0, 4, 180, 255, 933, 0, 0, 22],
    3: [0, 4, 180, 255, 933, 0, 0, 22],
    4: [0, 4, 180, 255, 933, 0, 0, 22],
}


if __name__ == "__main__":
    mp.freeze_support()
    print(f"[分五域_ChatGPTweights] 域0权重(原始8维): {CHATGPT_DOMAIN_WEIGHTS[0]}")
    domain_edge_weight_by_id = {
        d: Database.to_augraph_edge_weight(w)
        for d, w in CHATGPT_DOMAIN_WEIGHTS.items()
    }
    traffic_csv = "Traffic_3000_0.5.csv"
    out_runtime_csv = "分五域_ChatGPTweights_业务请求数-运行时间.csv"
    out_ratio_runtime_csv = "分五域_ChatGPTweights_域间业务占比-运行时间.csv"

    print("[分五域_ChatGPTweights] 计算运行时间...")
    _latency_curve, _business_success, latency_stats, runtime_curve = compute_domain_latency_curve(
        traffic_csv, domain_edge_weight_by_id, progress_every=50
    )
    export_runtime_csv(traffic_csv, runtime_curve, out_runtime_csv)
    print(
        f"[分五域_ChatGPTweights] 每条业务平均时间: "
        f"{float(latency_stats['mean_runtime_s']):.6f} s/条"
    )
    print(
        f"[分五域_ChatGPTweights] 每条成功业务平均时间: "
        f"{float(latency_stats.get('mean_runtime_s_success_only', float('nan'))):.6f} s/条"
    )
    print_mean_latency_runtime_console("[分五域_ChatGPTweights]", latency_stats)
    print(f"[分五域_ChatGPTweights] 已输出: {out_runtime_csv}")
    try:
        baseline_rt = pd.read_csv("分五域_基线weights_业务请求数-运行时间.csv")["运行时间_s"].mean()
        cur_rt = pd.read_csv(out_runtime_csv)["运行时间_s"].mean()
        print(
            f"[分五域_ChatGPTweights] 平均运行时间对比（秒/条）：当前={cur_rt:.6f}，基线={baseline_rt:.6f}"
        )
    except Exception as e:
        print(f"[分五域_ChatGPTweights] 未能读取基线运行时间CSV做对比：{e}")

    if not ONLY_05:
        print("[分五域_ChatGPTweights] 输出域间占比-运行时间（6 个占比场景）...")
        export_domain_ratio_runtime_csv(
            domain_edge_weight_by_id, out_ratio_runtime_csv, progress_every=50
        )
        print(f"[分五域_ChatGPTweights] 已输出: {out_ratio_runtime_csv}")
    else:
        print("[分五域_ChatGPTweights] ONLY_05=True，已跳过域间占比运行时间 CSV")

    if EXPORT_WAVE_RATIO_CSV:
        wave_business_csv = "分五域_ChatGPTweights_业务请求数_已激活波长总数.csv"
        wave_ratio_csv = "分五域_ChatGPTweights_域间业务占比_已激活波长总数.csv"
        print("[分五域_ChatGPTweights] 输出域间占比-激活波长总数...")
        run_scenario(
            scenario_name="分五域_ChatGPTweights_激活波长",
            business_csv_out=wave_business_csv,
            ratio_csv_out=wave_ratio_csv,
            domain_edge_weight_by_id=domain_edge_weight_by_id,
        )
        print(f"[分五域_ChatGPTweights] 已输出: {wave_ratio_csv}")
