import os
import numpy as np
import pandas as pd
from networkx.algorithms.connectivity.edge_augmentation import weighted_one_edge_augmentation, \
    weighted_bridge_augmentation

# 网络和业务信息
job_number = 300              # 业务数量
wavelength_number = 40        # 波长数量
wavelength_capacity = 25     # 单波长容量
time = 24                    # 所有时刻数量（24小时）

# 时延模型（latency.compute_latency_ms / delay.compute_latency）：单位 ms；可按论文/设备参数自行修改。
# OEO_time：在 fiber 矩阵生成后赋值，与单条物理链路同分布——[300,400) km 均匀随机后乘 1e-3 得 ms（不出现常数 20）。
v = 2 * 1e5           # 单位km/s
# 物理拓扑 graph_connect 与光纤：仅由「中讯」邻接矩阵决定直连边（1=有边，0=无直连边）。
# 每条直连边 fiber_length_km 在 [300,400) km 独立随机；多跳路径上每一跳都是一条直连边，各段各自累计时延。
# 业务流量（src/dst/各时刻）来自业务 CSV，由 Service 等加载；业务 OD 可无直连，由连通图寻路，不改变物理边集合。
_fiber_rng = np.random.default_rng()
# 兼容旧代码：fiber_length / fiber_time 为全链路统计均值；每条边的真实长度见 fiber_length_km（各自 [300,400) km 随机）
fiber_length = None
fiber_time = None
# 启发式 / LLM 权重 1351

weights = [0, 5, 100, 100, 1000, 10, 10, 25]

# 分域，Heuristic权重 1682
'''
weight_A = [0, 5, 100, 100, 1000, 10, 10, 25]
weight_B = [0, 5, 100, 100, 1000, 10, 10, 25]
weight_C = [0, 5, 100, 100, 1000, 10, 10, 25]
weight_D = [0, 5, 100, 100, 1000, 10, 10, 25]
weight_E = [0, 5, 100, 100, 1000, 10, 10, 25]
'''
#分域，用Deepseek调整的weight 1560
'''
weight_A = [0, 0, 500, 500, 2000, 100, 100, 10]   
weight_B = [0, 1, 300, 300, 1500,  50,  50, 15]
weight_C = [0, 0, 400, 400, 1600,  80,  80, 12]
weight_D = [0, 1, 300, 300, 1500,  50,  50, 15]
weight_E = [0, 1, 300, 300, 1500,  50,  50, 15]
'''
#分域，用chatgpt调整weight 1477 我是 OpenAI 的 GPT-5.4 Nano
weight_A = [0, 0, 800, 800, 860, 140, 140, 5]
weight_B = [0, 0, 760, 760, 840, 130, 130, 6]
weight_C = [0, 0, 780, 780, 850, 135, 135, 5]
weight_D = [0, 0, 760, 760, 835, 130, 130, 6]
weight_E = [0, 0, 770, 770, 845, 132, 132, 6]

# 约定：域编号 0-4 对应 A-E
DOMAIN_WEIGHTS = {
    0: weight_A,
    1: weight_B,
    2: weight_C,
    3: weight_D,
    4: weight_E,
}


# 基线 domain weights（用于“分域(基线weights)”曲线）
# 注意：weight_A1~weight_E1 的顺序和 `weights` 相同，仍满足
# [GrmE, LPE, TxE, RxE, WLE, MuxE, DeMuxE, WBE] -> to_augraph_edge_weight 映射。
BASELINE_DOMAIN_WEIGHTS = {
    0: weight_A,
    1: weight_B,
    2: weight_C,
    3: weight_D,
    4: weight_E,
}


def get_domain_weights(domain_id: int):
    """返回指定域的权重列表（长度=8）。若域号非法则回退到默认 weights。"""
    return DOMAIN_WEIGHTS.get(int(domain_id), weights)


def to_augraph_edge_weight(w):
    """
    将 Database.weights 的顺序转换为 AuGraph.edge_weight 所需顺序。

    Database.weights 顺序(8个)：
      [GrmE, LPE, TxE, RxE, WLE, MuxE, DeMuxE, WBE]

    AuGraph.edge_weight 顺序(8个)：
      [GrmE, LPE, TxE, WLE, MuxE, DeMuxE, RxE, WBE]
    """
    if w is None or len(w) != 8:
        raise ValueError("weights 必须是长度为 8 的列表")
    return [w[0], w[1], w[2], w[4], w[5], w[6], w[3], w[7]]


def get_domain_edge_weight(domain_id: int):
    """返回指定域的 AuGraph.edge_weight 顺序权重。"""
    return to_augraph_edge_weight(get_domain_weights(domain_id))


def get_domain_edge_weight_baseline(domain_id: int):
    """返回指定域的基线 AuGraph.edge_weight 顺序权重。"""
    w = BASELINE_DOMAIN_WEIGHTS.get(int(domain_id), weights)
    return to_augraph_edge_weight(w)

GrmE_weight   = weights[0]
LPE_weight    = weights[1]
TxE_weight    = weights[2]
RxE_weight    = weights[3]
WLE_weight    = weights[4]
MuxE_weight   = weights[5]
DeMuxE_weight = weights[6]
WBE_weight    = weights[7]

# DRL 权重范围
weight_max = 1
weight_min = -1


physical_topology_csv = 'csv格式中讯拓扑邻接矩阵_68.csv'
# 默认业务流量文件（仅校验节点编号是否在拓扑内；实际加载见 Service.py）
traffic_business_csv = 'Traffic_3000_0.5.csv'

_adj_df = pd.read_csv(physical_topology_csv, header=None).fillna(0)
_adj = np.asarray(_adj_df, dtype=int)
if _adj.ndim != 2 or _adj.shape[0] != _adj.shape[1]:
    raise ValueError(f"{physical_topology_csv} 须为方阵，当前 shape={getattr(_adj, 'shape', None)}")
node_number = int(_adj.shape[0])

# 无向物理邻接：任一侧非 0 视为有直连边（与 graph.py 一致）
_has = (_adj != 0) | (_adj.T != 0)
np.fill_diagonal(_has, False)
graph_connect = _has.astype(np.int32)

if os.path.isfile(traffic_business_csv):
    df_biz = pd.read_csv(traffic_business_csv)
    mx = int(max(df_biz['src'].max(), df_biz['dst'].max()))
    if mx >= node_number:
        raise ValueError(
            f"{traffic_business_csv} 中节点编号最大为 {mx}，不小于物理拓扑节点数 {node_number}"
        )

fiber_length_km = np.zeros((node_number, node_number), dtype=float)
fiber_time_ms = np.zeros((node_number, node_number), dtype=float)

for i in range(node_number):
    for j in range(i + 1, node_number):
        if graph_connect[i][j] != 1:
            continue
        L = 300.0 + float(_fiber_rng.random()) * 100.0
        fiber_length_km[i, j] = L
        fiber_length_km[j, i] = L
        t = L / v * 1000.0
        fiber_time_ms[i, j] = t
        fiber_time_ms[j, i] = t

# 自动计算链路数（无向）
link_number = int(np.sum(graph_connect) / 2)
if link_number > 0:
    pos = fiber_length_km > 0
    fiber_length = float(np.mean(fiber_length_km[pos]))
    fiber_time = float(np.mean(fiber_time_ms[pos]))
else:
    fiber_length = None
    fiber_time = None

OEO_time = (300.0 + float(_fiber_rng.random()) * 100.0) * 1e-3

# 波长总数-公式
wavelength_number_all = link_number * wavelength_number * 2


# 物理链路矩阵
# shape = (time * wavelength, node, node)

links_physical = np.zeros((time * wavelength_number, node_number, node_number))

wave, row, col = links_physical.shape
for i in range(row):
    for j in range(col):
        if graph_connect[i][j] == 1:
            for k in range(wave):
                links_physical[k][i][j] = wavelength_capacity
        else:
            for k in range(wave):
                links_physical[k][i][j] = -1.0


def clear(links):
    for i in range(row):
        for j in range(col):
            if graph_connect[i][j] == 1:
                for k in range(wave):
                    links[k][i][j] = wavelength_capacity
            else:
                for k in range(wave):
                    links[k][i][j] = -1.0
    return links



# 测试入口

if __name__ == '__main__':
    clear(links_physical)
    print("node_number =", node_number)
    print("link_number =", link_number)
    print("wavelength_number_all =", wavelength_number_all)
    print("links_physical shape =", links_physical.shape)
