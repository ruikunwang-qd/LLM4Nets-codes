"""
基于 BFS 发现顺序的域划分（输入邻接矩阵须为未分域全网拓扑，例如
``csv格式中讯拓扑邻接矩阵_68.csv`` 读入的 68×68 矩阵）。

据此构造 domain_node_list / domain_node_list_all 与边界节点集合。
"""
from __future__ import annotations

from collections import deque
from typing import List, Sequence, Tuple

import numpy as np


def _as_bool_adj(adj: np.ndarray) -> np.ndarray:
    """无向简单图：非零视为边；对矩阵做对称化，避免 CSV 只记单向 1 时漏边。"""
    a = np.asarray(adj, dtype=int)
    b = (a != 0).astype(np.int8)
    b = ((b | b.T) > 0).astype(np.int8)
    return b


def bfs_discovery_order(adj_bool: np.ndarray) -> List[int]:
    """全图（多连通分量依次）BFS 发现顺序：与 shortest_path_global 一致，按层扩展。"""
    n = int(adj_bool.shape[0])
    visited = [False] * n
    order: List[int] = []
    for s in range(n):
        if visited[s]:
            continue
        q = deque([s])
        visited[s] = True
        while q:
            u = int(q.popleft())
            order.append(u)
            row = adj_bool[u]
            for v in range(n):
                if int(row[v]) and not visited[v]:
                    visited[v] = True
                    q.append(v)
    return order


def partition_balanced_by_bfs_layers(adj: np.ndarray, k: int) -> List[List[int]]:
    """
    将节点 0..n-1 划分为 k 个域（互不相交），各域大小至多相差 1。

    策略（修正版）：先得到全图 BFS 发现顺序，再在该顺序上做**连续等长切块**。
    这样每个域在 BFS 树上是一段连续“时间带”，跨域边主要出现在相邻块之间，
    比“同一层内轮流塞域”要少得多，边界节点集合会小很多。

    （旧版按层贪心塞最少域会把域在图上打散，跨域边爆炸，边界节点虚高。）
    """
    if k < 1:
        raise ValueError("k 必须 >= 1")
    adj_bool = _as_bool_adj(adj)
    n = int(adj_bool.shape[0])
    if adj_bool.shape[0] != adj_bool.shape[1]:
        raise ValueError("邻接矩阵须为方阵")
    order = bfs_discovery_order(adj_bool)
    if len(order) != n:
        raise RuntimeError(f"BFS 覆盖节点数 {len(order)} != n {n}")

    sizes = [n // k + (1 if i < n % k else 0) for i in range(k)]
    domains: List[List[int]] = []
    pos = 0
    for sz in sizes:
        chunk = order[pos : pos + sz]
        pos += sz
        domains.append(sorted(chunk))
    return domains


def count_cut_edges(adj: np.ndarray, primary: Sequence[int]) -> int:
    """无向图跨域边条数（每条无向边只计一次）。"""
    adj_bool = _as_bool_adj(adj)
    n = len(primary)
    c = 0
    for u in range(n):
        pu = int(primary[u])
        row = adj_bool[u]
        for v in range(u + 1, n):
            if int(row[v]) and int(primary[v]) != pu:
                c += 1
    return c


def primary_domain_from_lists(domain_node_list: Sequence[Sequence[int]]) -> List[int]:
    n = max(max(nodes, default=-1) for nodes in domain_node_list) + 1
    prim = [-1] * n
    for d, nodes in enumerate(domain_node_list):
        for u in nodes:
            if prim[u] != -1:
                raise ValueError(f"节点 {u} 被重复划分到多个域")
            prim[u] = d
    if any(x < 0 for x in prim):
        missing = [i for i, x in enumerate(prim) if x < 0]
        raise ValueError(f"存在未分配节点: {missing[:10]}...")
    return prim


def boundary_nodes(adj: np.ndarray, primary: Sequence[int]) -> List[int]:
    adj_bool = _as_bool_adj(adj)
    n = len(primary)
    bset = set()
    for u in range(n):
        pu = int(primary[u])
        row = adj_bool[u]
        for v in range(n):
            if int(row[v]) and int(primary[v]) != pu:
                bset.add(u)
                bset.add(v)
    return sorted(bset)


def build_domain_node_list_all(
    domain_node_list: Sequence[Sequence[int]],
    primary: Sequence[int],
    adj: np.ndarray,
    max_external_per_domain: int = 10,
) -> List[List[int]]:
    """
    与 graph.py 五域思路类似：域 d 的子图节点 = 本域主节点 ∪ 若干外域节点（边界复制）。

    外域候选：与域 d 至少一条边相连、且主域不为 d 的节点。候选可能很多时，每域最多保留
    ``max_external_per_domain`` 个：优先保留与域 d 主节点连边数多的节点（再按节点编号）。
    """
    if max_external_per_domain < 0:
        raise ValueError("max_external_per_domain 须 >= 0")
    adj_bool = _as_bool_adj(adj)
    k = len(domain_node_list)
    primary_list = [int(primary[i]) for i in range(len(primary))]
    out: List[List[int]] = []
    for d in range(k):
        base = set(int(x) for x in domain_node_list[d])
        edge_count_to_base: dict[int, int] = {}
        for u in base:
            row = adj_bool[u]
            for v in range(len(primary_list)):
                if not int(row[v]):
                    continue
                if primary_list[v] == d:
                    continue
                edge_count_to_base[v] = edge_count_to_base.get(v, 0) + 1
        ranked = sorted(edge_count_to_base.keys(), key=lambda v: (-edge_count_to_base[v], v))
        if max_external_per_domain == 0:
            chosen: set[int] = set()
        else:
            chosen = set(ranked[:max_external_per_domain])
        nodes = sorted(base | chosen)
        out.append(nodes)
    return out


def boundary_nodes_in_subgraphs(
    domain_node_list_all: Sequence[Sequence[int]],
    primary: Sequence[int],
) -> List[int]:
    """各域子图中作为「外域复制」出现的节点（主域 ≠ 所在子图域号），去重后排序。"""
    primary_list = [int(primary[i]) for i in range(len(primary))]
    s: set[int] = set()
    for d, nodes_all in enumerate(domain_node_list_all):
        for v in nodes_all:
            v = int(v)
            if primary_list[v] != d:
                s.add(v)
    return sorted(s)


def submatrix_for_nodes(adj: np.ndarray, nodes: Sequence[int]) -> np.ndarray:
    """按 nodes 顺序取子邻接矩阵。"""
    idx = [int(x) for x in nodes]
    a = np.asarray(adj, dtype=int)
    return a[np.ix_(idx, idx)]


def apply_partition_to_graph_module(
    graph_mod,
    domain_node_list: List[List[int]],
    domain_node_list_all: List[List[int]],
    boundary_node_list: List[int],
) -> None:
    graph_mod.domain_node_list = domain_node_list
    graph_mod.domain_node_list_all = domain_node_list_all
    graph_mod.boundary_node_list = list(boundary_node_list)


def snapshot_graph_partition(graph_mod) -> Tuple:
    return (
        [list(x) for x in graph_mod.domain_node_list],
        [list(x) for x in graph_mod.domain_node_list_all],
        list(graph_mod.boundary_node_list),
    )


def restore_graph_partition(graph_mod, snap: Tuple) -> None:
    domain_node_list, domain_node_list_all, boundary_node_list = snap
    graph_mod.domain_node_list = domain_node_list
    graph_mod.domain_node_list_all = domain_node_list_all
    graph_mod.boundary_node_list = boundary_node_list
