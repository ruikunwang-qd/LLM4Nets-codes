import multiprocessing as mp
import statistics
import time

import pandas as pd

import AuGraph
import Compute
import Database
import RWA
import Service
import latency as latency_mod
from scenario_csv_runner import TRAFFIC_FILES_BY_RATIO, load_services_from_csv


GLOBAL_BASELINE_WEIGHTS = [0, 5, 100, 100, 1000, 10, 10, 25]
PROGRESS_EVERY = 50


def summarize_runtime_s(runtime_curve):
    if not runtime_curve:
        return {
            "min_runtime_s": float("inf"),
            "median_runtime_s": float("inf"),
            "mean_runtime_s": float("inf"),
            "max_runtime_s": float("inf"),
        }
    xs = [float(x) for x in runtime_curve]
    return {
        "min_runtime_s": min(xs),
        "median_runtime_s": float(statistics.median(xs)),
        "mean_runtime_s": float(sum(xs) / len(xs)),
        "max_runtime_s": max(xs),
    }


def summarize_latency_ms(latency_curve):
    if not latency_curve:
        return {
            "min_latency_ms": float("inf"),
            "median_latency_ms": float("inf"),
            "mean_latency_ms": float("inf"),
            "max_latency_ms": float("inf"),
        }
    xs = [float(x) for x in latency_curve]
    return {
        "min_latency_ms": min(xs),
        "median_latency_ms": float(statistics.median(xs)),
        "mean_latency_ms": float(sum(xs) / len(xs)),
        "max_latency_ms": max(xs),
    }


def run_global_once_collect(csv_path, global_weight, progress_every=0):
    services = load_services_from_csv(csv_path)
    Service.service_list = services

    Database.clear(Database.links_physical)
    Compute.init_wavelength_tracker(Database.node_number, Database.wavelength_number)
    AuGraph.links_virtual_list.clear()

    runtime_curve = []
    latency_curve = []
    wave_used_curve = []
    lightpath_curve = []
    success_flags = []
    t_start = time.time()

    for i in range(Database.job_number):
        if i == 0:
            AuGraph.au_graph_init(global_weight)
        else:
            AuGraph.update_au_graph_weight(global_weight)

        t0 = time.perf_counter()
        flag, wave_used, au_edges, _reason = RWA.route_wave_assign(
            global_weight, i, return_reason=True
        )
        runtime_curve.append(float(time.perf_counter() - t0))
        latency_curve.append(float(latency_mod.compute_latency_ms(flag, au_edges)))
        wave_used_curve.append(int(wave_used))
        lightpath_curve.append(int(len(AuGraph.links_virtual_list)))
        success_flags.append(bool(flag))

        if progress_every and ((i + 1) % int(progress_every) == 0 or (i + 1) == Database.job_number):
            elapsed = time.time() - t_start
            pct = (i + 1) / Database.job_number * 100
            print(f"[GLOBAL] {csv_path} 进度: {i + 1}/{Database.job_number} ({pct:.1f}%), 已耗时: {elapsed:.1f}s")

    total_wave = int(Compute.get_wave_used_count())
    total_lightpath = int(len(AuGraph.links_virtual_list))
    succ = int(sum(1 for x in success_flags if x))
    mean_runtime_all = float(sum(runtime_curve) / len(runtime_curve)) if runtime_curve else 0.0
    mean_runtime_success = (
        float(sum(runtime_curve[i] for i, ok in enumerate(success_flags) if ok) / succ)
        if succ > 0
        else float("nan")
    )
    mean_latency_all = float(sum(latency_curve) / len(latency_curve)) if latency_curve else 0.0
    mean_latency_success = (
        float(sum(latency_curve[i] for i, ok in enumerate(success_flags) if ok) / succ)
        if succ > 0
        else float("nan")
    )
    return {
        "total_wave": total_wave,
        "total_lightpath": total_lightpath,
        "latency_curve": latency_curve,
        "wave_used_curve": wave_used_curve,
        "lightpath_curve": lightpath_curve,
        "runtime_curve": runtime_curve,
        "success_num": succ,
        "blocked_num": int(Database.job_number - succ),
        "mean_latency_ms": mean_latency_all,
        "mean_latency_ms_success_only": mean_latency_success,
        "mean_runtime_s": mean_runtime_all,
        "mean_runtime_s_success_only": mean_runtime_success,
    }


if __name__ == "__main__":
    mp.freeze_support()
    global_weight = Database.to_augraph_edge_weight(GLOBAL_BASELINE_WEIGHTS)
    out_runtime_csv = "不分域_业务请求数-运行时间.csv"
    out_ratio_runtime_csv = "不分域_域间业务占比-运行时间.csv"
    out_latency_csv = "不分域_基线weights_业务请求数-时延.csv"
    out_ratio_latency_csv = "不分域_基线weights_域间业务占比-时延.csv"
    wave_business_csv = "不分域_基线weights_业务请求数_已激活波长总数.csv"
    wave_ratio_csv = "不分域_基线weights_域间业务占比_已激活波长总数.csv"
    lightpath_business_csv = "不分域_基线weights_业务请求数-已建立的光路数.csv"
    lightpath_ratio_csv = "不分域_基线weights_域间业务占比-已激活的光路数.csv"

    ratio_runtime_rows = []
    ratio_latency_rows = []
    ratio_wave_rows = []
    ratio_lightpath_rows = []
    result_by_ratio = {}

    for traffic_csv, ratio in TRAFFIC_FILES_BY_RATIO:
        print(f"[不分域_基线weights] 开始: {traffic_csv} (ratio={ratio})")
        res = run_global_once_collect(traffic_csv, global_weight, progress_every=PROGRESS_EVERY)
        result_by_ratio[float(ratio)] = res

        rs = summarize_runtime_s(res["runtime_curve"])
        ls = summarize_latency_ms(res["latency_curve"])
        ratio_runtime_rows.append(
            {
                "域间业务占比": float(ratio),
                "运行时间_s_最小值": rs["min_runtime_s"],
                "运行时间_s_中位数": rs["median_runtime_s"],
                "运行时间_s_平均值": rs["mean_runtime_s"],
                "运行时间_s_最大值": rs["max_runtime_s"],
                "平均运行时间_s_全体业务": res["mean_runtime_s"],
                "平均运行时间_s_仅成功业务": res["mean_runtime_s_success_only"],
                "成功业务数": res["success_num"],
                "阻塞业务数": res["blocked_num"],
            }
        )
        ratio_latency_rows.append(
            {
                "域间业务占比": float(ratio),
                "时延ms_最小值": ls["min_latency_ms"],
                "时延ms_中位数": ls["median_latency_ms"],
                "时延ms_平均值": ls["mean_latency_ms"],
                "时延ms_最大值": ls["max_latency_ms"],
                "平均时延ms_全体业务": res["mean_latency_ms"],
                "平均时延ms_仅成功业务": res["mean_latency_ms_success_only"],
                "成功业务数": res["success_num"],
                "阻塞业务数": res["blocked_num"],
            }
        )
        ratio_wave_rows.append(
            {
                "域间业务占比": float(ratio),
                "已激活波长总数": int(res["total_wave"]),
            }
        )
        ratio_lightpath_rows.append(
            {
                "域间业务占比": float(ratio),
                "已激活的光路数": int(res["total_lightpath"]),
            }
        )

    pd.DataFrame(ratio_runtime_rows).to_csv(out_ratio_runtime_csv, index=False, encoding="utf-8-sig")
    pd.DataFrame(ratio_latency_rows).to_csv(out_ratio_latency_csv, index=False, encoding="utf-8-sig")
    pd.DataFrame(ratio_wave_rows).to_csv(wave_ratio_csv, index=False, encoding="utf-8-sig")
    pd.DataFrame(ratio_lightpath_rows).to_csv(lightpath_ratio_csv, index=False, encoding="utf-8-sig")

    # 复用 ratio=0.5 的一次运行结果，输出“业务请求数-运行时间/波长”逐条曲线
    res05 = result_by_ratio.get(0.5)
    if res05 is None:
        raise RuntimeError("未找到 ratio=0.5 的结果，无法输出业务请求数曲线 CSV")

    pd.DataFrame(
        {
            "业务请求数": list(range(1, Database.job_number + 1)),
            "运行时间_s": [float(x) for x in res05["runtime_curve"]],
        }
    ).to_csv(out_runtime_csv, index=False, encoding="utf-8-sig")
    pd.DataFrame(
        {
            "业务请求数": list(range(1, Database.job_number + 1)),
            "时延ms": [float(x) for x in res05["latency_curve"]],
        }
    ).to_csv(out_latency_csv, index=False, encoding="utf-8-sig")

    pd.DataFrame(
        {
            "业务请求数": list(range(1, Database.job_number + 1)),
            "已激活波长总数": [int(x) for x in res05["wave_used_curve"]],
        }
    ).to_csv(wave_business_csv, index=False, encoding="utf-8-sig")
    pd.DataFrame(
        {
            "业务请求数": list(range(1, Database.job_number + 1)),
            "已建立的光路数": [int(x) for x in res05["lightpath_curve"]],
        }
    ).to_csv(lightpath_business_csv, index=False, encoding="utf-8-sig")

    print(f"[不分域_基线weights] 已输出: {out_runtime_csv}")
    print(f"[不分域_基线weights] 已输出: {out_ratio_runtime_csv}")
    print(f"[不分域_基线weights] 已输出: {out_latency_csv}")
    print(f"[不分域_基线weights] 已输出: {out_ratio_latency_csv}")
    print(f"[不分域_基线weights] 已输出: {wave_business_csv}")
    print(f"[不分域_基线weights] 已输出: {wave_ratio_csv}")
    print(f"[不分域_基线weights] 已输出: {lightpath_business_csv}")
    print(f"[不分域_基线weights] 已输出: {lightpath_ratio_csv}")
