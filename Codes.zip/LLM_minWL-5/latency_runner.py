import math
import multiprocessing as mp
import os
import statistics
import time
from typing import List, Sequence

import pandas as pd

import AuGraph
import Compute
import Database
import RWA
import Service
import delay
import graph
import latency as latency_mod
from AuGraph_simulation_LLM import run_domain_sim
from scenario_csv_runner import TRAFFIC_FILES_BY_RATIO, load_services_from_csv


def print_mean_latency_runtime_console(log_prefix: str, latency_stats: dict) -> None:
    """
    控制台打印平均时延 / 平均运行时间。
    若「全体」与「仅成功」数值相同（常见：无阻塞或失败业务时延亦为 0），只打一行，避免重复。
    """
    ml_a = float(latency_stats["mean_latency_ms"])
    ml_s = float(latency_stats.get("mean_latency_ms_success_only", float("nan")))
    rt_a = float(latency_stats["mean_runtime_s"])
    rt_s = float(latency_stats.get("mean_runtime_s_success_only", float("nan")))

    def _same(a: float, b: float) -> bool:
        if b != b:  # nan
            return False
        return math.isclose(a, b, rel_tol=0.0, abs_tol=1e-9)

    if _same(ml_a, ml_s):
        print(f"{log_prefix} 平均时延: {ml_a:.6f} ms")
    else:
        print(
            f"{log_prefix} 平均时延(全体业务): {ml_a:.6f} ms | "
            f"平均时延(仅成功业务): {ml_s:.6f} ms"
        )
    if _same(rt_a, rt_s):
        print(f"{log_prefix} 平均运行时间: {rt_a:.6f} s/条")
    else:
        print(
            f"{log_prefix} 平均运行时间(全体业务): {rt_a:.6f} s/条 | "
            f"平均运行时间(仅成功业务): {rt_s:.6f} s/条"
        )


def summarize_runtime_s(runtime_curve: Sequence[float]) -> dict:
    """对每条业务的运行时间（秒）做 min / median / mean / max。"""
    if not runtime_curve:
        return {
            "min_runtime_s": float("inf"),
            "median_runtime_s": float("inf"),
            "mean_runtime_s": float("inf"),
            "max_runtime_s": float("inf"),
        }
    xs: List[float] = [float(x) for x in runtime_curve]
    n = len(xs)
    return {
        "min_runtime_s": min(xs),
        "median_runtime_s": float(statistics.median(xs)),
        "mean_runtime_s": float(sum(xs) / n),
        "max_runtime_s": max(xs),
    }


def _reset_delay_module():
    # delay.py uses module-level globals; reset them to keep each run independent.
    delay.latency = []
    delay.is_block = []
    delay.average_latency = [0]
    delay.success_num = [0]
    delay.reject_num = [0]


def compute_global_latency_curve(csv_path: str, global_weight, progress_every: int = 50):
    """
    不分域：逐业务（0..job_number-1）计算每条业务时延（ms代理指标）。
    返回：
      latency_curve: list[float]，长度=job_number
      business_success: list[bool]，长度=job_number
      stats: dict（含 mean_runtime_s、成功业务子集均值等）
      runtime_curve: list[float]，每条业务路由/处理墙钟时间（秒）
    """
    _reset_delay_module()

    services = load_services_from_csv(csv_path)
    Service.service_list = services

    # init network state
    Database.clear(Database.links_physical)
    Compute.init_wavelength_tracker(Database.node_number, Database.wavelength_number)
    AuGraph.links_virtual_list.clear()

    latency_curve = []
    business_success = []
    runtime_curve = []

    jn = int(Database.job_number)
    for i in range(jn):
        if i == 0:
            AuGraph.au_graph_init(AuGraph.edge_weight)
        else:
            AuGraph.update_au_graph_weight(AuGraph.edge_weight)

        t0 = time.perf_counter()
        flag, _wave_used, au_edges_list, _reason = RWA.route_wave_assign(
            global_weight, i, return_reason=True
        )
        latency_val, _avg = delay.compute_latency(flag, au_edges_list)
        runtime_curve.append(float(time.perf_counter() - t0))
        latency_curve.append(float(latency_val))
        business_success.append(bool(flag))

        if progress_every and ((i + 1) % int(progress_every) == 0 or (i + 1) == jn):
            print(
                f"[不分域时延] 进度: {i + 1}/{jn} "
                f"({(i + 1) / jn * 100:.1f}%)"
            )

    # 与 latency.py 一致：min/median/mean/max 对「全体业务」时延（含失败 0）
    stats_all = latency_mod.summarize_all_latencies_ms(latency_curve)
    succ = int(sum(1 for x in business_success if x))
    mean_run_all = float(sum(runtime_curve) / jn) if jn else 0.0
    stats = {
        **stats_all,
        "success_num": succ,
        "blocked_num": int(jn - succ),
        "mean_runtime_s": mean_run_all,
    }
    if succ > 0:
        stats["mean_latency_ms_success_only"] = float(
            sum(latency_curve[i] for i in range(jn) if business_success[i]) / succ
        )
        stats["mean_runtime_s_success_only"] = float(
            sum(runtime_curve[i] for i in range(jn) if business_success[i]) / succ
        )
    else:
        stats["mean_latency_ms_success_only"] = float("nan")
        stats["mean_runtime_s_success_only"] = float("nan")

    return latency_curve, business_success, stats, runtime_curve


def compute_domain_latency_curve(csv_path: str, domain_edge_weight_by_id, progress_every: int = 0):
    """
    分域：逐业务按跨域拆段，在域内并行仿真子段时延；最后按原始业务 id 求和得到每条业务的总时延。
    返回：
      latency_curve: list[float]，长度=job_number
      business_success: list[bool]，长度=job_number
      stats: dict（含 mean_latency_ms、mean_runtime_s 及成功业务子集均值等）
      runtime_curve: list[float]，每条业务各域子段处理时间之和（秒）
    """
    _reset_delay_module()

    base_services = load_services_from_csv(csv_path)
    jn = int(Database.job_number)

    num_domains = len(graph.domain_node_list)
    domain_to_seg_services = {d: [] for d in range(num_domains)}
    business_success = [True for _ in range(jn)]
    # 记录每条原始业务被拆成了多少段，用于补充“跨段边界切换”时延开销。
    segment_count_by_business = [0 for _ in range(jn)]

    for base_service in base_services:
        ser_id = int(base_service["id"])
        src = base_service["src"]
        dest = base_service["dest"]
        traffic = base_service["traffic"]

        full_path, segments = graph.route_with_domain_segments(src, dest)
        if not full_path or not segments:
            if 0 <= ser_id < Database.job_number:
                business_success[ser_id] = False
            continue

        for seg_idx, seg in enumerate(segments):
            seg_nodes = seg["nodes"]
            seg_domain = seg["domain"]
            seg_service = {
                "id": f"{ser_id}_seg{seg_idx}_D{seg_domain}",
                "ser_id": ser_id,
                "src": seg_nodes[0],
                "dest": seg_nodes[-1],
                "traffic": traffic.copy(),
            }
            if seg_domain in domain_to_seg_services:
                domain_to_seg_services[seg_domain].append(seg_service)
                segment_count_by_business[ser_id] += 1

    tasks = [
        (d, segs, domain_edge_weight_by_id[d], True, True)
        for d, segs in domain_to_seg_services.items()
        if segs
    ]
    if not tasks:
        zeros_lat = [0.0 for _ in range(jn)]
        zeros_rt = [0.0 for _ in range(jn)]
        stats = {
            "min_latency_ms": float("inf"),
            "median_latency_ms": float("inf"),
            "mean_latency_ms": float("inf"),
            "max_latency_ms": float("inf"),
            "success_num": 0,
            "blocked_num": jn,
            "mean_runtime_s": 0.0,
            "mean_runtime_s_success_only": float("nan"),
            "mean_latency_ms_success_only": float("nan"),
        }
        return zeros_lat, business_success, stats, zeros_rt

    with mp.Pool(processes=len(tasks)) as pool:
        results = pool.starmap(run_domain_sim, tasks)

    latency_curve = [0.0 for _ in range(jn)]
    runtime_curve = [0.0 for _ in range(jn)]

    for r in results:
        ser_id_list = r[2]
        seg_success_list = r[8]
        seg_latency_list = r[10]
        seg_elapsed_list = r[5]

        for sid, ok, lat, dt in zip(ser_id_list, seg_success_list, seg_latency_list, seg_elapsed_list):
            sid_int = int(sid)
            if 0 <= sid_int < jn:
                latency_curve[sid_int] += float(lat)
                runtime_curve[sid_int] += float(dt)
                if not bool(ok):
                    business_success[sid_int] = False

    # 分域拆段后，跨段边界会发生额外切换开销。
    # 之前仅“子段时延求和”，会低估多段业务总时延；这里补上每个边界一次固定 OEO 开销。
    boundary_switch_penalty_ms = float(2 * Database.OEO_time)
    for k in range(jn):
        if business_success[k] and segment_count_by_business[k] > 1:
            latency_curve[k] += float((segment_count_by_business[k] - 1) * boundary_switch_penalty_ms)

    # If a business is blocked, set its latency to 0 to match delay.py behavior (blocked path has no valid route).
    for k in range(jn):
        if not business_success[k]:
            latency_curve[k] = 0.0
            runtime_curve[k] = 0.0

    stats_all = latency_mod.summarize_all_latencies_ms(latency_curve)
    succ = int(sum(1 for x in business_success if x))
    mean_run_all = float(sum(runtime_curve) / jn) if jn else 0.0
    stats = {
        **stats_all,
        "success_num": succ,
        "blocked_num": int(jn - succ),
        "mean_runtime_s": mean_run_all,
    }
    if succ > 0:
        stats["mean_latency_ms_success_only"] = float(
            sum(latency_curve[i] for i in range(jn) if business_success[i]) / succ
        )
        stats["mean_runtime_s_success_only"] = float(
            sum(runtime_curve[i] for i in range(jn) if business_success[i]) / succ
        )
    else:
        stats["mean_latency_ms_success_only"] = float("nan")
        stats["mean_runtime_s_success_only"] = float("nan")

    return latency_curve, business_success, stats, runtime_curve


def export_latency_csv(csv_path: str, latency_curve, out_path: str):
    jn = Database.job_number
    pd.DataFrame(
        {
            "业务请求数": list(range(1, jn + 1)),
            "时延ms": [float(x) for x in latency_curve],
        }
    ).to_csv(out_path, index=False, encoding="utf-8-sig")

    print(f"已保存时延CSV: {out_path}")


def export_runtime_csv(csv_path: str, runtime_curve: Sequence[float], out_path: str):
    """每条业务一行的处理/运行时间（秒），列：业务请求数、运行时间_s。"""
    del csv_path  # 与 export_latency_csv 签名一致，便于调用方对称传参
    jn = Database.job_number
    pd.DataFrame(
        {
            "业务请求数": list(range(1, jn + 1)),
            "运行时间_s": [float(x) for x in runtime_curve],
        }
    ).to_csv(out_path, index=False, encoding="utf-8-sig")
    print(f"已保存运行时间CSV: {out_path}")


def export_domain_ratio_latency_csv(
    domain_edge_weight_by_id,
    out_path: str,
    progress_every: int = 0,
):
    """
    对 scenario_csv_runner.TRAFFIC_FILES_BY_RATIO 中每个流量文件跑一次分域时延，
    输出「域间业务占比 → 时延统计」汇总表（每行一个占比）。
    """
    rows = []
    for traffic_csv, ratio in TRAFFIC_FILES_BY_RATIO:
        print(f"[域间占比-时延] 开始 ratio={ratio} ({traffic_csv})")
        _curve, _succ, stats, _rt = compute_domain_latency_curve(
            traffic_csv, domain_edge_weight_by_id, progress_every=progress_every
        )
        rows.append(
            {
                "域间业务占比": float(ratio),
                "时延ms_最小值": stats["min_latency_ms"],
                "时延ms_中位数": stats["median_latency_ms"],
                "时延ms_平均值": stats["mean_latency_ms"],
                "时延ms_最大值": stats["max_latency_ms"],
                "成功业务数": stats["success_num"],
                "阻塞业务数": stats["blocked_num"],
            }
        )
        print(f"[域间占比-时延] 完成 ratio={ratio}, 统计: {stats}")

    pd.DataFrame(rows).to_csv(out_path, index=False, encoding="utf-8-sig")
    print(f"已保存域间占比-时延CSV: {out_path}")


def export_domain_ratio_runtime_csv(
    domain_edge_weight_by_id,
    out_path: str,
    progress_every: int = 0,
):
    """
    对 TRAFFIC_FILES_BY_RATIO 中每个流量文件跑一次分域仿真并统计运行时间，
    输出「域间业务占比 → 运行时间」汇总表（每行一个占比）。
    """
    rows = []
    for traffic_csv, ratio in TRAFFIC_FILES_BY_RATIO:
        print(f"[域间占比-运行时间] 开始 ratio={ratio} ({traffic_csv})")
        t_wall_start = time.perf_counter()
        _curve, _succ, stats, rt_curve = compute_domain_latency_curve(
            traffic_csv, domain_edge_weight_by_id, progress_every=progress_every
        )
        wall_elapsed_s = float(time.perf_counter() - t_wall_start)
        avg_wall_time_s_per_business = (
            wall_elapsed_s / float(Database.job_number) if Database.job_number else float("nan")
        )
        rs = summarize_runtime_s(rt_curve)
        rows.append(
            {
                "域间业务占比": float(ratio),
                "运行时间_s_最小值": rs["min_runtime_s"],
                "运行时间_s_中位数": rs["median_runtime_s"],
                "运行时间_s_平均值": rs["mean_runtime_s"],
                "运行时间_s_最大值": rs["max_runtime_s"],
                "平均运行时间_s_全体业务": stats["mean_runtime_s"],
                "平均运行时间_s_仅成功业务": stats.get(
                    "mean_runtime_s_success_only", float("nan")
                ),
                "平均整体墙钟时间_s_每业务": avg_wall_time_s_per_business,
                "成功业务数": stats["success_num"],
                "阻塞业务数": stats["blocked_num"],
            }
        )
        print(
            f"[域间占比-运行时间] ratio={ratio} 平均时间(拆段+并行整体墙钟/业务数): "
            f"{avg_wall_time_s_per_business:.6f} s/条"
        )
        print(f"[域间占比-运行时间] 完成 ratio={ratio}, 统计: {stats}")

    pd.DataFrame(rows).to_csv(out_path, index=False, encoding="utf-8-sig")
    print(f"已保存域间占比-运行时间CSV: {out_path}")


def export_global_ratio_runtime_csv(
    global_weight,
    out_path: str,
    progress_every: int = 50,
):
    """不分域：各域间占比流量文件一条汇总行，列含运行时间统计（秒）。"""
    rows = []
    for traffic_csv, ratio in TRAFFIC_FILES_BY_RATIO:
        print(f"[不分域域间占比-运行时间] 开始 ratio={ratio} ({traffic_csv})")
        _lat, _succ, stats, rt_curve = compute_global_latency_curve(
            traffic_csv, global_weight, progress_every=progress_every
        )
        rs = summarize_runtime_s(rt_curve)
        rows.append(
            {
                "域间业务占比": float(ratio),
                "运行时间_s_最小值": rs["min_runtime_s"],
                "运行时间_s_中位数": rs["median_runtime_s"],
                "运行时间_s_平均值": rs["mean_runtime_s"],
                "运行时间_s_最大值": rs["max_runtime_s"],
                "平均运行时间_s_全体业务": stats["mean_runtime_s"],
                "平均运行时间_s_仅成功业务": stats.get(
                    "mean_runtime_s_success_only", float("nan")
                ),
                "成功业务数": stats["success_num"],
                "阻塞业务数": stats["blocked_num"],
            }
        )
        print(f"[不分域域间占比-运行时间] 完成 ratio={ratio}, 统计: {stats}")

    pd.DataFrame(rows).to_csv(out_path, index=False, encoding="utf-8-sig")
    print(f"已保存不分域域间占比-运行时间CSV: {out_path}")


def export_global_ratio_latency_csv(
    global_weight,
    out_path: str,
    progress_every: int = 50,
):
    """不分域：各域间占比流量文件一条汇总行，列含时延统计（ms）。"""
    rows = []
    for traffic_csv, ratio in TRAFFIC_FILES_BY_RATIO:
        print(f"[不分域域间占比-时延] 开始 ratio={ratio} ({traffic_csv})")
        _lat, _succ, stats, _rt = compute_global_latency_curve(
            traffic_csv, global_weight, progress_every=progress_every
        )
        rows.append(
            {
                "域间业务占比": float(ratio),
                "时延ms_最小值": stats["min_latency_ms"],
                "时延ms_中位数": stats["median_latency_ms"],
                "时延ms_平均值": stats["mean_latency_ms"],
                "时延ms_最大值": stats["max_latency_ms"],
                "成功业务数": stats["success_num"],
                "阻塞业务数": stats["blocked_num"],
            }
        )
        print(f"[不分域域间占比-时延] 完成 ratio={ratio}, 统计: {stats}")

    pd.DataFrame(rows).to_csv(out_path, index=False, encoding="utf-8-sig")
    print(f"已保存不分域域间占比-时延CSV: {out_path}")

