# -*- coding: utf-8 -*-
"""
路径时延（ms）计算与全量统计。

- `compute_latency_ms`：单条业务时延，规则与原先 `delay.compute_latency` 中路径累加一致，
  改为无全局副作用，供 `delay.py` / `latency_runner` / 分域仿真统一调用。
- `summarize_all_latencies_ms`：对「全体业务」时延列表做 min/median/mean/max（含阻塞等产生的 0），
  与脚本入口 `python latency.py` 的统计口径一致。
"""
from __future__ import annotations

import statistics
from typing import Any, List, Sequence

import AuGraph
import Database


def _hop_fiber_ms(a: int, b: int) -> float:
    """单跳光纤传播时延(ms)：优先 per-link 矩阵，否则回退标量 fiber_time（可为 None）。"""
    ftm = getattr(Database, "fiber_time_ms", None)
    if ftm is not None:
        return float(ftm[int(a)][int(b)])
    ft = getattr(Database, "fiber_time", None)
    return float(ft) if ft is not None else 0.0


def compute_latency_ms(flag: bool, au_edges_list: Sequence[Any]) -> float:
    """
    计算当前业务路径时延（ms）。无辅助图边或边列表为空时返回 0。
    `flag` 仅保留与旧接口一致，当前公式不区分成功/失败（失败时通常无边，自然为 0）。
    """
    del flag  # 与 delay 旧签名兼容；阻塞时通常 au_edges_list[-1] 为空
    if not au_edges_list:
        return 0.0
    cur_list = au_edges_list[-1]
    if len(cur_list) == 0:
        return 0.0

    latency_temp = 0.0
    continue_index = -1
    for j in range(len(cur_list)):
        if j > continue_index:
            cur_au_edge = cur_list[j]
            if cur_au_edge["attribute"] == 4:
                if j + 1 >= len(cur_list):
                    break
                if cur_list[j + 1]["attribute"] == 3:
                    latency_temp += 2 * Database.OEO_time + _hop_fiber_ms(
                        cur_au_edge["src_phy"], cur_au_edge["dest_phy"]
                    )
                elif cur_list[j + 1]["attribute"] == 7:
                    fiber_ms_sum = 0.0
                    for m in range(j, len(cur_list)):
                        if cur_list[m]["attribute"] == 4:
                            fiber_ms_sum += _hop_fiber_ms(
                                cur_list[m]["src_phy"], cur_list[m]["dest_phy"]
                            )
                        elif cur_list[m]["attribute"] == 7:
                            continue
                        else:
                            continue_index = m - 1
                            break
                    latency_temp += 2 * Database.OEO_time + fiber_ms_sum

            if cur_au_edge["attribute"] == 1:
                for vir_link in AuGraph.links_virtual_list:
                    if (
                        cur_au_edge["src_phy"] == vir_link["src"]
                        and cur_au_edge["dest_phy"] == vir_link["dest"]
                        and cur_au_edge["wavelength_id"] == vir_link["wavelength_id"]
                    ):
                        route_ms = 0.0
                        rt = vir_link["route"]
                        for k in range(len(rt) - 1):
                            route_ms += _hop_fiber_ms(rt[k], rt[k + 1])
                        latency_temp += 2 * Database.OEO_time + route_ms
    return float(latency_temp)


def summarize_all_latencies_ms(latency_list: Sequence[float]) -> dict:
    """对全体业务时延（含 0）计算 min / median / mean / max，单位 ms。"""
    if not latency_list:
        return {
            "min_latency_ms": float("inf"),
            "median_latency_ms": float("inf"),
            "mean_latency_ms": float("inf"),
            "max_latency_ms": float("inf"),
        }
    xs: List[float] = [float(x) for x in latency_list]
    n = len(xs)
    return {
        "min_latency_ms": min(xs),
        "median_latency_ms": float(statistics.median(xs)),
        "mean_latency_ms": float(sum(xs) / n),
        "max_latency_ms": max(xs),
    }


if __name__ == "__main__":
    import AuGraph as _AuGraph
    import Compute
    import RWA
    import Service

    Service.generate_service(0, Database.time)
    Database.clear(Database.links_physical)
    _AuGraph.links_virtual_list.clear()

    latency_list: List[float] = []
    for i in range(Database.job_number):
        if i == 0:
            _AuGraph.au_graph_init(_AuGraph.edge_weight)
        else:
            _AuGraph.update_au_graph_weight(_AuGraph.edge_weight)
        flag, wave_used, au_edges_list = RWA.route_wave_assign(_AuGraph.edge_weight, i)
        lat_ms = compute_latency_ms(flag, au_edges_list)
        latency_list.append(lat_ms)
        avg_all = sum(latency_list) / len(latency_list)
        print(i, "使用波长：", wave_used, "时延", lat_ms, "平均时延(全业务累计均值)", avg_all)

    print(latency_list)
    print()
    s = summarize_all_latencies_ms(latency_list)
    print(
        f'the min latency is {s["min_latency_ms"]:.4f} ms, '
        f'the median latency is {s["median_latency_ms"]:.4f} ms, '
        f'mean latency is {s["mean_latency_ms"]:.4f} ms, '
        f'the max latency is {s["max_latency_ms"]:.4f} ms'
    )
    print(f'{s["mean_latency_ms"]:.4f}')
