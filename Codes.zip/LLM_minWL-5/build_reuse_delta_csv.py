import pandas as pd
from pathlib import Path


def pick_file(root: Path, must_have: list[str]) -> Path:
    for p in root.glob("*.csv"):
        name = p.name
        if all(token in name for token in must_have):
            return p
    raise FileNotFoundError(f"cannot find csv with tokens: {must_have}")


def build_one(root: Path, prefix: str, out_name: str) -> None:
    wave_fp = pick_file(root, [prefix, "域间业务占比", "已激活波长总数"])
    lightpath_fp = pick_file(root, [prefix, "域间业务占比", "已激活的光路数"])

    w = pd.read_csv(wave_fp, engine="python")
    l = pd.read_csv(lightpath_fp, engine="python")

    ratio_col = w.columns[0]
    wave_col = w.columns[1]
    lp_col = l.columns[1]

    merged = w.merge(l, on=ratio_col, how="inner")
    merged = merged.sort_values(ratio_col).reset_index(drop=True)
    merged["delta_active_waves"] = merged[wave_col].diff().fillna(merged[wave_col]).astype(int)
    merged["reuse_ratio_lp_over_wave"] = merged[lp_col] / merged[wave_col]
    merged.to_csv(root / out_name, index=False, encoding="utf-8-sig")
    print(f"saved: {out_name}")


if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    build_one(root, "不分域_基线weights", "不分域_基线weights_域间占比_复用率与新增波长.csv")
    build_one(root, "分五域_基线weights", "分五域_基线weights_域间占比_复用率与新增波长.csv")
