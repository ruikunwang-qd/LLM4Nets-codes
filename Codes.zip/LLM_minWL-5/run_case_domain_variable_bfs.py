"""
多域数（2/3/4/6/7/8/9）均衡划分 + 分域并行仿真运行时间 CSV。

全网拓扑来源：与 ``graph.py`` 相同，显式读取未分域邻接 CSV
``csv格式中讯拓扑邻接矩阵_68.csv``（与 ``graph.adjacency_matrix`` 校验一致后再划分）。

划分：对该矩阵无向化后做全图 BFS 得到节点发现顺序，再按该顺序做**连续等长切块**
（各域节点数至多差 1），使跨域边主要出现在相邻块之间；边界节点为跨域无向边的端点；
各域子图节点为「本域主节点 ∪ 与主域节点相邻且主域属于其它域的节点」（与 graph.py 五域思路一致）。

输出：
  - 控制台：各域节点、边界节点、各域子图规模；邻接子矩阵写入 CSV（不刷屏打印全矩阵）
  - 运行时间 CSV：文件名后缀 ``-k域``（k 为域个数）

运行结束后会恢复 graph 模块的原始五域划分，避免影响其它脚本。
"""
from __future__ import annotations

import multiprocessing as mp
import os

import numpy as np
import pandas as pd

import Database
import domain_partition_bfs as dpb
import graph
from latency_runner import (
    compute_domain_latency_curve,
    export_domain_ratio_runtime_csv,
    export_runtime_csv,
    print_mean_latency_runtime_console,
)

# 与 run_case_domain_baseline 一致的 8 维权值，每个域相同
BASELINE_DOMAIN_WEIGHT = [0, 5, 100, 100, 1000, 10, 10, 25]

# 需要评估的域个数（不含 5，与现有五域脚本区分）
K_LIST = [2, 3, 4, 6, 7, 8, 9]

TRAFFIC_CSV = "Traffic_3000_0.5.csv"
# True: 只写主流量一条运行时间曲线；False: 额外写域间占比运行时间汇总（较慢）
ONLY_05 = True

# 划分说明与子邻接矩阵输出目录
OUTPUT_ROOT = "domain_partition_bfs_outputs"

# 每个域子图中最多保留的外域复制（边界）节点个数
MAX_EXTERNAL_NODES_PER_DOMAIN = 10

# 未分域全网拓扑（与 graph.py 第 5 行同一文件）
FULL_NETWORK_TOPOLOGY_CSV = "csv格式中讯拓扑邻接矩阵_68.csv"


def _load_full_network_adjacency(csv_path: str) -> np.ndarray:
    """与 graph.py 一致：无表头 CSV，缺失填 0，整型方阵。"""
    df = pd.read_csv(csv_path, header=None).fillna(0)
    arr = np.array(df, dtype=int)
    if arr.ndim != 2 or arr.shape[0] != arr.shape[1]:
        raise ValueError(f"邻接矩阵须为方阵: {csv_path} shape={arr.shape}")
    return arr


def _save_submatrix_csv(adj: np.ndarray, nodes: list[int], path: str) -> None:
    sub = dpb.submatrix_for_nodes(adj, nodes)
    pd.DataFrame(sub, index=nodes, columns=nodes).to_csv(path, encoding="utf-8-sig")


def _print_and_save_partition(
    k: int, adj: np.ndarray, topology_csv: str
) -> tuple[list[list[int]], list[int]]:
    domain_node_list = dpb.partition_balanced_by_bfs_layers(adj, k)
    primary_list = dpb.primary_domain_from_lists(domain_node_list)
    domain_node_list_all = dpb.build_domain_node_list_all(
        domain_node_list,
        primary_list,
        adj,
        max_external_per_domain=MAX_EXTERNAL_NODES_PER_DOMAIN,
    )
    boundary = dpb.boundary_nodes_in_subgraphs(domain_node_list_all, primary_list)
    full_cut_boundary = dpb.boundary_nodes(adj, primary_list)
    cut_edges = dpb.count_cut_edges(adj, primary_list)

    print(f"\n========== BFS 均衡划分：{k} 域 ==========")
    sizes = [len(dom) for dom in domain_node_list]
    print(f"各域主节点数: {sizes}，合计 {sum(sizes)}，min={min(sizes)} max={max(sizes)}")
    print(f"跨域无向边数: {cut_edges}")
    print(
        f"子图保留外域复制节点(每域≤{MAX_EXTERNAL_NODES_PER_DOMAIN}, 全局去重): "
        f"{len(boundary)} 个 -> {boundary}"
    )
    print(
        f"(参考) 若不做截断，跨域边端点去重数: {len(full_cut_boundary)}"
    )
    for d in range(k):
        print(f"  域{d} 主节点({len(domain_node_list[d])}): {domain_node_list[d]}")
        ghosts = sorted(set(domain_node_list_all[d]) - set(domain_node_list[d]))
        print(
            f"  域{d} 子图节点数(含边界复制)={len(domain_node_list_all[d])}，"
            f"额外节点: {ghosts}"
        )
    out_dir = os.path.join(OUTPUT_ROOT, f"k{k}")
    os.makedirs(out_dir, exist_ok=True)
    summary_lines = [
        f"topology_csv={topology_csv}",
        f"k={k}",
        f"max_external_per_domain={MAX_EXTERNAL_NODES_PER_DOMAIN}",
        f"domain_sizes={sizes}",
        f"cut_edges={cut_edges}",
        f"subgraph_ghost_boundary({len(boundary)})={boundary}",
        f"full_cut_endpoints_uncapped({len(full_cut_boundary)})={full_cut_boundary}",
        "",
    ]
    for d in range(k):
        path = os.path.join(out_dir, f"domain_{d}_adj_submatrix.csv")
        _save_submatrix_csv(adj, domain_node_list_all[d], path)
        summary_lines.append(f"domain_{d}_primary={domain_node_list[d]}")
        summary_lines.append(f"domain_{d}_subgraph_nodes={domain_node_list_all[d]}")
        summary_lines.append(f"saved_adj_csv={path}")
        summary_lines.append("")
    with open(os.path.join(out_dir, "partition_summary.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(summary_lines))
    print(f"各域子邻接矩阵已写入: {out_dir}\\domain_*_adj_submatrix.csv")

    dpb.apply_partition_to_graph_module(graph, domain_node_list, domain_node_list_all, boundary)
    return domain_node_list, boundary


if __name__ == "__main__":
    mp.freeze_support()
    os.makedirs(OUTPUT_ROOT, exist_ok=True)

    snap = dpb.snapshot_graph_partition(graph)
    adj = _load_full_network_adjacency(FULL_NETWORK_TOPOLOGY_CSV)
    gadj = np.asarray(graph.adjacency_matrix, dtype=int)
    if adj.shape != gadj.shape or not np.array_equal(adj, gadj):
        raise ValueError(
            f"拓扑不一致：{FULL_NETWORK_TOPOLOGY_CSV} 与 graph.adjacency_matrix 不相等。"
            "请确认 graph.py 仍从该文件加载，或先重新 import graph。"
        )
    print(
        f"[拓扑] 未分域全网: {FULL_NETWORK_TOPOLOGY_CSV}, "
        f"n={adj.shape[0]}（已与 graph.adjacency_matrix 校验一致）"
    )

    try:
        for k in K_LIST:
            _print_and_save_partition(k, adj, FULL_NETWORK_TOPOLOGY_CSV)

            domain_edge_weight_by_id = {
                d: Database.to_augraph_edge_weight(BASELINE_DOMAIN_WEIGHT) for d in range(k)
            }
            out_runtime = f"分BFS均衡域_基线weights_业务请求数-运行时间-{k}域.csv"
            out_ratio_runtime = f"分BFS均衡域_基线weights_域间业务占比-运行时间-{k}域.csv"

            print(f"[分BFS均衡域 k={k}] 计算运行时间: {TRAFFIC_CSV}")
            _lat, _succ, latency_stats, runtime_curve = compute_domain_latency_curve(
                TRAFFIC_CSV, domain_edge_weight_by_id, progress_every=50
            )
            export_runtime_csv(TRAFFIC_CSV, runtime_curve, out_runtime)
            print_mean_latency_runtime_console(f"[分BFS均衡域 k={k}]", latency_stats)
            print(f"[分BFS均衡域 k={k}] 已输出: {out_runtime}")

            if not ONLY_05:
                print(f"[分BFS均衡域 k={k}] 域间占比运行时间汇总...")
                export_domain_ratio_runtime_csv(
                    domain_edge_weight_by_id, out_ratio_runtime, progress_every=50
                )
                print(f"[分BFS均衡域 k={k}] 已输出: {out_ratio_runtime}")
    finally:
        dpb.restore_graph_partition(graph, snap)
        print("\n已恢复 graph 模块为原始五域划分。")
